import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties, type PointerEvent as RPointerEvent } from 'react'
import { createPortal } from 'react-dom'
import { AnimatePresence, motion } from 'framer-motion'
import Hls from 'hls.js'
import {
  Airplay, AudioLines, Cast, Check, CheckCircle2, ChevronDown, FastForward, Flag, Languages, List, Loader2, Maximize, Minimize, Pause, Play, RotateCcw, RotateCw,
  Search, Server, Settings, SkipBack, SkipForward, TriangleAlert, Upload, Users, Volume1, Volume2, VolumeX, X,
} from 'lucide-react'
import { apiUrl, fetchStream, type EpInfo, type EpKind } from '../services/api'
import { nativeHlsRequestConfig, resolveNativeApiPath } from '../lib/nativeRuntime'
import { KIND } from './EpisodeList'
import { WatchedThumbOverlay } from './WatchedBadge'
import { blob, BLOB_T, LITE, SPRING } from './ServerPopup'
import { LoadingGrid } from './LoadingGrid'
import { gpuSupported, startUpscale, type Anime4KMode } from '../lib/upscale'
import { findActiveCue, parseSubtitleText, type Cue } from '../lib/subtitles'
import { submitStreamReport } from '../lib/supabase'
import { toast } from '../lib/toast'
import { attachPlayerSecurity } from '../lib/playerSecurity'
import {
  airplayPicker, airplaySupported, castLoad, castRequest, castSeek, castSetVolume, castStop, castToggleMute, castTogglePlay, castUrl, getCast, initCast, onCastFinished, useCast,
} from '../lib/cast'
import { type ServerAccess } from '../lib/servers'
import { getPrefs } from '../lib/library'
import { findTrackForMode, formatHlsTrackLabel, isOriginalTrack, trackMatchesLang } from '../lib/audioTrackLogic'
import {
  resolveIsTouchInteraction,
  resolveStageTapAction,
  shouldBlockSyntheticUiClick,
  shouldIgnoreGestureClick,
} from '../lib/playerTapLogic'
import { sanitizeSkipPair } from '../lib/skipValidation'
import {
  buildPosStorageKey,
  isNearOrAtPlaybackEnd,
  resolveResumePosition,
  shouldPersistPlaybackPosition,
  shouldRestartFromBeginningOnPlay,
} from '../lib/playbackResume'
import { StreamProblem } from './StreamProblem'
import { EMBED_POPUP_BLOCKED_SANDBOX, EXTERNAL_PLAYER_ALLOW_PERMISSIONS, isDirectFileMediaUrl } from '../lib/movieServers'
import './cineplayer.css'

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2]
const isEn = (t: { language: string; label: string }) => /^en\b|^eng|english/i.test(t.language) || /english/i.test(t.label)
const ISO: Record<string, string> = { en: 'English', eng: 'English', ar: 'Arabic', ara: 'Arabic', es: 'Spanish', spa: 'Spanish', fr: 'French', fre: 'French', fra: 'French', de: 'German', ger: 'German', deu: 'German', it: 'Italian', ita: 'Italian', pt: 'Portuguese', por: 'Portuguese', pob: 'Portuguese', ru: 'Russian', rus: 'Russian', hi: 'Hindi', hin: 'Hindi', ta: 'Tamil', tam: 'Tamil', te: 'Telugu', tel: 'Telugu', ml: 'Malayalam', mal: 'Malayalam', kn: 'Kannada', kan: 'Kannada', bn: 'Bengali', ben: 'Bengali', ja: 'Japanese', jpn: 'Japanese', zh: 'Chinese', chi: 'Chinese', zho: 'Chinese', id: 'Indonesian', ind: 'Indonesian', th: 'Thai', tha: 'Thai', vi: 'Vietnamese', vie: 'Vietnamese', ko: 'Korean', kor: 'Korean', tr: 'Turkish', tur: 'Turkish', pl: 'Polish', pol: 'Polish', nl: 'Dutch', dut: 'Dutch', nld: 'Dutch' }
/** "Arabic - Arabic", "English #2", "eng" all fold into one language name so the menu can count them */
const langName = (t: { language: string; label: string }) => {
  const raw = (t.language || t.label || '').split(/[-–(#]/)[0].trim()
  return ISO[raw.toLowerCase()] ?? (raw ? raw[0].toUpperCase() + raw.slice(1) : 'Unknown')
}
function formatTrackSubLabel(label: string, lang: string): string {
  let s = (label || '').trim()
  if (!s) return 'Default'
  const langEsc = lang.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const prefixRegex = new RegExp(`^${langEsc}\\s*[-–:#]?\\s*`, 'i')
  if (prefixRegex.test(s)) {
    s = s.replace(prefixRegex, '').trim()
  }
  if (s.startsWith('(') && s.endsWith(')')) {
    s = s.slice(1, -1).trim()
  }
  s = s.replace(/([a-zA-Z])\(([^)]+)\)/g, '$1 ($2)')
  if (!s || s.toLowerCase() === lang.toLowerCase()) {
    return 'Default'
  }
  return s
}
const sourceReferer = (id?: string) =>
  id === 'acdn' ? 'https://ravok.buzz/' : id?.startsWith('flixcloud') ? 'https://flixcloud.cc/' : 'https://megaplay.buzz/'

const SUB_SIZE = {
  tiny: 0.9,
  small: 1.15,
  medium: 1.45,
  large: 1.8,
  xlarge: 2.2,
} as const

// Web fonts only (loaded in index.html) — system stacks render as garbage on some Android OEM fonts.
const SUB_FONT_LIST = [
  ['sans', 'Inter', '"Inter", Arial, sans-serif', 'sans'],
  ['fansub', 'Roboto', '"Roboto", Arial, sans-serif', 'sans'],
  ['rounded', 'Outfit', '"Outfit", "Nunito", sans-serif', 'sans'],
  ['nunito', 'Nunito', '"Nunito", sans-serif', 'sans'],
  ['poppins', 'Poppins', '"Poppins", Arial, sans-serif', 'sans'],
  ['montserrat', 'Montserrat', '"Montserrat", Arial, sans-serif', 'sans'],
  ['opensans', 'Open Sans', '"Open Sans", Arial, sans-serif', 'sans'],
  ['lato', 'Lato', '"Lato", Arial, sans-serif', 'sans'],
  ['atkinson', 'Hyperlegible', '"Atkinson Hyperlegible", Arial, sans-serif', 'sans'],
  ['serif', 'Merriweather', '"Merriweather", Georgia, serif', 'serif'],
  ['playfair', 'Playfair', '"Playfair Display", Georgia, serif', 'serif'],
  ['lora', 'Lora', '"Lora", Georgia, serif', 'serif'],
  ['mono', 'Roboto Mono', '"Roboto Mono", "Courier New", monospace', 'mono'],
  ['jetbrains', 'JetBrains Mono', '"JetBrains Mono", "Courier New", monospace', 'mono'],
  ['oswald', 'Oswald', '"Oswald", Impact, sans-serif', 'display'],
  ['bebas', 'Bebas Neue', '"Bebas Neue", Impact, sans-serif', 'display'],
  ['bangers', 'Bangers', '"Bangers", Impact, cursive', 'display'],
  ['lobster', 'Lobster', '"Lobster", cursive', 'display'],
  ['marker', 'Marker', '"Permanent Marker", cursive', 'display'],
  ['comic', 'Comic Neue', '"Comic Neue", "Comic Sans MS", cursive', 'hand'],
  ['caveat', 'Caveat', '"Caveat", cursive', 'hand'],
] as const
const FONT_CATS = [['all', 'All'], ['sans', 'Sans'], ['serif', 'Serif'], ['mono', 'Mono'], ['display', 'Display'], ['hand', 'Handwriting']] as const
type SubFont = (typeof SUB_FONT_LIST)[number][0]
const SUB_FONTS = Object.fromEntries(SUB_FONT_LIST.map(([k, , f]) => [k, f])) as Record<SubFont, string>

const CAP_COLORS = [
  '#ffffff', // White
  '#ffe14d', // Yellow
  '#5fe3ff', // Cyan
  '#7dff9b', // Mint
  '#ff9f43', // Amber
  '#ff78c4', // Pink
]

const EDGE_KEYS = ['none', 'shadow', 'outline', 'heavy', 'glow'] as const
type EdgeKey = (typeof EDGE_KEYS)[number]
const capEdge = (k: EdgeKey, c: string) =>
  ({
    none: 'none',
    shadow: `0 2px 4px ${c}e6, 0 1px 2px ${c}`,
    outline: `-1px -1px 0 ${c}, 1px -1px 0 ${c}, -1px 1px 0 ${c}, 1px 1px 0 ${c}`,
    heavy: `-2px -2px 0 ${c}, 2px -2px 0 ${c}, -2px 2px 0 ${c}, 2px 2px 0 ${c}, 0 2px 6px ${c}`,
    glow: `0 0 6px currentColor, 0 0 12px ${c}e6, 0 2px 4px ${c}`,
  })[k] ?? 'none'

const EDGE_COLORS = ['#000000', '#ffffff', '#dc143c', '#1e66ff', '#7a3cff']
const BG_COLORS = ['#08080a', '#000000', '#1c1c24', '#0b1d4d', '#4d0b14', '#ffffff']
const hexRgb = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16) || 0).join(',')

const CAP_BOX = {
  pill: 'Pill',
  block: 'Block',
  none: 'None',
} as const

const CAP_DEFAULT = {
  size: 'medium' as keyof typeof SUB_SIZE,
  font: 'sans' as SubFont,
  weight: 700,
  spacing: 'normal' as 'normal' | 'wide' | 'tight',
  bg: 65,
  boxStyle: 'pill' as keyof typeof CAP_BOX,
  pos: 0,
  color: '#ffffff',
  edge: 'shadow' as EdgeKey,
  scale: 100,
  italic: false,
  upper: false,
  edgeColor: '#000000',
  bgColor: '#08080a',
  opacity: 100,
  lh: 135,
  width: 100,
  blur: 0,
  align: 'center' as 'left' | 'center' | 'right',
}
type CapStyle = typeof CAP_DEFAULT

const capCss = (cs: CapStyle, u: string): CSSProperties => {
  const plain = cs.boxStyle === 'none' || cs.bg === 0
  return {
    fontSize: `max(13px, calc(${u} * ${(SUB_SIZE[cs.size] ?? 1.45) * (cs.scale / 100)}))`,
    fontFamily: SUB_FONTS[cs.font] ?? SUB_FONTS.sans,
    fontWeight: cs.weight ?? 700,
    fontStyle: cs.italic ? 'italic' : 'normal',
    textTransform: cs.upper ? 'uppercase' : 'none',
    letterSpacing: cs.spacing === 'wide' ? '0.06em' : cs.spacing === 'tight' ? '-0.02em' : 'normal',
    color: `rgba(${hexRgb(cs.color)},${cs.opacity / 100})`,
    lineHeight: cs.lh / 100,
    maxWidth: `${cs.width}%`,
    textAlign: cs.align,
    backdropFilter: !plain && cs.blur ? `blur(${cs.blur}px)` : undefined,
    WebkitBackdropFilter: !plain && cs.blur ? `blur(${cs.blur}px)` : undefined,
    background: plain ? 'transparent' : `rgba(${hexRgb(cs.bgColor)},${cs.bg / 100})`,
    textShadow: capEdge(cs.edge, cs.edgeColor),
    padding: plain ? '0.1em 0.35em' : '0.25em 0.7em',
    borderRadius: cs.boxStyle === 'block' ? '2px' : '0.45em',
  }
}

const CAP_PRESETS: [string, Partial<CapStyle>][] = [
  ['Default', CAP_DEFAULT],
  ['Netflix', { font: 'fansub', weight: 500, edge: 'shadow', boxStyle: 'none', bg: 0 }],
  ['Fansub', { font: 'fansub', color: '#ffe14d', edge: 'heavy', boxStyle: 'none', bg: 0 }],
  ['Cinema', { font: 'serif', weight: 400, edge: 'outline', boxStyle: 'none', bg: 0 }],
  ['Comic', { font: 'bangers', upper: true, spacing: 'wide', edge: 'heavy', boxStyle: 'none', bg: 0 }],
  ['Glass', { font: 'rounded', boxStyle: 'pill', bg: 35, blur: 8 }],
  ['Accessible', { font: 'atkinson', size: 'large', color: '#ffe14d', boxStyle: 'block', bg: 90, bgColor: '#000000', edge: 'none' }],
]

const loadCap = (): CapStyle => {
  try {
    return { ...CAP_DEFAULT, ...JSON.parse(localStorage.getItem('zp-cap') || '{}') }
  } catch {
    return CAP_DEFAULT
  }
}

export type VideoFilterPreset = 'off' | 'vibrant' | 'cinema' | 'sharp' | 'warm'

const VIDEO_FILTER_DEFAULTS = {
  preset: 'off' as VideoFilterPreset,
  brightness: 100,
  contrast: 100,
  saturation: 100,
}
type VideoFilters = typeof VIDEO_FILTER_DEFAULTS

const loadVideoFilters = (): VideoFilters => {
  try {
    return { ...VIDEO_FILTER_DEFAULTS, ...JSON.parse(localStorage.getItem('zp-vfx') || '{}') }
  } catch {
    return VIDEO_FILTER_DEFAULTS
  }
}

const ANIME4K_MODES: Array<{ id: Anime4KMode; label: string; desc: string }> = [
  { id: 'modeA', label: 'Mode A', desc: 'Balanced restoration & 2× upscale (Best for 720p/1080p anime)' },
  { id: 'modeB', label: 'Mode B', desc: 'Soft restoration (Reduces compression ringing & artifacts)' },
  { id: 'modeC', label: 'Mode C', desc: 'Sharp outlines & high detail for crisp modern animation' },
  { id: 'modeAA', label: 'Mode AA', desc: 'Double-pass ultra restoration for maximum clean detail' },
  { id: 'denoise', label: 'Denoise', desc: 'Artifact removal & debanding + 2× CNN upscale' },
  { id: 'fast', label: 'Fast CNN', desc: 'Lightweight 2× neural net (low battery / integrated GPU)' },
]
const EP_PAGE = 25
const fmtAir = (d: string | null) => (d ? new Date(d + 'T00:00:00').toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : null)
const clamp = (n: number, a: number, b: number) => Math.min(b, Math.max(a, n))
const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(' ')
const fmt = (s: number) => {
  if (!isFinite(s) || s < 0) s = 0
  const h = (s / 3600) | 0
  const m = ((s % 3600) / 60) | 0
  const x = s % 60 | 0
  return `${h ? h + ':' + String(m).padStart(2, '0') : m}:${String(x).padStart(2, '0')}`
}

type Seg = { start: number; end: number } | null | undefined
const ASPECTS = ['Fit', 'Fill', 'Stretch', '16:9', '4:3'] as const
type Aspect = (typeof ASPECTS)[number]
const loadAspect = (): Aspect => {
  try {
    const v = localStorage.getItem('zp-ar') as Aspect
    return ASPECTS.includes(v) ? v : 'Fit'
  } catch {
    return 'Fit'
  }
}
/** Video box style per aspect mode. 16:9 / 4:3 stretch the picture to that ratio, then letterbox it inside the player. */
const aspectStyle = (a: Aspect, isFs = false): CSSProperties => {
  if (a === 'Fit') return isFs ? { objectFit: 'contain' } : { objectFit: 'fill' }
  if (a === 'Fill') return { objectFit: 'cover' }
  if (a === 'Stretch') return { objectFit: 'fill' }
  const r = a === '16:9' ? 16 / 9 : 4 / 3
  return { objectFit: 'fill', inset: 0, margin: 'auto', width: `min(100cqw, ${r} * 100cqh)`, height: `min(100cqh, 100cqw / ${r})` }
}
const readNum = (k: string, d: number) => {
  try {
    const v = localStorage.getItem(k)
    return v === null ? d : Number(v)
  } catch {
    return d
  }
}
const saveNum = (k: string, v: number) => {
  try {
    localStorage.setItem(k, String(v))
  } catch {
    /* ignore */
  }
}
const PF_DEFAULT = { seek: 10, hold: 2, hide: 3200, flip: false, zoom: 100 }
type Pf = typeof PF_DEFAULT
const loadPf = (): Pf => {
  try {
    return { ...PF_DEFAULT, ...JSON.parse(localStorage.getItem('zp-pf') || '{}') }
  } catch {
    return PF_DEFAULT
  }
}
type SheetName = null | 'subs' | 'set' | 'eps' | 'report'
type PopName = null | 'spd' | 'q' | 'cc' | 'aud' | 'srv'
interface Track {
  id: string
  label: string
  language: string
  url?: string
  source?: string
  cues?: Cue[]
  referer?: string
}

export interface PlayerServer {
  id: string
  name: string
  note: string
  /** extension requirement shown under the server name */
  access?: ServerAccess
  tags?: string[]
  disabled?: boolean
}

export interface CinePlayerProps {
  streamUrl?: string
  /** Optional sanitized embed URL (e.g. CinemaOS Priority #1 frame) rendered inside CinePlayer */
  embedUrl?: string | null
  embedSandboxed?: boolean
  intro?: Seg
  recap?: Seg
  outro?: Seg
  title: string
  episode: number
  episodeTitle?: string
  totalEpisodes: number
  availableEpisodes?: number
  animeId: number
  season?: number
  format?: string | null
  directSubtitles?: { id: string; label: string; lang?: string; url: string }[]
  originalLanguage?: 'Japanese' | 'Chinese' | 'Korean'
  audioMode?: 'sub' | 'dub'
  hasDub?: boolean
  hasSub?: boolean
  audioLoading?: boolean
  preview?: boolean
  onAudio?: (m: 'sub' | 'dub') => void
  /** separate MP4 audio versions (language dubs) of a movie; each is its own stream */
  dubs?: { id: string; label: string; selected?: boolean }[]
  onDub?: (id: string) => void
  /** reports the stream's audio renditions (and the active one) so the page can list them; [] when the player goes away */
  onAudioTracks?: (tracks: { i: number; label: string; lang: string }[], active: number) => void
  /** page asks for a rendition; pass a fresh object per request */
  audioSel?: { i: number } | null
  /** false while the page's own tutorial is open, so the two don't overlap */
  tourReady?: boolean
  servers?: PlayerServer[]
  serverId?: string
  onServer?: (id: string) => void
  hasNextEpisode?: boolean
  hasPrevEpisode?: boolean
  onNextEpisode?: () => void
  onPrevEpisode?: () => void
  onSelectEpisode?: (n: number) => void
  onPlay?: () => void
  onEnded?: () => void
  /** called every few seconds while playing, for continue-watching */
  onProgress?: (pos: number, dur: number) => void
  autoNext?: boolean
  onAutoNext?: (v: boolean) => void
  autoSkip?: boolean
  onAutoSkip?: (v: boolean) => void
  /** what the "next" buttons really go to (they jump over filler when skipFiller is on); defaults to episode + 1 */
  nextEpisode?: number
  /** this episode is non-canon: shows its label and, for filler / recap, a skip button */
  episodeKind?: 'filler' | 'mixed' | 'recap'
  skipFiller?: boolean
  onSkipFiller?: (v: boolean) => void
  /** next episode's stream is being fetched; the player stays mounted (and fullscreen) meanwhile */
  switching?: boolean
  episodesInfo?: Map<number, EpInfo>
  fallbackImg?: string | null
  defaultRuntime?: number | null
  kinds?: Map<number, EpKind>
  onVideoRef?: (el: HTMLVideoElement | null) => void
  onDuration?: (dur: number) => void
  onPlayerAction?: (action: { type: 'play' | 'pause' | 'seek'; time: number }) => void
  externalControl?: {
    action: 'play' | 'pause' | 'seek'
    time: number
    token: number
  } | null
  onWatchTogetherClick?: () => void
  watchPartyActive?: boolean
  watchPartyPeersCount?: number
  /** When watching together in a room as a guest (non-host), timestamp and episode changes are host-controlled */
  isPartyGuest?: boolean
  qualities?: {
    label: string
    url: string
    size?: number
    sizeLabel?: string | null
    downloadUrl?: string
  }[]
  currentQuality?: string
  onQualityChange?: (quality: { label: string; url: string; size?: number; sizeLabel?: string | null; downloadUrl?: string }) => void
  downloadUrl?: string
  fallbackStreamUrl?: string
  isTmdb?: boolean
  /** called when the direct stream fails to load (e.g. dead URL, CORS, DNS error) */
  onStreamError?: () => void
  /** episode numbers that have already been watched */
  watchedEps?: Set<number>
}

function Sheet({
  title,
  onClose,
  target,
  className,
  bodyClassName,
  dialog,
  children,
}: {
  title: string
  onClose: () => void
  target: HTMLElement
  className?: string
  bodyClassName?: string
  dialog?: boolean
  children: React.ReactNode
}) {
  return createPortal(
    <div
      className={cx('zp-sw', dialog && 'zp-sw-dlg')}
      onClick={onClose}
      onWheel={(e) => e.stopPropagation()}
      onTouchMove={(e) => e.stopPropagation()}
    >
      <div className={cx('zp-sh', className)} role="dialog" aria-label={title} onClick={(e) => e.stopPropagation()}>
        <div className="zp-sh-h">
          <h4>{title}</h4>
          <button className="zp-b" style={{ '--s': '40px' } as React.CSSProperties} onClick={onClose} aria-label="Close">
            <X />
          </button>
        </div>
        <div className={cx('zp-sh-b', bodyClassName)}>{children}</div>
      </div>
    </div>,
    target,
  )
}

function Episodes({
  total,
  available,
  current,
  episodesInfo,
  fallbackImg,
  defaultRuntime,
  kinds,
  watchedEps,
  onPick,
}: {
  total: number
  available: number
  current: number
  episodesInfo?: Map<number, EpInfo>
  fallbackImg?: string | null
  defaultRuntime?: number | null
  kinds?: Map<number, EpKind>
  watchedEps?: Set<number>
  onPick: (n: number) => void
}) {
  const pages = Math.ceil(total / EP_PAGE)
  const [page, setPage] = useState(() => Math.max(0, Math.min(pages - 1, Math.floor(((current ?? 1) - 1) / EP_PAGE))))
  const [q, setQ] = useState('')
  const [dropOpen, setDropOpen] = useState(false)
  const dropRef = useRef<HTMLDivElement>(null)
  const listRef = useRef<HTMLDivElement>(null)
  const currentItemRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    if (!dropOpen) return
    const onDown = (e: MouseEvent | TouchEvent) => {
      if (dropRef.current && !dropRef.current.contains(e.target as Node)) {
        setDropOpen(false)
      }
    }
    document.addEventListener('pointerdown', onDown)
    return () => document.removeEventListener('pointerdown', onDown)
  }, [dropOpen])

  useEffect(() => {
    listRef.current?.scrollTo({ top: 0, behavior: 'smooth' })
  }, [page, q])

  useEffect(() => {
    const container = listRef.current
    const item = currentItemRef.current
    if (container && item) {
      container.scrollTop = Math.max(0, item.offsetTop - container.clientHeight / 2 + item.offsetHeight / 2)
    }
  }, [])

  const from = page * EP_PAGE + 1
  const to = Math.min(total, from + EP_PAGE - 1)

  const ranges = useMemo(() => {
    return Array.from({ length: pages }, (_, i) => ({
      index: i,
      label: `Episodes ${i * EP_PAGE + 1} – ${Math.min(total, (i + 1) * EP_PAGE)}`,
      short: `${i * EP_PAGE + 1} – ${Math.min(total, (i + 1) * EP_PAGE)}`,
    }))
  }, [pages, total])

  const nums = useMemo(() => {
    const term = q.trim().toLowerCase()
    let list = Array.from({ length: total }, (_, i) => i + 1)
    if (term) {
      const numMatch = term.replace(/^ep(isode)?\s*/i, '').trim()
      list = list
        .filter((n) => {
          if (numMatch && String(n) === numMatch) return true
          if (String(n) === term) return true
          const epName = episodesInfo?.get(n)?.name
          return epName ? epName.toLowerCase().includes(term) : false
        })
        .slice(0, 100)
    } else {
      list = list.slice(from - 1, to)
    }
    return list
  }, [q, total, from, to, episodesInfo])

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col">
      <div className="relative z-20 shrink-0 pb-3">
        <div className="flex items-center gap-2">
          <div className="relative min-w-0 flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-white/40" />
            <input
              type="text"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search episode or title…"
              aria-label="Search episodes"
              className="h-8 w-full rounded-lg border border-white/10 bg-white/5 pl-8 pr-7 text-xs text-white placeholder:text-white/40 outline-none transition focus:border-white/30"
            />
            {q && (
              <button
                type="button"
                onClick={() => setQ('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-0.5 text-white/40 hover:text-white"
                aria-label="Clear search"
              >
                <X className="size-3" />
              </button>
            )}
          </div>

          {pages > 1 && !q && (
            <div ref={dropRef} className="relative shrink-0 sm:w-44">
              <button
                type="button"
                onClick={() => setDropOpen((o) => !o)}
                aria-haspopup="listbox"
                aria-expanded={dropOpen}
                className="flex h-8 w-full items-center justify-between gap-1.5 rounded-lg border border-white/10 bg-white/5 px-2.5 text-xs font-medium text-white transition hover:bg-white/10"
              >
                <span className="truncate">{ranges[page]?.short ?? 'Range'}</span>
                <ChevronDown className={cx('size-3.5 shrink-0 text-white/50 transition-transform duration-200', dropOpen && 'rotate-180')} />
              </button>

              {dropOpen && (
                <div
                  role="listbox"
                  className="absolute right-0 top-full mt-1.5 z-30 max-h-[min(58dvh,420px)] w-48 overflow-y-auto rounded-lg border border-white/10 bg-[#121218] p-1 shadow-xl scrollbar-thin"
                >
                  {ranges.map((r) => (
                    <button
                      key={r.index}
                      role="option"
                      aria-selected={r.index === page}
                      type="button"
                      onClick={() => {
                        setPage(r.index)
                        setDropOpen(false)
                        listRef.current?.scrollTo({ top: 0, behavior: 'smooth' })
                      }}
                      className={cx(
                        'flex w-full items-center justify-between rounded-md px-2.5 py-1.5 text-xs font-medium transition',
                        r.index === page
                          ? 'bg-white/10 font-semibold text-white'
                          : 'text-white/75 hover:bg-white/5 hover:text-white'
                      )}
                    >
                      <span>{r.label}</span>
                      {r.index === page && <Check className="size-3 shrink-0" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="mt-2 flex items-center justify-between text-[11px] text-white/45 px-0.5">
          <span>{q ? `${nums.length} match${nums.length === 1 ? '' : 'es'} found` : `Showing ${from}–${to} of ${total} episodes`}</span>
          {pages > 1 && !q && <span className="text-[10px] uppercase tracking-wider text-white/35">Page {page + 1}/{pages}</span>}
        </div>
      </div>

      <div
        ref={listRef}
        tabIndex={0}
        aria-label="Episodes list"
        className="flex-1 min-h-0 overflow-y-auto overscroll-contain pr-1 space-y-1 scrollbar-thin outline-none"
      >
        {nums.length === 0 ? (
          <div className="rounded-lg border border-dashed border-white/10 p-6 text-center text-xs text-white/40">
            No episodes found matching "{q}".
          </div>
        ) : (
          nums.map((n) => {
            const e = episodesInfo?.get(n)
            const aired = n <= available
            const on = n === current
            const img = e?.image ?? fallbackImg ?? null
            const mins = e?.runtime ?? defaultRuntime
            const air = fmtAir(e?.air ?? null)
            const kind = kinds?.get(n)
            const isEpWatched = Boolean(watchedEps?.has(n))
            const name = e?.name ?? `Episode ${n}`

            return (
              <button
                key={n}
                ref={on ? currentItemRef : undefined}
                type="button"
                onClick={() => onPick(n)}
                disabled={!aired}
                aria-current={on ? 'true' : undefined}
                className={cx(
                  'group flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left transition',
                  on
                    ? 'bg-white/10 text-white'
                    : 'text-white/80 hover:bg-white/5 hover:text-white',
                  !aired && 'cursor-not-allowed opacity-35 hover:bg-transparent'
                )}
              >
                <div className="relative aspect-video w-24 sm:w-28 shrink-0 overflow-hidden rounded-md bg-white/5">
                  {img ? (
                    <img
                      src={img}
                      alt=""
                      loading="lazy"
                      decoding="async"
                      className={cx(
                        'h-full w-full object-cover transition-opacity duration-200',
                        !e?.image && 'opacity-60'
                      )}
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-white/5 text-[10px] font-bold text-white/40">
                      EP {n}
                    </div>
                  )}
                  <span aria-hidden className="absolute inset-0 z-[1] bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                  {kind && KIND[kind] && (
                    <span
                      className={cx(
                        'absolute left-1 top-1 z-[4] rounded px-1 py-0.2 text-[8.5px] font-bold uppercase',
                        KIND[kind].cls
                      )}
                    >
                      {KIND[kind].label}
                    </span>
                  )}
                  {isEpWatched && <WatchedThumbOverlay size="xs" showReplay={!on} />}
                  <span className="absolute bottom-1 left-1.5 z-[4] font-display text-xs font-bold text-white">
                    {n}
                  </span>
                  {aired && (!isEpWatched || on) && (
                    <span
                      className={cx(
                        'absolute bottom-1 right-1 z-[4] grid size-5 place-items-center rounded bg-black/60 text-white',
                        on && 'bg-[var(--a,#dc143c)] text-white'
                      )}
                    >
                      {on ? <AudioLines className="size-2.5" /> : <Play className="size-2 fill-current" />}
                    </span>
                  )}
                </div>

                <div className="min-w-0 flex-1 py-0.5">
                  <p
                    className={cx(
                      'line-clamp-1 text-xs leading-snug font-medium',
                      on ? 'text-white font-semibold' : 'text-white/90 group-hover:text-white'
                    )}
                  >
                    {name}
                  </p>
                  <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-white/45">
                    <span>Ep {n}</span>
                    {mins ? <span>· {mins}m</span> : null}
                    {air && <span>· {air}</span>}
                    {kind && KIND[kind] && (
                      <span className="text-[10px] font-medium text-amber-400">
                        · {KIND[kind].label}
                      </span>
                    )}
                    {!aired && (
                      <span className="text-[10px] text-white/30">
                        · Not aired
                      </span>
                    )}
                    {on && (
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--a2,#ff4d6a)]">
                        · Playing
                      </span>
                    )}
                    {isEpWatched && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400">
                        · <Check className="size-2.5 stroke-[3]" /> Watched
                      </span>
                    )}
                  </div>
                  {e?.overview && (
                    <p className="mt-0.5 line-clamp-1 text-[11px] leading-relaxed text-white/35">
                      {e.overview}
                    </p>
                  )}
                </div>
              </button>
            )
          })
        )}
      </div>
    </div>
  )
}

/** Plain files (mp4 / webm / mkv / hakunaymatata direct CDN) bypass hls.js; the proxied url keeps the real one in ?url= */
const isFileSrc = (u: string) => isDirectFileMediaUrl(u)
const stripSegParam = (u: string) => u.replace(/([?&])seg=1(&|$)/, (_m, a, b) => (b ? a : ''))
const ALANG = 'zp-alang'
const readAlang = () => {
  try {
    return localStorage.getItem(ALANG) || ''
  } catch {
    return ''
  }
}

const formatLangLabel = (code: string) => {
  const clean = (code || '').trim()
  if (!clean) return 'your preferred language'
  const mapped = ISO[clean.toLowerCase()]
  if (mapped) return mapped
  try {
    const dn = new Intl.DisplayNames(['en'], { type: 'language' }).of(clean)
    if (dn && dn.toLowerCase() !== clean.toLowerCase()) return dn
  } catch {
    /* ignore */
  }
  return clean.charAt(0).toUpperCase() + clean.slice(1)
}

const hasIdentifiableLang = (t: { label: string; lang: string }) => {
  const l = t.label.trim().toLowerCase()
  const g = t.lang.trim().toLowerCase()
  if (g && g !== 'und' && g !== 'unknown') return true
  if (!l) return false
  if (/^(track|audio|stream|default|main|dub|sub)(\s*#?\d+)?$/i.test(l)) return false
  return true
}

/** Preferred quality (Profile page): 0 = auto. */
const readMaxQuality = () => {
  try {
    return Number(localStorage.getItem('zp-q')) || 0
  } catch {
    return 0
  }
}

const readScopedPos = (id: number, ep: number, season = 1, isTmdb = false) => {
  try {
    const k = buildPosStorageKey({ mediaId: id, episode: ep, season, isTmdb })
    const v = Number(localStorage.getItem(k))
    if (v > 0) return v
    if (isTmdb && season === 1) {
      return Number(localStorage.getItem(`zk:pos:${id}:${ep}`)) || 0
    }
    return 0
  } catch {
    return 0
  }
}

const clearScopedPos = (id: number, ep: number, season = 1, isTmdb = false) => {
  try {
    localStorage.removeItem(buildPosStorageKey({ mediaId: id, episode: ep, season, isTmdb }))
    if (isTmdb && season === 1) {
      localStorage.removeItem(`zk:pos:${id}:${ep}`)
    }
  } catch {
    /* storage unavailable */
  }
}

const persistOrClearScopedPos = (
  id: number,
  ep: number,
  season: number,
  isTmdb: boolean,
  ct: number,
  du: number,
  ended = false,
) => {
  if (!id) return
  try {
    const key = buildPosStorageKey({ mediaId: id, episode: ep, season, isTmdb })
    if (ended || (du > 0 && isNearOrAtPlaybackEnd(ct, du, ended))) {
      localStorage.removeItem(key)
      if (isTmdb && season === 1) localStorage.removeItem(`zk:pos:${id}:${ep}`)
    } else if (shouldPersistPlaybackPosition(ct, du)) {
      localStorage.setItem(key, String(Math.floor(ct)))
    }
  } catch {
    /* storage unavailable */
  }
}

export default function CinePlayer({
  streamUrl: streamUrlInput = '', embedUrl: embedUrlInput = null, embedSandboxed = false, intro, recap, outro, title, episode, episodeTitle = '', totalEpisodes, availableEpisodes, animeId, season = 1, format,
  directSubtitles = [], originalLanguage = 'Japanese', audioMode = 'sub', hasDub = true, hasSub = true, audioLoading = false, preview = false, onAudio, dubs, onDub, onAudioTracks, audioSel, tourReady: _tourReady = true, servers, serverId, onServer,
  hasNextEpisode = false, hasPrevEpisode = false, onNextEpisode, onPrevEpisode, onSelectEpisode, onPlay, onEnded, onProgress,
  autoNext: _autoNext = true, onAutoNext: _onAutoNext, autoSkip = false, onAutoSkip: _onAutoSkip,
  nextEpisode, episodeKind, skipFiller = false, onSkipFiller, switching = false,
  episodesInfo, fallbackImg, defaultRuntime, kinds,
  onVideoRef, onDuration, onPlayerAction, externalControl, onWatchTogetherClick, watchPartyActive, watchPartyPeersCount,
  isPartyGuest = false,
  qualities, currentQuality, onQualityChange, fallbackStreamUrl: fallbackStreamUrlInput, isTmdb = false, onStreamError, watchedEps,
}: CinePlayerProps) {
  const streamUrl = resolveNativeApiPath(streamUrlInput)
  const fallbackStreamUrl = resolveNativeApiPath(fallbackStreamUrlInput)
  const embedUrl = resolveNativeApiPath(embedUrlInput) || null
  const origLang: 'Japanese' | 'Chinese' | 'Korean' = originalLanguage || 'Japanese'
  const origSubLabel = `${origLang} (Original)`
  const origDetailLabel = `${origLang} (Original)`
  const isMovie = format === 'MOVIE' || (totalEpisodes <= 1 && format !== 'TV')
  const cleanEpTitle = episodeTitle?.trim()
  const hasDistinctEpTitle = !!(
    cleanEpTitle &&
    cleanEpTitle !== String(episode) &&
    !(() => {
      const m = cleanEpTitle.match(/^(?:ep(?:isode)?\.?|ch(?:apter)?\.?)\s*0*(\d+)$/i)
      return m && Number(m[1]) === Number(episode)
    })()
  )
  const vid = useRef<HTMLVideoElement>(null)
  const root = useRef<HTMLDivElement>(null)
  const isExternalAction = useRef(false)
  const wantPlayRef = useRef(true)
  const audioSwitchLock = useRef(0)

  useEffect(() => {
    onVideoRef?.(vid.current)
    return () => onVideoRef?.(null)
  }, [onVideoRef])

  useEffect(() => {
    if (!externalControl || !vid.current) return
    isExternalAction.current = true
    const v = vid.current
    if (externalControl.action === 'seek') {
      v.currentTime = externalControl.time
      setTime(externalControl.time)
    } else if (externalControl.action === 'play') {
      wantPlayRef.current = true
      if (Math.abs(v.currentTime - externalControl.time) > 1.2) {
        v.currentTime = externalControl.time
      }
      void v.play().catch(() => {})
    } else if (externalControl.action === 'pause') {
      wantPlayRef.current = false
      if (Math.abs(v.currentTime - externalControl.time) > 1.2) {
        v.currentTime = externalControl.time
      }
      v.pause()
      setBusy(false)
    }
    const t = setTimeout(() => {
      isExternalAction.current = false
    }, 180)
    return () => clearTimeout(t)
  }, [externalControl])
  const hls = useRef<Hls | null>(null)
  const triedFallback = useRef(false)
  const noSegRef = useRef(false)
  const lastEpKeyRef = useRef('')

  useEffect(() => {
    triedFallback.current = false
    noSegRef.current = false
  }, [streamUrl])

  // Player shortcut & context menu protection
  useEffect(() => {
    return attachPlayerSecurity(root.current, vid.current, { isPreview: preview })
  }, [preview])
  const bar = useRef<HTMLDivElement>(null)
  const file = useRef<HTMLInputElement>(null)
  const hideT = useRef(0)
  const fbT = useRef(0)
  const fbAt = useRef(0)
  const tok = useRef(0)
  const skipped = useRef(-1)
  const tap = useRef({ t: 0, side: 0, timer: 0, chainSide: 0, chainUntil: 0, revealedAt: 0 })
  const lastHandledTapAt = useRef(0)
  const lastPointerLifecycleAt = useRef(0)
  const uiPointerDownSeen = useRef(false)
  const gesture = useRef({
    pointers: new Map<number, { x: number; y: number; wasVisible: boolean; ts: number; type: string }>(),
    multi: false,
    moved: false,
  })
  const unlockAt = useRef(0)
  const unlockTimer = useRef(0)
  const [revealLock, setRevealLock] = useState(false)
  const lastTouchAt = useRef(0)
  const lastMousePos = useRef({ x: -1, y: -1 })
  const audioModeRef = useRef(audioMode)
  audioModeRef.current = audioMode
  const origLangRef = useRef(origLang)
  origLangRef.current = origLang
  const userPickedAudioRef = useRef(false)
  const autoAudioAttemptsRef = useRef(0)
  const st = useRef({ playing: false, sheet: null as SheetName, pop: null as PopName, show: true })
  const api = useRef({ togglePlay: () => {}, toggleMute: () => {}, toggleFs: () => {}, poke: () => {}, doSkip: () => {}, skipOn: false, v: 1 })

  const [playing, setPlaying] = useState(false)
  const [fillAsk, setFillAsk] = useState(false) // "Skip filler?" prompt: asked once per episode, then gone
  const [time, setTime] = useState(0)
  const [dur, setDur] = useState(0)
  const [buf, setBuf] = useState(0)
  const [vol, setVol] = useState(() => clamp(readNum('zp-vol', 1), 0, 1))
  const [muted, setMuted] = useState(() => readNum('zp-mute', 0) === 1)
  const [speed, setSpeed] = useState(1)
  const [show, setShow] = useState(true)
  const [busy, setBusy] = useState(true)
  const [mediaReady, setMediaReady] = useState(false)
  const [playbackReady, setPlaybackReady] = useState(false)
  const [err, setErr] = useState(false)
  const [retry, setRetry] = useState(0)
  const [isFs, setIsFs] = useState(false)
  const [fake, setFake] = useState(false)
  const fakeRef = useRef(false)
  fakeRef.current = fake
  const [rot90, setRot90] = useState(false)
  const rot90Ref = useRef(false)
  rot90Ref.current = rot90
  const stageRef = useRef<HTMLDivElement>(null)
  const fsSessionRef = useRef(0)
  const autoFs = useRef(false)
  const [, setPip] = useState(false)
  const cst = useCast()
  const casting = cst.status === 'connected'
  const castOn = useRef(false)
  castOn.current = casting
  const canCast = !preview && !watchPartyActive
  const airplay = airplaySupported()
  const castAvail = cst.status === 'ready' || cst.status === 'connecting' || cst.status === 'connected' || airplay
  const castLoadedFor = useRef<string | null>(null)
  const castLast = useRef({ time: 0, playing: false })
  const wasCasting = useRef(false)
  const [hover, setHover] = useState<number | null>(null)
  const pv = useRef<HTMLVideoElement>(null) // seek-bar preview video (muted, lowest quality, starts on first hover)
  const pvT = useRef<number | null>(null)
  const [pvOn, setPvOn] = useState(false)
  const [pvRdy, setPvRdy] = useState(false)
  const [scrub, setScrub] = useState<number | null>(null)
  const lastTimeRef = useRef<number>(0)
  const hasEndedRef = useRef<boolean>(false)
  const [levels, setLevels] = useState<{ i: number; label: string; sub?: string; url?: string }[]>([])
  const [lvl, setLvl] = useState(-1)
  const [audioTracks, setAudioTracks] = useState<{ i: number; label: string; lang: string }[]>([])
  const [audioIdx, setAudioIdx] = useState(0)
  const [savedPrefLang, setSavedPrefLang] = useState(() => readAlang())
  const [dismissedLangPrompt, setDismissedLangPrompt] = useState<string | null>(null)
  const [fb, setFb] = useState<{ side: number; n: number; k: number } | null>(null)
  const [sheet, setSheet] = useState<SheetName>(null)
  const [capTab, setCapTab] = useState<'presets' | 'font' | 'text' | 'box' | 'sync'>('presets')
  const [capCat, setCapCat] = useState<string>('all')
  const [pop, setPopRaw] = useState<PopName>(null)
  const [grp, setGrp] = useState<string | null>('English')
  const [subSearch, setSubSearch] = useState('')
  const [note, setNote] = useState<{ k: 'load' | 'ok' | 'err'; msg: string } | null>(null)
  const [srcLeft, setSrcLeft] = useState(0) // other servers still being asked for captions
  const noteTimer = useRef(0)
  const [held, setHeld] = useState(false)
  const hold = useRef({ timer: 0, on: false, prev: 1 })
  const [popAnchor, setPopAnchor] = useState<{ left?: number; right?: number; top?: number; bottom?: number; maxHeight?: number; fixed?: boolean } | null>(null)
  const lastAnchor = useRef<{ left?: number; right?: number; top?: number; bottom?: number; maxHeight?: number; fixed?: boolean } | null>(null)
  if (popAnchor) lastAnchor.current = popAnchor
  const activeAnchor = popAnchor || lastAnchor.current
  const popRef = useRef<HTMLDivElement>(null)

  const closePop = () => {
    setPopRaw(null)
  }
  const setPop = (p: PopName, target?: HTMLElement | null) => {
    setPopRaw((c) => {
      if (c === p || !p) {
        return null
      }
      const fsNow = Boolean(
        isFs ||
        fakeRef.current ||
        (getFullscreenElement() && root.current && (getFullscreenElement() === root.current || root.current.contains(getFullscreenElement()))),
      )
      const container = stageRef.current || root.current
      if (target && !fsNow) {
        const btnRect = target.getBoundingClientRect()
        const maxW = p === 'cc' ? Math.min(360, window.innerWidth - 16) : Math.min(280, window.innerWidth - 16)
        const spaceBelow = Math.max(0, Math.floor(window.innerHeight - btnRect.bottom - 16))
        const spaceAbove = Math.max(0, Math.floor(btnRect.top - 16))
        const openUp = spaceAbove > spaceBelow && spaceBelow < 260
        const anchor: { left?: number; right?: number; top?: number; bottom?: number; maxHeight?: number; fixed?: boolean } = {
          fixed: true,
          maxHeight: Math.max(180, Math.min(480, openUp ? spaceAbove : spaceBelow)),
        }
        if (openUp) {
          anchor.bottom = Math.max(8, Math.round(window.innerHeight - btnRect.top + 8))
        } else {
          anchor.top = Math.max(8, Math.round(btnRect.bottom + 8))
        }
        const isLeft = btnRect.left + btnRect.width / 2 < window.innerWidth / 2
        if (isLeft) {
          anchor.left = Math.max(8, Math.min(window.innerWidth - maxW - 8, Math.round(btnRect.left)))
        } else {
          anchor.right = Math.max(8, Math.min(window.innerWidth - maxW - 8, Math.round(window.innerWidth - btnRect.right)))
        }
        setPopAnchor(anchor)
        lastAnchor.current = anchor
      } else if (target && container) {
        const rootRect = container.getBoundingClientRect()
        const btnRect = target.getBoundingClientRect()
        const maxW = p === 'cc' ? 360 : 260
        const anchor: { left?: number; right?: number; top?: number; bottom?: number; maxHeight?: number; fixed?: boolean } = {}
        if (rot90Ref.current) {
          const visW = rootRect.height
          const visTop = rootRect.right - btnRect.right
          const visBottomFromTop = rootRect.right - btnRect.left
          const visLeft = btnRect.top - rootRect.top
          const visRight = btnRect.bottom - rootRect.top
          const isTop = visTop < rootRect.width / 2
          const isLeft = (visLeft + visRight) / 2 < visW / 2
          if (isTop) {
            anchor.top = Math.max(8, Math.round(visBottomFromTop + 8))
          } else {
            anchor.bottom = Math.max(48, Math.round(rootRect.width - visTop + 8))
          }
          if (isLeft) {
            const maxLeft = Math.max(8, Math.round(visW - maxW - 8))
            anchor.left = Math.max(8, Math.min(maxLeft, Math.round(visLeft)))
          } else {
            const maxRight = Math.max(8, Math.round(visW - maxW - 8))
            anchor.right = Math.max(8, Math.min(maxRight, Math.round(rootRect.bottom - btnRect.bottom)))
          }
        } else {
          const isTop = (btnRect.top - rootRect.top) < (rootRect.height / 2)
          const isLeft = (btnRect.left + btnRect.width / 2 - rootRect.left) < (rootRect.width / 2)

          if (isTop) {
            anchor.top = Math.max(8, Math.round(btnRect.bottom - rootRect.top + 8))
          } else {
            anchor.bottom = Math.max(48, Math.round(rootRect.bottom - btnRect.top + 8))
          }

          if (isLeft) {
            const maxLeft = Math.max(8, Math.round(rootRect.width - maxW - 8))
            anchor.left = Math.max(8, Math.min(maxLeft, Math.round(btnRect.left - rootRect.left)))
          } else {
            const maxRight = Math.max(8, Math.round(rootRect.width - maxW - 8))
            anchor.right = Math.max(8, Math.min(maxRight, Math.round(rootRect.right - btnRect.right)))
          }
        }
        setPopAnchor(anchor)
        lastAnchor.current = anchor
      } else {
        setPopAnchor(null)
      }
      return p
    })
  }

  useEffect(() => {
    if (!pop) return
    const onDown = (e: PointerEvent) => {
      if (popRef.current && !popRef.current.contains(e.target as Node)) {
        const target = e.target as HTMLElement | null
        if (target?.closest?.('.zp-b, .zp-btn, [data-tour]')) return
        closePop()
      }
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closePop()
    }
    const onScrollOrResize = (e: Event) => {
      if (e.type === 'scroll' && popRef.current?.contains(e.target as Node)) return
      if (lastAnchor.current?.fixed) closePop()
    }
    window.addEventListener('pointerdown', onDown)
    window.addEventListener('keydown', onKey)
    window.addEventListener('scroll', onScrollOrResize, true)
    window.addEventListener('resize', onScrollOrResize)
    return () => {
      window.removeEventListener('pointerdown', onDown)
      window.removeEventListener('keydown', onKey)
      window.removeEventListener('scroll', onScrollOrResize, true)
      window.removeEventListener('resize', onScrollOrResize)
    }
  }, [pop])
  const [reportIssue, setReportIssue] = useState('Broken / Won\'t Play')
  const [reportDetails, setReportDetails] = useState('')
  const [reportSubmitting, setReportSubmitting] = useState(false)
  const [reportSuccess, setReportSuccess] = useState<string | null>(null)
  const [tracks, setTracks] = useState<Track[]>([])
  const [trackId, setTrackId] = useState<string | null>(null)
  const [cues, setCues] = useState<Cue[]>([])
  const [caps, setCaps] = useState(audioMode === 'sub')
  const [offset, setOffset] = useState(0) // subtitle delay in seconds (+ = later)
  const [up, setUpRaw] = useState(() => gpuSupported && readNum('zp-up', 0) === 1)
  const [upInt, setUpIntRaw] = useState(() => readNum('zp-upi', 100))
  const [upMode, setUpModeRaw] = useState<Anime4KMode>(() => {
    const m = (typeof localStorage !== 'undefined' ? localStorage.getItem('zp-upm') : null) as Anime4KMode
    return m && ['modeA', 'modeB', 'modeC', 'modeAA', 'denoise', 'fast'].includes(m) ? m : 'modeA'
  })
  const [upErr, setUpErr] = useState<string | null>(null)
  const [vkey, setVkey] = useState(0)
  const cv = useRef<HTMLCanvasElement>(null)
  const setUp = (on: boolean) => {
    setUpErr(null)
    setUpRaw(on)
    saveNum('zp-up', on ? 1 : 0)
  }
  const setUpInt = (n: number) => {
    setUpIntRaw(n)
    saveNum('zp-upi', n)
  }
  const setUpMode = (m: Anime4KMode) => {
    setUpErr(null)
    setUpModeRaw(m)
    try {
      localStorage.setItem('zp-upm', m)
    } catch {}
  }
  const [vfx, setVfxRaw] = useState<VideoFilters>(loadVideoFilters)
  const setVfx = (patch: Partial<VideoFilters>) => {
    setVfxRaw((p) => {
      const next = { ...p, ...patch }
      try {
        localStorage.setItem('zp-vfx', JSON.stringify(next))
      } catch {}
      return next
    })
  }

  const videoFilterStyle = useMemo(() => {
    const list: string[] = []
    if (vfx.preset === 'vibrant') {
      list.push('saturate(1.28) contrast(1.06) brightness(1.02)')
    } else if (vfx.preset === 'cinema') {
      list.push('contrast(1.18) saturate(1.1) brightness(0.98)')
    } else if (vfx.preset === 'sharp') {
      list.push('contrast(1.14) brightness(1.02)')
    } else if (vfx.preset === 'warm') {
      list.push('sepia(0.2) saturate(1.08) brightness(0.98)')
    }
    if (vfx.brightness !== 100) list.push(`brightness(${vfx.brightness}%)`)
    if (vfx.contrast !== 100) list.push(`contrast(${vfx.contrast}%)`)
    if (vfx.saturation !== 100) list.push(`saturate(${vfx.saturation}%)`)
    return list.length ? list.join(' ') : undefined
  }, [vfx])
  const [pf, setPfRaw] = useState<Pf>(loadPf)
  const pfRef = useRef(pf)
  pfRef.current = pf
  const setPf = (p: Partial<Pf>) =>
    setPfRaw((c) => {
      const n = { ...c, ...p }
      try {
        localStorage.setItem('zp-pf', JSON.stringify(n))
      } catch {}
      return n
    })
  const [setTab, setSetTab] = useState<'video' | 'picture' | 'play' | 'cast'>('video')
  const [ar, setArRaw] = useState<Aspect>(loadAspect)
  const setAr = (a: Aspect) => {
    setArRaw(a)
    try {
      localStorage.setItem('zp-ar', a)
    } catch {
      /* ignore */
    }
  }
  const [cs, setCsRaw] = useState<CapStyle>(loadCap)
  const setCs = (p: Partial<CapStyle>) =>
    setCsRaw((c) => {
      const n = { ...c, ...p }
      try {
        localStorage.setItem('zp-cap', JSON.stringify(n))
      } catch {
        /* storage unavailable */
      }
      return n
    })
  const [loadingSubs, setLoadingSubs] = useState(false)
  const [subErr, setSubErr] = useState<string | null>(null)
  const [card, setCard] = useState(true)
const slider = (label: string, key: 'opacity' | 'lh' | 'width' | 'blur' | 'scale' | 'bg' | 'pos', min: number, max: number, step: number, unit = '%') => (
    <>
      <p className="zp-sec">{label} ({cs[key]}{unit})</p>
      <input
        type="range" className="zp-rg" min={min} max={max} step={step} value={cs[key]}
        style={{ '--p': `${((cs[key] - min) / (max - min)) * 100}%` } as CSSProperties}
        onChange={(e) => setCs({ [key]: +e.target.value })}
        aria-label={label}
      />
    </>
  )
  const swatch = (list: string[], key: 'color' | 'bgColor' | 'edgeColor') => (
    <>
      {list.map((c) => (
        <button
          key={c}
          className={cx('zp-pi zp-sw-c', cs[key] === c && 'on')}
          style={{ '--c': c, backgroundColor: c } as CSSProperties}
          onClick={() => setCs({ [key]: c })}
          aria-label={`${key} ${c}`}
        />
      ))}
      <label
        className="zp-pi zp-sw-c"
        style={{ '--c': 'conic-gradient(#f33,#fd3,#3f6,#3df,#36f,#f3d,#f33)', position: 'relative' } as CSSProperties}
        aria-label="Custom color"
      >
        <input
          type="color" value={cs[key]}
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0, cursor: 'pointer' }}
          onChange={(e) => setCs({ [key]: e.target.value })}
        />
      </label>
    </>
  )

  st.current = { playing, sheet, pop, show }

  // weak devices: html.zp-lite turns off every backdrop blur (see cineplayer.css)
  useEffect(() => {
    if (!LITE) return
    document.documentElement.classList.add('zp-lite')
    return () => document.documentElement.classList.remove('zp-lite')
  }, [])
  const armRevealLock = useCallback((ms = 420) => {
    unlockAt.current = Date.now() + ms
    setRevealLock(true)
    clearTimeout(unlockTimer.current)
    unlockTimer.current = window.setTimeout(() => setRevealLock(false), ms)
  }, [])
  useEffect(() => () => {
    clearTimeout(unlockTimer.current)
    clearTimeout(tap.current.timer)
  }, [])

  /* ── controls visibility: auto-hide (3s when playing, 5s when paused/buffering) ── */
  const poke = useCallback((timeout = 3000) => {
    st.current.show = true
    setShow(true)
    clearTimeout(hideT.current)
    const s = st.current
    if (!s.sheet && !s.pop) {
      const delay = s.playing ? timeout : 5000
      hideT.current = window.setTimeout(() => {
        if (!st.current.sheet && !st.current.pop) {
          st.current.show = false
          setShow(false)
          setRevealLock(false)
        }
      }, delay)
    }
  }, [])
  useEffect(() => {
    poke(3000)
    return () => clearTimeout(hideT.current)
  }, [playing, sheet, pop, poke])
  useEffect(() => {
    setCaps(audioMode === 'sub')
  }, [isTmdb, audioMode, animeId, episode])

  /* ── seek preview: tiny second video on the lowest level, only loads after the first hover ── */
  useEffect(() => {
    const p = pv.current
    setPvRdy(false)
    if (!pvOn || !p || !streamUrl) return
    const url = noSegRef.current ? stripSegParam(streamUrl) : streamUrl
    let h: Hls | null = null
    if (!isFileSrc(streamUrl) && Hls.isSupported()) {
      h = new Hls({ ...nativeHlsRequestConfig(), enableWorker: false, startLevel: 0, maxBufferLength: 2, maxMaxBufferLength: 4, backBufferLength: 0, capLevelToPlayerSize: false })
      h.loadSource(url)
      h.attachMedia(p)
      h.on(Hls.Events.MANIFEST_PARSED, () => {
        if (!h || !h.levels.length) return
        let low = 0
        h.levels.forEach((l: any, i: number) => {
          if ((l.bitrate || 0) < (h!.levels[low].bitrate || 0)) low = i
        })
        h.currentLevel = low
      })
      h.on(Hls.Events.ERROR, (_: any, d: any) => {
        if (d.fatal) {
          h?.destroy()
          h = null
        }
      })
    } else {
      p.src = url
    }
    return () => {
      h?.destroy()
      p.removeAttribute('src')
      p.load()
    }
  }, [pvOn, streamUrl, retry])

  /* ── HLS ── */
  useEffect(() => {
    const v = vid.current
    if (!v || !streamUrl) return
    wantPlayRef.current = true
    setBusy(true)
    setMediaReady(false)
    setPlaybackReady(false)
    setErr(false)
    setLevels([])
    setLvl(-1)
    setAudioTracks([])
    setAudioIdx(0)
    setTime(0)
    setDur(defaultRuntime && defaultRuntime > 0 ? defaultRuntime * 60 : 0)
    setBuf(0)
    setCard(true)
    skipped.current = -1
    resetGestures()
    let readyTimer = 0
    let stallTimer = 0
    hasEndedRef.current = false
    const epKey = `${isTmdb ? 'tmdb' : 'al'}:${season}:${animeId}:${episode}`
    const sameEpisode = lastEpKeyRef.current === epKey
    lastEpKeyRef.current = epKey
    if (!sameEpisode) lastTimeRef.current = 0
    const saved = readScopedPos(animeId, episode, season, isTmdb)
    const expectedDurSec = defaultRuntime && defaultRuntime > 0 ? defaultRuntime * 60 : 0
    const resumeTime = resolveResumePosition({
      savedPos: saved,
      livePos: lastTimeRef.current,
      sameEpisode,
      durationSec: 0,
      expectedDurationSec: expectedDurSec,
    })
    const onMeta = () => {
      window.clearTimeout(stallTimer)
      if (v.duration && isFinite(v.duration) && v.duration > 0) setDur(v.duration)
      else if (defaultRuntime && defaultRuntime > 0) setDur(defaultRuntime * 60)
      const effectiveDur = (v.duration && isFinite(v.duration) && v.duration > 0) ? v.duration : expectedDurSec
      const safeResume = resolveResumePosition({
        savedPos: saved,
        livePos: lastTimeRef.current,
        sameEpisode,
        durationSec: effectiveDur,
        expectedDurationSec: expectedDurSec,
      })
      if (safeResume > 10) {
        if (Math.abs(v.currentTime - safeResume) > 1.5) v.currentTime = safeResume
      } else {
        if (v.currentTime > 10 || startPos > 10) {
          v.currentTime = 0
          if (h) h.startLoad(0)
        }
        lastTimeRef.current = 0
        setTime(0)
        clearScopedPos(animeId, episode, season, isTmdb)
      }
      setMediaReady(true)
      if (v.readyState >= 2) {
        setPlaybackReady(true)
        setBusy(false)
      }
      if (!castOn.current) {
        if (wantPlayRef.current) {
          v.play()
            .then(() => {
              if (!wantPlayRef.current && !v.paused) v.pause()
              if (v.readyState >= 2) {
                setPlaybackReady(true)
                setBusy(false)
              }
            })
            .catch((playErr: any) => {
              if (playErr?.name === 'NotAllowedError') {
                wantPlayRef.current = false
                setPlaying(false)
                setBusy(false)
              } else if (v.readyState >= 2) {
                setPlaybackReady(true)
                setBusy(false)
              }
              poke(4000)
            })
        } else {
          v.pause()
          setPlaying(false)
          if (v.readyState >= 2) setBusy(false)
        }
      }
    }

    if (isFileSrc(streamUrl) && qualities && qualities.length > 0) {
      const qLevels = qualities.map((q, idx) => ({
        i: idx,
        label: q.label,
        sub: q.sizeLabel || undefined,
        url: q.url,
      }))
      setLevels(qLevels)
      const curIdx = qLevels.findIndex(
        (l) => (currentQuality && l.label.toLowerCase() === currentQuality.toLowerCase()) || l.url === streamUrl
      )
      setLvl(curIdx >= 0 ? curIdx : 0)
    }
    let h: Hls | null = null
    let fails = 0
    const startPos = resumeTime


    // Clean up previous media state on the HTMLVideoElement so new episode doesn't inherit old buffers or ended state
    try {
      v.pause()
      if (hls.current) {
        hls.current.stopLoad()
        hls.current.detachMedia()
        hls.current.destroy()
        hls.current = null
      }
      v.removeAttribute('src')
      v.load()
      v.currentTime = startPos > 0 ? startPos : 0
    } catch {}

    const armStallWatchdog = (timeoutMs = 14000) => {
      window.clearTimeout(stallTimer)
      stallTimer = window.setTimeout(() => {
        if (castOn.current) return
        if (fallbackStreamUrl && fallbackStreamUrl !== streamUrl && !triedFallback.current) {
          triedFallback.current = true
          if (hls.current) {
            hls.current.loadSource(fallbackStreamUrl)
            hls.current.startLoad()
          } else if (v) {
            v.src = fallbackStreamUrl
            v.load()
            v.play().catch(() => {})
          }
          armStallWatchdog(timeoutMs)
          return
        }
        window.clearTimeout(readyTimer)
        try {
          hls.current?.stopLoad()
          hls.current?.destroy()
        } catch {}
        hls.current = null
        setErr(true)
        setBusy(false)
        setMediaReady(true)
        onStreamError?.()
      }, timeoutMs)
    }

    if (!isFileSrc(streamUrl) && Hls.isSupported()) {
      h = new Hls({
        ...nativeHlsRequestConfig(),
        enableWorker: true,
        backBufferLength: 30,
        maxBufferLength: 30,
        maxMaxBufferLength: 60,
        maxBufferSize: 60 * 1000 * 1000,
        startPosition: startPos,
        manifestLoadingMaxRetry: 1,
        manifestLoadingRetryDelay: 500,
        levelLoadingMaxRetry: 1,
        levelLoadingRetryDelay: 500,
        fragLoadingMaxRetry: 2,
        fragLoadingRetryDelay: 500,
        fragLoadingTimeOut: 12000,
        manifestLoadingTimeOut: 10000,
        levelLoadingTimeOut: 10000,
      })
      hls.current = h
      armStallWatchdog(15000)
      v.addEventListener('loadedmetadata', onMeta)
      h.loadSource(noSegRef.current ? stripSegParam(streamUrl) : streamUrl)
      h.attachMedia(v)
      h.on(Hls.Events.FRAG_LOADED, () => {
        fails = 0
        window.clearTimeout(stallTimer)
        window.clearTimeout(readyTimer)
        setBusy(false)
        setMediaReady(true)
        if (v.readyState >= 2) setPlaybackReady(true)
      })
      userPickedAudioRef.current = false
      autoAudioAttemptsRef.current = 0
      h.on(Hls.Events.MANIFEST_PARSED, (_: any, d: any) => {
        const all = (d.levels || []).map((l: any, i: number) => ({ i, h: l.height || 0, br: l.bitrate || 0, label: l.height ? `${l.height}p` : `Level ${i + 1}` }))
        // one entry per height (a stream can list several codecs of the same size): keep the richest
        const list = all.filter((l: any) => !l.h || !all.some((o: any) => o.h === l.h && o.br > l.br)).sort((a: any, b: any) => b.h - a.h)
        setLevels(list)
        // Profile → "Preferred quality": start locked on that height (or the closest one below it); Auto stays one tap away
        const want = readMaxQuality()
        const pick = want ? list.find((l: any) => l.h && l.h <= want) ?? list[list.length - 1] : null
        if (pick && h) {
          h.currentLevel = pick.i
          setLvl(pick.i)
        }
        if (h?.audioTracks && h.audioTracks.length > 0) {
          const aList = h.audioTracks.map((t: any, i: number) => ({ i, label: formatHlsTrackLabel(t, i, origLangRef.current), lang: t.lang || '' }))
          setAudioTracks(aList)
          const target = findTrackForMode(aList, audioModeRef.current, readAlang(), origLangRef.current)
          if (target) {
            if (h.audioTrack !== target.i) h.audioTrack = target.i
            setAudioIdx(target.i)
          }
          if (aList.length > 1) {
            window.clearTimeout(readyTimer)
            setMediaReady(true)
          }
        }
        window.clearTimeout(readyTimer)
        if (!(h?.audioTracks && h.audioTracks.length > 1)) {
          readyTimer = window.setTimeout(() => setMediaReady(true), 900)
        }
        if (castOn.current) h?.stopLoad() // the TV is playing: don't download the same stream here
        else if (wantPlayRef.current) {
          v.play()
            .then(() => {
              if (!wantPlayRef.current && !v.paused) v.pause()
              if (v.readyState >= 2) {
                setPlaybackReady(true)
                setBusy(false)
              }
            })
            .catch((playErr: any) => {
              if (playErr?.name === 'NotAllowedError') {
                wantPlayRef.current = false
                setPlaying(false)
                setBusy(false)
              } else if (v.readyState >= 2) {
                setPlaybackReady(true)
                setBusy(false)
              }
              poke(4000)
            })
        } else {
          v.pause()
          setPlaying(false)
          if (v.readyState >= 2) setBusy(false)
        }
      })
      // Multi-audio streams (ACDN, FlixCloud, etc.): list the renditions, match audioMode or language
      h.on(Hls.Events.AUDIO_TRACKS_UPDATED, (_: any, d: any) => {
        const list = (d.audioTracks || []).map((t: any, i: number) => ({ i, label: formatHlsTrackLabel(t, i, origLangRef.current), lang: t.lang || '' }))
        setAudioTracks(list)
        const target = !userPickedAudioRef.current
          ? findTrackForMode(list, audioModeRef.current, readAlang(), origLangRef.current)
          : null
        if (target && h) {
          if (h.audioTrack !== target.i) h.audioTrack = target.i
          setAudioIdx(target.i)
        } else {
          setAudioIdx(h ? h.audioTrack : 0)
        }
        if (list.length > 1) {
          window.clearTimeout(readyTimer)
          setMediaReady(true)
        }
      })
      h.on(Hls.Events.LEVEL_LOADED, () => {
        if (!h?.audioTracks || h.audioTracks.length < 2 || userPickedAudioRef.current) return
        const list = h.audioTracks.map((t: any, i: number) => ({ i, label: formatHlsTrackLabel(t, i, origLangRef.current), lang: t.lang || '' }))
        const curTrack = list[h.audioTrack]
        if (audioModeRef.current === 'dub' && (!curTrack || isOriginalTrack(curTrack, origLangRef.current))) {
          const target = findTrackForMode(list, 'dub', readAlang(), origLangRef.current)
          if (target && h.audioTrack !== target.i) {
            h.audioTrack = target.i
            setAudioIdx(target.i)
          }
        }
      })
      h.on(Hls.Events.AUDIO_TRACK_SWITCHED, () => {
        audioSwitchLock.current = 0
        if (
          h?.audioTracks &&
          h.audioTracks.length > 1 &&
          !userPickedAudioRef.current &&
          audioModeRef.current === 'dub' &&
          autoAudioAttemptsRef.current < 4
        ) {
          const list = h.audioTracks.map((t: any, i: number) => ({ i, label: formatHlsTrackLabel(t, i, origLangRef.current), lang: t.lang || '' }))
          const curTrack = list[h.audioTrack]
          const target = findTrackForMode(list, 'dub', readAlang(), origLangRef.current)
          if (target && target.i !== h.audioTrack && (!curTrack || isOriginalTrack(curTrack, origLangRef.current))) {
            autoAudioAttemptsRef.current += 1
            h.audioTrack = target.i
            setAudioIdx(target.i)
            return
          }
        }
        setAudioIdx(h ? h.audioTrack : 0)
      })
      h.on(Hls.Events.ERROR, (_: any, d: any) => {
        if (d.type === Hls.ErrorTypes.NETWORK_ERROR && h && !noSegRef.current && streamUrl.includes('seg=1')) {
          noSegRef.current = true
          h.loadSource(stripSegParam(streamUrl))
          h.startLoad()
          return
        }
        if (!d.fatal) return
        const code = d.response?.code
        const isHttpError = code === 403 || code === 404 || code === 410 || (typeof code === 'number' && code >= 500)
        const isParseError = d.details === 'manifestParsingError' || d.details === 'levelParsingError'
        if ((isHttpError || isParseError) && fallbackStreamUrl && fallbackStreamUrl !== streamUrl && !triedFallback.current) {
          triedFallback.current = true
          h?.loadSource(fallbackStreamUrl)
          h?.startLoad()
          return
        }
        const isHardHttpFail =
          isParseError ||
          (isHttpError &&
            (d.details === 'manifestLoadError' || d.details === 'levelLoadError' || d.details === 'audioTrackLoadError'))
        if (!isHardHttpFail && d.type === Hls.ErrorTypes.NETWORK_ERROR && fails++ < 2) h?.startLoad()
        else if (!isHardHttpFail && d.type === Hls.ErrorTypes.MEDIA_ERROR && fails++ < 2) h?.recoverMediaError()
        else {
          if (fallbackStreamUrl && fallbackStreamUrl !== streamUrl && !triedFallback.current) {
            triedFallback.current = true
            h?.loadSource(fallbackStreamUrl)
            h?.startLoad()
            return
          }
          window.clearTimeout(stallTimer)
          window.clearTimeout(readyTimer)
          h?.destroy()
          setErr(true)
          setBusy(false)
          setMediaReady(true)
          onStreamError?.()
        }
      })
    } else if (isFileSrc(streamUrl) || v.canPlayType('application/vnd.apple.mpegurl')) {
      const cleanUrl = isFileSrc(streamUrl) ? stripSegParam(streamUrl) : streamUrl
      armStallWatchdog(18000)
      v.src = cleanUrl
      v.addEventListener('loadedmetadata', onMeta)
      v.addEventListener('loadeddata', onCanPlay)
      v.addEventListener('canplay', onCanPlay)
      v.addEventListener('progress', onFileProgress)
      v.addEventListener('waiting', onFileWaitOrStall)
      v.addEventListener('stalled', onFileWaitOrStall)
      v.addEventListener('error', onVideoError)
    } else {
      setErr(true)
      setBusy(false)
      setMediaReady(true)
      onStreamError?.()
    }

    function onFileProgress() {
      if (v && v.readyState >= 2) {
        window.clearTimeout(stallTimer)
      }
    }

    function onFileWaitOrStall() {
      if (v && wantPlayRef.current && !castOn.current && v.readyState < 3) {
        armStallWatchdog(16000)
      }
    }

    function onCanPlay() {
      window.clearTimeout(stallTimer)
      setBusy(false)
      setMediaReady(true)
      if (v && v.readyState >= 2) setPlaybackReady(true)
    }

    function onVideoError() {
      if (!v) return;
      window.clearTimeout(stallTimer);
      if (fallbackStreamUrl && fallbackStreamUrl !== v.src && !triedFallback.current) {
        triedFallback.current = true;
        console.warn('[CinePlayer] Direct stream encountered error, seamlessly falling back to proxy stream:', fallbackStreamUrl);
        armStallWatchdog(16000);
        v.src = fallbackStreamUrl;
        v.load();
        v.play().catch((playErr: any) => {
          if (playErr?.name === 'NotAllowedError') {
            wantPlayRef.current = false
            setPlaying(false)
            setBusy(false)
          }
        });
        return;
      }
      setErr(true);
      setBusy(false);
      onStreamError?.();
    }

    const onHalt = () => {
      window.clearTimeout(stallTimer)
      try {
        if (h) {
          h.stopLoad()
          h.destroy()
        }
        hls.current = null
        v.pause()
        v.removeAttribute('src')
        v.load()
        setBusy(false)
      } catch {}
    }
    window.addEventListener('zenkai:devtools-halt', onHalt)

    const t = window.setTimeout(() => setCard(false), 3800)
    return () => {
      const ctNow = v.currentTime || lastTimeRef.current || 0
      const duNow = v.duration && isFinite(v.duration) && v.duration > 0 ? v.duration : 0
      if (duNow > 0) {
        persistOrClearScopedPos(animeId, episode, season, isTmdb, ctNow, duNow, hasEndedRef.current || v.ended)
      }
      window.removeEventListener('zenkai:devtools-halt', onHalt)
      window.clearTimeout(t)
      window.clearTimeout(readyTimer)
      window.clearTimeout(stallTimer)
      v.removeEventListener('loadedmetadata', onMeta)
      v.removeEventListener('loadeddata', onCanPlay)
      v.removeEventListener('canplay', onCanPlay)
      v.removeEventListener('progress', onFileProgress)
      v.removeEventListener('waiting', onFileWaitOrStall)
      v.removeEventListener('stalled', onFileWaitOrStall)
      v.removeEventListener('error', onVideoError)
      if (h) {
        try {
          h.stopLoad()
          h.detachMedia()
          h.destroy()
        } catch {}
      }
      hls.current = null
      try {
        v.pause()
        v.removeAttribute('src')
        v.load()
      } catch {}
    }
  }, [streamUrl, retry, animeId, episode, season, isTmdb])

  /* ── Cast ── */
  useEffect(() => {
    if (canCast) void initCast()
  }, [canCast])

  // start / replace what the TV plays: on connect, and whenever the stream changes while connected (next episode, other server)
  useEffect(() => {
    if (!casting) {
      castLoadedFor.current = null
      return
    }
    if (!streamUrl) return
    const id = `${streamUrl}|${retry}`
    if (castLoadedFor.current === id) return
    const switched = castLoadedFor.current !== null
    castLoadedFor.current = id
    const v = vid.current
    const saved = resolveResumePosition({
      savedPos: readScopedPos(animeId, episode, season, isTmdb),
      durationSec: dur,
      expectedDurationSec: defaultRuntime ? defaultRuntime * 60 : 0,
    })
    const start = switched ? saved : v && v.currentTime > 3 && !isNearOrAtPlaybackEnd(v.currentTime, dur, v.ended) ? v.currentTime : saved
    v?.pause()
    hls.current?.stopLoad()
    setBusy(true)
    void castLoad({
      url: castUrl(apiUrl(streamUrl)),
      title,
      subtitle: isMovie ? (title || '') : `Episode ${episode}${hasDistinctEpTitle ? ` · ${cleanEpTitle}` : ''}`,
      image: fallbackImg,
      time: start > 3 ? start : 0,
      autoplay: true,
      file: isFileSrc(streamUrl),
    }).then((ok) => {
      if (!ok) {
        setBusy(false)
        flash('err', 'Could not start on the TV')
      }
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [casting, streamUrl, retry, episode])

  // show the TV's state in the player's own controls
  useEffect(() => {
    if (!casting) return
    castLast.current = { time: cst.time, playing: cst.playing }
    setTime(cst.time)
    if (cst.duration > 0) setDur(cst.duration)
    setPlaying(cst.playing)
    setBusy(cst.buffering || !cst.loaded)
    setVol(cst.volume)
    setMuted(cst.muted)
  }, [casting, cst])

  // stopped casting: pick up here from where the TV was
  useEffect(() => {
    if (casting) {
      wasCasting.current = true
      return
    }
    if (!wasCasting.current) return
    wasCasting.current = false
    const v = vid.current
    const last = castLast.current
    hls.current?.startLoad()
    setBusy(false)
    if (!v) return
    if (last.time > 1) v.currentTime = last.time
    if (last.playing) v.play().catch(() => {})
  }, [casting])

  useEffect(
    () =>
      onCastFinished(() => {
        if (!castOn.current) return
        hasEndedRef.current = true
        lastTimeRef.current = 0
        skipped.current = -1
        clearScopedPos(animeId, episode, season, isTmdb)
        onEnded?.()
      }),
    [animeId, episode, season, isTmdb, onEnded],
  )

  /* remember position every 5s */
  useEffect(() => {
    if (!playing) return
    const tick = () => {
      const v = vid.current
      const r = castOn.current ? getCast() : null
      const ct = r ? r.time : v?.currentTime ?? 0
      const du = r ? r.duration : v?.duration ?? 0
      if (!du) return
      onProgress?.(Math.floor(ct), Math.floor(du))
      persistOrClearScopedPos(animeId, episode, season, isTmdb, ct, du, Boolean(v?.ended || hasEndedRef.current))
    }
    tick()
    const id = window.setInterval(tick, 5000)
    return () => window.clearInterval(id)
  }, [playing, animeId, episode, season, isTmdb, casting])

  /* ── subtitles ── */
  /** Fetch + parse a caption file; true when it produced cues. Stream captions need the player's referer, so try the proxy first, then the raw url. */
  const loadTrack = async (url: string | undefined, my: number, referer?: string): Promise<boolean> => {
    if (!url) return false
    const streamProxy = (import.meta.env.VITE_STREAM_PROXY_URL as string | undefined)?.trim()
    const proxyBase = streamProxy ? (streamProxy.includes('/proxy') ? streamProxy : `${streamProxy.replace(/\/+$/, '')}/api/public/proxy`) : apiUrl('/proxy')
    const candidates: string[] = []
    let rawUrl = url
    if (url.startsWith('/proxy') || url.startsWith('/api/proxy') || url.includes('/proxy?') || url.includes('api/public/proxy')) {
      try {
        const parsed = new URL(url, typeof window !== 'undefined' ? window.location.href : 'http://localhost')
        const inner = parsed.searchParams.get('url')
        if (inner) rawUrl = inner
      } catch {}
    }

    const isDirectCors = /strem\.io|opensubtitles/i.test(rawUrl)
    const localProxy = apiUrl(`/proxy?url=${encodeURIComponent(rawUrl)}${referer && !isDirectCors ? `&referer=${encodeURIComponent(referer)}` : ''}`)

    if (isDirectCors) {
      candidates.push(rawUrl, localProxy)
    } else if (url.startsWith('/proxy') || url.startsWith('/api/proxy')) {
      candidates.push(apiUrl(url), rawUrl)
    } else {
      const proxied = `${proxyBase}?url=${encodeURIComponent(rawUrl)}${referer ? `&referer=${encodeURIComponent(referer)}` : ''}`
      candidates.push(localProxy, rawUrl, proxied)
    }

    const uniqueCandidates = [...new Set(candidates.filter(Boolean))]
    for (const u of uniqueCandidates) {
      try {
        const res = await fetch(u)
        if (!res.ok) continue
        const parsed = parseSubtitleText(await res.text())
        if (!parsed.length) continue
        if (my === tok.current) setCues(parsed)
        return true
      } catch {
        /* try the next route */
      }
    }
    return false
  }

  /** top-of-player notification */
  const flash = (k: 'load' | 'ok' | 'err', msg: string) => {
    window.clearTimeout(noteTimer.current)
    setNote({ k, msg })
    // Only auto-dismiss completed/error notices; 'load' stays until ready, with a 5s safety timeout
    const timeout = k === 'ok' ? 2600 : k === 'err' ? 4200 : 5000
    noteTimer.current = window.setTimeout(() => {
      setNote((n) => (n?.msg === msg ? null : n))
    }, timeout)
  }
  useEffect(() => () => window.clearTimeout(noteTimer.current), [])

  // Auto-dismiss stream switching / loading notification once both playback and subtitles are ready
  useEffect(() => {
    if (!switching && !loadingSubs && (playing || !busy)) {
      setNote((n) => (n?.k === 'load' ? null : n))
    }
  }, [switching, loadingSubs, playing, busy])

  const scoreCandidate = useCallback((t: Track) => {
    const en = isEn(t)
    const isStream = t.source !== 'OpenSubtitles'
    const lbl = (t.label || '').toLowerCase()
    const isSignsOnly = /\b(signs?|songs?|forced)\b/i.test(lbl) && !/\b(full|dialogue|dialog|sdh|cc|dubtitle)\b/i.test(lbl)
    const isCcOrFull = /\b(cc|sdh|full|dialogue|dialog|dubtitle)\b/i.test(lbl)
    if (en && isStream && !isSignsOnly && isCcOrFull) return 120
    if (en && isStream && !isSignsOnly) return 100
    if (en && isStream) return 80
    if (isStream && !isSignsOnly) return 60
    if (en && !isSignsOnly) return 50
    if (en) return 40
    return 10
  }, [])

  const sortByBestSub = useCallback(
    (list: Track[]) => [...list].sort((a, b) => scoreCandidate(b) - scoreCandidate(a)),
    [scoreCandidate],
  )

  const pick = async (t: Track, quiet = false, turnOn = true): Promise<boolean> => {
    const my = ++tok.current
    const name = `${langName(t)}${t.source ? ` · ${t.source}` : ''}`
    setTrackId(t.id)
    if (turnOn) setCaps(true)
    setSubErr(null)
    setCues([])
    if (t.cues) {
      setCues(t.cues)
      if (!quiet) flash('ok', `Subtitles: ${name}`)
      return true
    }
    if (!quiet) flash('load', `Downloading ${name}…`)
    const ok = await loadTrack(t.url, my, t.referer)
    if (my === tok.current) {
      if (ok) {
        if (!quiet) flash('ok', `Subtitles: ${name}`)
      } else {
        setSubErr(`Couldn't load "${t.label}". Try another track.`)
        if (!quiet) flash('err', `Couldn't load ${name}. Try another track or source.`)
      }
    }
    return ok
  }

  const subKey = JSON.stringify(directSubtitles)
  useEffect(() => {
    let dead = false
    let pickedStreamSub = false
    const shouldTurnOn = audioMode === 'sub'

    ;(async () => {
      setLoadingSubs(true)
      setCues([])
      const primarySource = servers?.find((x) => x.id === serverId)?.name ?? 'Stream'
      const all: Track[] = directSubtitles.map((s, i) => ({
        id: s.id || `direct_${i}`,
        label: s.label || s.lang || `Track ${i + 1}`,
        language: s.lang || s.label || 'English',
        url: s.url,
        source: primarySource,
        referer: sourceReferer(serverId),
      }))
      if (!isTmdb) {
        try {
          const q = new URLSearchParams({ title, ep: String(episode), id: String(animeId), format: format ?? '' })
          const res = await fetch(apiUrl(`/api/subtitles?${q}`))
          if (res.ok) {
            const data = (await res.json()) as { subtitles?: Track[] }
            for (const s of data.subtitles ?? []) if (!all.some((c) => c.url === s.url)) all.push(s) // every source, not one per language
          }
        } catch {
          /* OpenSubtitles is optional */
        }
      } else if (all.length === 0) {
        try {
          const q = new URLSearchParams({
            id: String(animeId),
            type: format === 'MOVIE' ? 'movie' : 'tv',
            s: String(episode || 1),
            e: String(episode || 1),
            title: title || ''
          })
          const res = await fetch(apiUrl(`/api/movies/stream?${q}`))
          if (res.ok) {
            const data = (await res.json()) as { subtitles?: Track[] }
            for (const s of data.subtitles ?? []) if (!all.some((c) => c.url === s.url)) all.push(s)
          }
        } catch {}
      }
      if (dead) return
      setTracks(all)

      // ask every other direct server for its captions too; they trickle into the menu as each answers (anime only)
      if (!isTmdb) {
        const seen = new Set(all.map((t) => t.url))
        const others =
          servers && servers.length > 0
            ? servers.filter((x) => x.id !== serverId)
            : [
                { id: 'megaplay', name: 'Stream' },
                { id: 'flixcloud', name: 'Stream' },
                { id: 'vidstream', name: 'Stream' },
              ].filter((x) => x.id !== serverId)
        setSrcLeft(others.length)
        for (const x of others) {
          const fetchSubs = async () => {
            let r = await fetchStream({ id: animeId, ep: episode, server: x.id, audio: audioMode, title, format })
            if ((!r.subtitles || !r.subtitles.length) && audioMode !== 'sub' && x.id !== 'acdn') {
              try {
                r = await fetchStream({ id: animeId, ep: episode, server: x.id, audio: 'sub', title, format })
              } catch {}
            }
            const add: Track[] = (r.subtitles || [])
              .filter((s) => s.file && !seen.has(s.file))
              .map((s, i) => ({
                id: `${x.id}_${i}_${s.file}`,
                label: s.label,
                language: s.label,
                url: s.file,
                source: x.name || 'Stream',
                referer: sourceReferer(x.id),
              }))
            add.forEach((t) => seen.add(t.url))
            if (!dead && add.length) {
              setTracks((p) => {
                const streamTracks = [...p.filter((t) => t.source !== 'OpenSubtitles'), ...add]
                const osTracks = p.filter((t) => t.source === 'OpenSubtitles')
                return [...streamTracks, ...osTracks]
              })
              if (!pickedStreamSub) {
                for (const cand of sortByBestSub(add)) {
                  if (dead || pickedStreamSub) break
                  const ok = await pick(cand, true, shouldTurnOn)
                  if (ok) {
                    pickedStreamSub = true
                    break
                  } else {
                    setTracks((p) => p.filter((x) => x.id !== cand.id))
                  }
                }
              }
            }
          }
          fetchSubs()
            .catch(() => {
              /* that server has nothing for this episode */
            })
            .finally(() => !dead && setSrcLeft((n) => Math.max(0, n - 1)))
        }
      } else {
        setSrcLeft(0)
      }

      const ordered = sortByBestSub(all)
      if (!ordered.length) {
        if (!dead) setLoadingSubs(false)
        return setTrackId(null)
      }
      // Walk prioritized candidates (Stream / CC English first) until one loads
      for (const t of ordered) {
        if (dead || pickedStreamSub) break
        const ok = await pick(t, true, shouldTurnOn)
        if (ok) {
          if (t.source !== 'OpenSubtitles') pickedStreamSub = true
          break
        } else if (t.source !== 'OpenSubtitles') {
          setTracks((p) => p.filter((x) => x.id !== t.id))
        }
      }
      if (!dead) setLoadingSubs(false)
    })()
    return () => {
      dead = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [title, episode, animeId, subKey, audioMode])

  const uploadSub = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    e.target.value = ''
    if (!f) return
    const r = new FileReader()
    r.onload = (ev) => {
      const t: Track = {
        id: `custom_${Date.now()}`,
        label: `Custom (${f.name.replace(/\.[^/.]+$/, '')})`,
        language: 'Custom',
        source: 'Upload',
        cues: parseSubtitleText(String(ev.target?.result ?? '')),
      }
      setTracks((p) => [t, ...p])
      void pick(t)
      setSheet(null)
    }
    r.readAsText(f)
  }

  /* ── video events ── */
  const onTime = () => {
    const v = vid.current
    if (!v || castOn.current) return
    if (!hasEndedRef.current) lastTimeRef.current = v.currentTime
    setTime(v.currentTime)
    if (v.duration > 0) {
      let end = 0
      for (let i = 0; i < v.buffered.length; i++) if (v.buffered.start(i) <= v.currentTime + 0.5) end = Math.max(end, v.buffered.end(i))
      const b = end / v.duration
      setBuf((o) => (Math.abs(o - b) < 0.002 ? o : b))
    }
  }

  // every language with how many captions it has, English first
  const langs = (() => {
    const m = new Map<string, Track[]>()
    for (const t of tracks) m.set(langName(t), [...(m.get(langName(t)) ?? []), t])
    return [...m].sort(([a], [b]) => (a === 'English' ? -1 : b === 'English' ? 1 : a.localeCompare(b)))
  })()

  const filteredLangs = useMemo(() => {
    const q = subSearch.trim().toLowerCase()
    if (!q) return langs
    return langs.filter(
      ([name, list]) =>
        name.toLowerCase().includes(q) ||
        list.some((t) => t.label.toLowerCase().includes(q) || (t.source && t.source.toLowerCase().includes(q)))
    )
  }, [langs, subSearch])

  useEffect(() => {
    if (dur > 0) onDuration?.(dur)
  }, [dur, onDuration])

  const validSkips = useMemo(() => {
    const fallbackDur = defaultRuntime && defaultRuntime > 0 ? defaultRuntime * 60 : 0
    const effectiveDur = dur > 0 ? dur : fallbackDur
    return sanitizeSkipPair({
      intro,
      recap,
      outro,
      durationSec: dur > 0 ? dur : undefined,
      expectedDurationSec: effectiveDur > 0 ? effectiveDur : undefined,
    })
  }, [intro, recap, outro, dur, defaultRuntime])
  const safeIntro = validSkips.intro
  const safeRecap = validSkips.recap
  const safeOutro = validSkips.outro

  const mediaLoading = Boolean(switching || busy || !(casting ? cst.loaded && !cst.buffering : playbackReady))
  const playDisabled = Boolean(err || mediaLoading)
  const skipDisabled = Boolean(err || switching || !(casting ? cst.loaded : (mediaReady || playbackReady || dur > 0)))

  const inSeg = (seg: typeof safeIntro) =>
    seg != null && seg.end > seg.start && time >= seg.start && time < Math.max(seg.start, seg.end - 0.35)
  const inRecap = inSeg(safeRecap)
  const inIntro = !inRecap && inSeg(safeIntro)
  const inOutro = !inRecap && !inIntro && inSeg(safeOutro)
  const skip = inRecap
    ? { kind: 'recap' as const, label: 'SKIP RECAP', to: safeRecap!.end }
    : inIntro
      ? { kind: 'intro' as const, label: 'SKIP INTRO', to: safeIntro!.end }
      : inOutro
        ? { kind: 'outro' as const, label: 'SKIP OUTRO', to: safeOutro!.end }
        : null
  const doSkip = () => {
    if (skipDisabled) return
    if (skip && castOn.current) {
      castSeek(skip.to)
      if (dur > 0) persistOrClearScopedPos(animeId, episode, season, isTmdb, skip.to, dur, false)
      if (st.current.show) poke()
    } else if (skip && vid.current) {
      hasEndedRef.current = false
      vid.current.currentTime = skip.to
      lastTimeRef.current = skip.to
      setTime(skip.to)
      const effectiveDur = (vid.current.duration && isFinite(vid.current.duration) && vid.current.duration > 0) ? vid.current.duration : dur
      if (effectiveDur > 0) persistOrClearScopedPos(animeId, episode, season, isTmdb, skip.to, effectiveDur, false)
      if (st.current.show) poke()
    }
  }
  /* ── GPU upscaler (Anime4K): restarts when the toggle flips or the stream changes resolution ── */
  useEffect(() => {
    const v = vid.current
    if (!v) return
    const on = () => setVkey((k) => k + 1)
    v.addEventListener('resize', on)
    return () => v.removeEventListener('resize', on)
  }, [])
  useEffect(() => {
    const v = vid.current
    const c = cv.current
    if (!up || !v || !c) return
    let dead = false
    let stop: (() => void) | undefined
    setUpErr(null)
    startUpscale(v, c, {
      mode: upMode,
      onSlow: (reason) => {
        if (!dead && reason) setUpErr(reason)
      },
    })
      .then((s) => (dead ? s() : (stop = s)))
      .catch((e: unknown) => {
        if (dead) return
        setUpErr(e instanceof Error ? e.message : 'Upscaler initialization failed')
      })
    return () => {
      dead = true
      stop?.()
    }
  }, [up, upMode, vkey])

  const cue = caps && cues.length ? findActiveCue(cues, time, -offset) : null
  const upNext = !skip && hasNextEpisode && dur > 0 && dur - time <= 20 && !!onNextEpisode
  const skipFill = fillAsk && !skip && !upNext && (episodeKind === 'filler' || episodeKind === 'recap') && hasNextEpisode && !!onNextEpisode
  useEffect(() => {
    const non = episodeKind === 'filler' || episodeKind === 'recap'
    setFillAsk(non)
    if (!non) return
    const t = window.setTimeout(() => setFillAsk(false), 15000) // unanswered: quietly goes away
    return () => window.clearTimeout(t)
  }, [episode, episodeKind])

  useEffect(() => {
    if (autoSkip && !skipDisabled && skip && skipped.current !== skip.to && vid.current) {
      skipped.current = skip.to
      if (castOn.current) castSeek(skip.to)
      else vid.current.currentTime = skip.to
    }
  })

  /* ── actions ── */
  const togglePlay = () => {
    if (playDisabled) return
    if (castOn.current) {
      castTogglePlay()
      poke()
      return
    }
    const v = vid.current
    if (!v) return
    const effectiveDur = (v.duration && isFinite(v.duration) && v.duration > 0) ? v.duration : dur
    const atEnd = shouldRestartFromBeginningOnPlay({
      ended: hasEndedRef.current || v.ended,
      currentTimeSec: v.currentTime,
      durationSec: effectiveDur,
    })
    const shouldPlay = atEnd || v.paused || !wantPlayRef.current
    wantPlayRef.current = shouldPlay
    if (shouldPlay) {
      if (atEnd) {
        hasEndedRef.current = false
        lastTimeRef.current = 0
        skipped.current = -1
        clearScopedPos(animeId, episode, season, isTmdb)
        v.currentTime = 0
        setTime(0)
        if (hls.current) hls.current.startLoad(0)
      }
      if (v.readyState < 3) setBusy(true)
      const p = v.play()
      if (p && typeof p.then === 'function') {
        p.then(() => {
          if (!wantPlayRef.current && vid.current && !vid.current.paused) {
            vid.current.pause()
          }
        }).catch(() => {
          if (!wantPlayRef.current) setBusy(false)
        })
      }
    } else {
      v.pause()
      setPlaying(false)
      setBusy(false)
    }
    poke()
  }

  const seek = (d: number, quiet = false) => {
    if (isPartyGuest) {
      toast('Playback timestamp is controlled by the party host', 'info')
      return
    }
    const v = vid.current
    if (!v) return
    const r = castOn.current ? getCast() : null
    const effectiveDur = r?.duration || v.duration || dur || 0
    const currentPos = r ? r.time : (v.currentTime || time || 0)
    const t = effectiveDur > 0 ? clamp(currentPos + d, 0, effectiveDur) : Math.max(0, currentPos + d)
    if (effectiveDur > 0 && t < Math.max(0, effectiveDur - 2)) hasEndedRef.current = false
    if (r) castSeek(t)
    else v.currentTime = t
    lastTimeRef.current = t
    setTime(t)
    if (effectiveDur > 0) persistOrClearScopedPos(animeId, episode, season, isTmdb, t, effectiveDur, false)
    const side = d < 0 ? -1 : 1
    const now = Date.now()
    setFb((p) => (p && p.side === side && now - fbAt.current < 800 ? { side, n: p.n + Math.abs(d), k: p.k + 1 } : { side, n: Math.abs(d), k: (p?.k || 0) + 1 }))
    fbAt.current = now
    clearTimeout(fbT.current)
    fbT.current = window.setTimeout(() => setFb(null), 700)
    if (!quiet) poke()
  }

  const setVolume = (f: number) => {
    if (castOn.current) {
      castSetVolume(f)
      poke()
      return
    }
    const v = vid.current
    if (!v) return
    const n = clamp(f, 0, 1)
    v.volume = n
    v.muted = n === 0
    poke()
  }

  const toggleMute = () => {
    if (castOn.current) {
      castToggleMute()
      poke()
      return
    }
    const v = vid.current
    if (!v) return
    v.muted = !v.muted
    if (!v.muted && v.volume === 0) v.volume = 0.6
    poke()
  }

  const setRate = (s: number) => {
    if (castOn.current) {
      toast('Playback speed is not available while casting', 'info')
      return
    }
    setSpeed(s)
    if (vid.current) vid.current.playbackRate = s
  }
  const setQuality = (i: number) => {
    if (hls.current) {
      setLvl(i)
      hls.current.currentLevel = i
    } else if (qualities && qualities.length > 0 && vid.current) {
      const resolvedIdx = i >= 0 && qualities[i] ? i : 0
      const target = qualities[resolvedIdx]
      setLvl(resolvedIdx)
      if (target && vid.current.src !== target.url) {
        const curTime = vid.current.currentTime
        const wasPlaying = !vid.current.paused
        setBusy(true)
        vid.current.src = target.url
        const onSwitched = () => {
          vid.current?.removeEventListener('loadedmetadata', onSwitched)
          if (vid.current && curTime > 0) vid.current.currentTime = curTime
          if (wasPlaying && vid.current) vid.current.play().catch(() => {})
          setBusy(false)
        }
        vid.current.addEventListener('loadedmetadata', onSwitched)
        onQualityChange?.(target)
        flash('ok', `Quality: ${target.label}${target.sizeLabel ? ` (${target.sizeLabel})` : ''}`)
      }
    } else {
      setLvl(i)
    }
  }
  const setAudioTrack = (t: { i: number; lang: string; label: string }) => {
    if (switching || audioLoading || Date.now() < audioSwitchLock.current) return
    audioSwitchLock.current = Date.now() + 350
    userPickedAudioRef.current = true
    flash('ok', `Audio: ${t.label}`)
    if (hls.current) hls.current.audioTrack = t.i
    setAudioIdx(t.i)
    const l = t.label.toLowerCase()
    const g = t.lang.toLowerCase()
    const isSub = isOriginalTrack(t, origLang)
    const isDub = !isSub && (g === 'en' || g === 'eng' || g === 'hi' || g === 'hin' || g === 'ja' || g === 'jpn' || l.includes('english') || l.includes('hindi') || l.includes('japanese') || l.includes('tamil') || l.includes('telugu') || l.includes('malayalam') || l.includes('kannada') || l.includes('bengali') || l.includes('dub') || audioTracks.length > 1)
    if (isDub && onAudio && audioMode !== 'dub') {
      onAudio('dub')
    } else if (isSub && onAudio && audioMode !== 'sub') {
      onAudio('sub')
    }
  }

  useEffect(() => {
    setSavedPrefLang(readAlang())
  }, [streamUrl, episode, animeId])

  // Live switch HLS audio track when audioMode ('sub' | 'dub') changes from the parent
  useEffect(() => {
    userPickedAudioRef.current = false
    autoAudioAttemptsRef.current = 0
    if (!audioTracks.length || !hls.current) return
    const target = findTrackForMode(audioTracks, audioMode, readAlang(), origLang)
    if (target && hls.current.audioTrack !== target.i) {
      hls.current.audioTrack = target.i
      setAudioIdx(target.i)
    }
  }, [audioMode, audioTracks, origLang])
  const atRef = useRef(onAudioTracks)
  atRef.current = onAudioTracks
  useEffect(() => {
    atRef.current?.(audioTracks, audioIdx)
  }, [audioTracks, audioIdx])
  useEffect(() => {
    const t = audioSel ? audioTracks[audioSel.i] : null
    if (t) setAudioTrack(t)
  }, [audioSel])

  const getFullscreenElement = () => {
    if (typeof document === 'undefined') return null
    const d = document as Document & {
      webkitFullscreenElement?: Element
      mozFullScreenElement?: Element
      msFullscreenElement?: Element
    }
    return d.fullscreenElement || d.webkitFullscreenElement || d.mozFullScreenElement || d.msFullscreenElement || null
  }

  const exitFullscreen = async () => {
    if (typeof document === 'undefined') return
    const d = document as Document & {
      webkitFullscreenElement?: Element
      mozFullScreenElement?: Element
      msFullscreenElement?: Element
      webkitExitFullscreen?: () => Promise<void> | void
      mozCancelFullScreen?: () => Promise<void> | void
      msExitFullscreen?: () => Promise<void> | void
    }
    try {
      if (d.exitFullscreen) await d.exitFullscreen()
      else if (d.webkitExitFullscreen) await d.webkitExitFullscreen()
      else if (d.mozCancelFullScreen) await d.mozCancelFullScreen()
      else if (d.msExitFullscreen) await d.msExitFullscreen()
    } catch {}
  }

  const enterFullscreen = async (el: HTMLElement) => {
    const target = el as HTMLElement & {
      requestFullscreen?: (opts?: { navigationUI?: 'auto' | 'hide' | 'show' }) => Promise<void>
      webkitRequestFullscreen?: () => Promise<void> | void
      mozRequestFullScreen?: () => Promise<void> | void
      msRequestFullscreen?: () => Promise<void> | void
    }
    if (target.requestFullscreen) {
      try {
        await target.requestFullscreen({ navigationUI: 'hide' })
      } catch {
        await target.requestFullscreen()
      }
    } else if (target.webkitRequestFullscreen) await target.webkitRequestFullscreen()
    else if (target.mozRequestFullScreen) await target.mozRequestFullScreen()
    else if (target.msRequestFullscreen) await target.msRequestFullscreen()
    else throw new Error('Fullscreen not supported')
  }

  const isTouchDevice = () =>
    typeof window !== 'undefined' &&
    (matchMedia('(pointer: coarse)').matches ||
      matchMedia('(any-pointer: coarse)').matches ||
      navigator.maxTouchPoints > 0 ||
      'ontouchstart' in window)

  const isPortraitViewport = () => {
    if (typeof window === 'undefined') return false
    const fsEl = getFullscreenElement()
    if (fsEl && root.current) {
      const rect = root.current.getBoundingClientRect()
      if (rect.width > 0 && rect.height > 0) return rect.height > rect.width
    }
    return window.innerHeight > window.innerWidth
  }

  const tryLockLandscape = async (): Promise<boolean> => {
    try {
      const o = screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> }
      if (!o?.lock) return false
      try {
        await o.lock('landscape')
        return true
      } catch {
        try {
          await o.lock('landscape-primary')
          return true
        } catch {
          return false
        }
      }
    } catch {
      return false
    }
  }

  const scheduleRotFallback = (sid: number, delayMs: number) => {
    window.setTimeout(() => {
      if (fsSessionRef.current !== sid) return
      if (!getFullscreenElement() && !fakeRef.current) return
      if (isPortraitViewport()) {
        setRot90(true)
      }
    }, delayMs)
  }

  // phones: keep controls responsive and clear CSS rotation fallback if device physically rotates to landscape
  useEffect(() => {
    const mq = matchMedia('(orientation: landscape)')
    const onRotate = () => {
      setPopRaw(null)
      resetGestures()
      if (!isPortraitViewport()) {
        setRot90(false)
      }
      if (!mq.matches && autoFs.current) {
        autoFs.current = false
        if (getFullscreenElement()) exitFullscreen().catch(() => {})
        fakeRef.current = false
        setFake(false)
        setRot90(false)
      }
      poke(3000)
    }
    const onResize = () => {
      if (!isPortraitViewport()) {
        setRot90(false)
      }
    }
    mq.addEventListener('change', onRotate)
    window.addEventListener('orientationchange', onRotate)
    window.addEventListener('resize', onResize)
    return () => {
      mq.removeEventListener('change', onRotate)
      window.removeEventListener('orientationchange', onRotate)
      window.removeEventListener('resize', onResize)
    }
  }, [])

  const toggleFs = () => {
    const el = root.current
    if (!el) return
    autoFs.current = false
    const currentFs = getFullscreenElement()
    if (currentFs) {
      fsSessionRef.current++
      setRot90(false)
      fakeRef.current = false
      setFake(false)
      setIsFs(false)
      exitFullscreen().catch(() => {})
      try {
        screen.orientation?.unlock?.()
      } catch {}
    } else if (fake) {
      fsSessionRef.current++
      setRot90(false)
      fakeRef.current = false
      setFake(false)
      setIsFs(false)
      try {
        screen.orientation?.unlock?.()
      } catch {}
    } else {
      const sid = ++fsSessionRef.current
      const shouldRotate = isTouchDevice() && isPortraitViewport()
      enterFullscreen(el)
        .then(async () => {
          setIsFs(true)
          if (!shouldRotate) return
          const locked = await tryLockLandscape()
          scheduleRotFallback(sid, locked ? 240 : 30)
        })
        .catch(async () => {
          fakeRef.current = true
          setFake(true)
          setIsFs(true)
          if (!shouldRotate) return
          const locked = await tryLockLandscape()
          scheduleRotFallback(sid, locked ? 240 : 30)
        })
    }
    poke()
  }

  const togglePiP = async () => {
    const v = vid.current as (HTMLVideoElement & { webkitSetPresentationMode?: (m: string) => void; webkitPresentationMode?: string }) | null
    try {
      if (document.pictureInPictureElement) await document.exitPictureInPicture()
      else if (v) {
        v.removeAttribute('disablePictureInPicture')
        v.disablePictureInPicture = false
        if (v.readyState < 1) await new Promise<void>((r) => (v.addEventListener('loadedmetadata', () => r(), { once: true }), setTimeout(r, 2000)))
        if (document.pictureInPictureEnabled && v.requestPictureInPicture) await v.requestPictureInPicture()
        else if (v.webkitSetPresentationMode) v.webkitSetPresentationMode(v.webkitPresentationMode === 'picture-in-picture' ? 'inline' : 'picture-in-picture')
      }
    } catch {
      /* not allowed */
    }
    poke()
  }

  useEffect(() => {
    const f = () => {
      const fsEl = getFullscreenElement()
      const on = Boolean(fsEl && root.current && (fsEl === root.current || root.current.contains(fsEl)))
      setIsFs(on)
      resetGestures()
      if (on) {
        const sid = fsSessionRef.current
        if (isTouchDevice() && isPortraitViewport()) {
          void tryLockLandscape().then((locked) => {
            if (!isPortraitViewport()) {
              setRot90(false)
            } else {
              scheduleRotFallback(sid, locked ? 240 : 30)
            }
          })
        }
      } else {
        fsSessionRef.current++
        setRot90(false)
        fakeRef.current = false
        setFake(false)
        try {
          screen.orientation?.unlock?.()
        } catch {}
      }
    }
    document.addEventListener('fullscreenchange', f)
    document.addEventListener('webkitfullscreenchange', f)
    document.addEventListener('mozfullscreenchange', f)
    document.addEventListener('MSFullscreenChange', f)
    const wk = typeof (document.createElement('video') as HTMLVideoElement & { webkitSetPresentationMode?: unknown }).webkitSetPresentationMode === 'function'
    setPip(!!document.pictureInPictureEnabled || wk)
    return () => {
      document.removeEventListener('fullscreenchange', f)
      document.removeEventListener('webkitfullscreenchange', f)
      document.removeEventListener('mozfullscreenchange', f)
      document.removeEventListener('MSFullscreenChange', f)
      try {
        screen.orientation?.unlock?.()
      } catch {}
    }
  }, [])

  useEffect(() => {
    if (!fake) return
    const o = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = o
    }
  }, [fake])

  /* ── keyboard ── */
  api.current = { togglePlay, toggleMute, toggleFs, poke, doSkip, skipOn: !!skip && !skipDisabled, v: muted ? 0 : vol }
  const keys = useRef({ seek, setVolume, setRate, togglePiP, speed, dur, hasNext: hasNextEpisode, hasPrev: hasPrevEpisode, next: onNextEpisode, prev: onPrevEpisode })
  keys.current = { seek, setVolume, setRate, togglePiP, speed, dur, hasNext: hasNextEpisode, hasPrev: hasPrevEpisode, next: onNextEpisode, prev: onPrevEpisode }
  useEffect(() => {
    const kd = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement
      if (/INPUT|TEXTAREA|SELECT/.test(t.tagName) || t.isContentEditable || e.ctrlKey || e.metaKey || e.altKey) return
      const a = api.current
      const kk = keys.current
      const v = vid.current
      const key = e.key
      const k = key.toLowerCase()
      const tv = document.documentElement.hasAttribute('data-tv')
      const arrow = key.startsWith('Arrow')
      const onBtn = t.tagName === 'BUTTON' || t.tagName === 'A'
      const inCtl = onBtn && !!root.current?.contains(t) // focus is on a control (TV: D-pad moves between them)
      if (k === ' ' && onBtn) return
      if (tv && arrow && (st.current.sheet || st.current.pop)) return // an open menu: the D-pad moves through it
      if (tv && arrow && inCtl) {
        poke() // keep the controls up while the D-pad is working them
        return
      }
      const step = e.shiftKey ? 30 : pfRef.current.seek
      let h: (() => void) | null = null
      if (k === ' ' || k === 'k' || (key === 'Enter' && !onBtn)) h = a.togglePlay
      else if (key === 'MediaPlayPause') h = a.togglePlay
      else if (key === 'MediaPlay') h = () => !st.current.playing && a.togglePlay()
      else if (key === 'MediaPause' || key === 'MediaStop') h = () => st.current.playing && a.togglePlay()
      else if (key === 'MediaTrackNext' || k === 'n') {
        if (isPartyGuest) { toast('Only the party host can change episodes', 'info'); return }
        h = () => kk.hasNext && kk.next?.()
      }
      else if (key === 'MediaTrackPrevious' || k === 'p') {
        if (isPartyGuest) { toast('Only the party host can change episodes', 'info'); return }
        h = () => kk.hasPrev && kk.prev?.()
      }
      else if (key === 'MediaFastForward' || key === 'MediaRewind' || k === 'arrowleft' || k === 'arrowright' || k === 'j' || k === 'l') {
        if (isPartyGuest) { toast('Playback timestamp is controlled by party host', 'info'); return }
        if (key === 'MediaFastForward') h = () => kk.seek(30)
        else if (key === 'MediaRewind') h = () => kk.seek(-30)
        else if (k === 'arrowleft') h = () => kk.seek(-step)
        else if (k === 'arrowright') h = () => kk.seek(step)
        else if (k === 'j') h = () => kk.seek(-pfRef.current.seek)
        else if (k === 'l') h = () => kk.seek(pfRef.current.seek)
      }
      else if (tv && (k === 'arrowup' || k === 'arrowdown')) {
        // TV: Up / Down bring up the controls and put focus on Play (the remote has its own volume keys)
        h = () => root.current?.querySelector<HTMLElement>('.zp-hero')?.focus()
      } else if (k === 'arrowup') h = () => kk.setVolume(a.v + 0.1)
      else if (k === 'arrowdown') h = () => kk.setVolume(a.v - 0.1)
      else if (/^[0-9]$/.test(key) && v && kk.dur) h = () => { const t = (kk.dur * Number(key)) / 10; castOn.current ? castSeek(t) : (v.currentTime = t); setTime(t) }
      else if (k === 'home' && v) h = () => { castOn.current ? castSeek(0) : (v.currentTime = 0); setTime(0) }
      else if (k === 'end' && v && kk.dur) h = () => { const t = Math.max(0, kk.dur - 1); castOn.current ? castSeek(t) : (v.currentTime = t); setTime(t) }
      else if ((key === ',' || key === '.') && v && v.paused && !castOn.current) h = () => ((v.currentTime = clamp(v.currentTime + (key === ',' ? -1 : 1) / 24, 0, v.duration || 0)), setTime(v.currentTime))
      else if (key === '<') h = () => kk.setRate(SPEEDS[Math.max(0, SPEEDS.indexOf(kk.speed) - 1)])
      else if (key === '>') h = () => kk.setRate(SPEEDS[Math.min(SPEEDS.length - 1, SPEEDS.indexOf(kk.speed) + 1)])
      else if (k === 'f') h = a.toggleFs
      else if (k === 'm') h = a.toggleMute
      else if (k === 'c')
        h = () => {
          setCaps((c) => {
            const next = !c
            if (next && (!trackId || !cues.length) && tracks.length > 0) {
              const best = sortByBestSub(tracks)[0]
              if (best) void pick(best, false, true)
            }
            return next
          })
        }
      else if (k === 'tab' && a.skipOn) h = a.doSkip
      else if (k === 'escape' && (st.current.sheet || st.current.pop)) h = () => (setSheet(null), closePop())
      else if (k === 'escape' && tv && inCtl) {
        // TV: Back from the controls returns to plain seeking
        h = () => {
          t.blur()
          clearTimeout(hideT.current)
          if (st.current.playing) setShow(false)
        }
      }
      if (!h) return
      e.preventDefault()
      h()
      if (k !== 'escape' && !(k === 'tab' && a.skipOn)) a.poke()
    }
    window.addEventListener('keydown', kd)
    return () => window.removeEventListener('keydown', kd)
  }, [])

  const onMouseMovePoke = (e: RPointerEvent) => {
    if (e.pointerType !== 'mouse') return
    if (Date.now() - lastTouchAt.current < 1000) return
    const dx = Math.abs(e.clientX - lastMousePos.current.x)
    const dy = Math.abs(e.clientY - lastMousePos.current.y)
    if (lastMousePos.current.x >= 0 && dx < 3 && dy < 3) return
    lastMousePos.current = { x: e.clientX, y: e.clientY }
    poke(3000)
  }

  /* ── hold & tap / double-tap ── */
  const holdStart = (allow = true) => {
    if (!allow) return
    const h = hold.current
    window.clearTimeout(h.timer)
    h.timer = window.setTimeout(() => {
      const v = vid.current
      if (!v || castOn.current || v.paused || st.current.pop) return
      h.on = true
      h.prev = v.playbackRate
      v.playbackRate = pfRef.current.hold
      setHeld(true)
    }, 400)
  }
  const holdEnd = () => {
    const h = hold.current
    window.clearTimeout(h.timer)
    if (!h.on) return false
    h.on = false
    if (vid.current) vid.current.playbackRate = h.prev
    setHeld(false)
    return true
  }
  const resetGestures = () => {
    clearTimeout(tap.current.timer)
    clearTimeout(unlockTimer.current)
    unlockAt.current = 0
    uiPointerDownSeen.current = false
    setRevealLock(false)
    tap.current.t = 0
    tap.current.side = 0
    tap.current.chainSide = 0
    tap.current.chainUntil = 0
    tap.current.revealedAt = 0
    gesture.current.pointers.clear()
    gesture.current.multi = false
    gesture.current.moved = false
    holdEnd()
  }

  const handleTap = (opts: { clientX: number; clientY: number; rect: DOMRect; isTouch: boolean; wasVisible: boolean }) => {
    const now = Date.now()
    lastHandledTapAt.current = now
    uiPointerDownSeen.current = false
    if (opts.isTouch) lastTouchAt.current = now

    const r = opts.rect
    const xFrac = rot90Ref.current
      ? (r.height > 0 ? (opts.clientY - r.top) / r.height : 0.5)
      : (r.width > 0 ? (opts.clientX - r.left) / r.width : 0.5)

    clearTimeout(tap.current.timer)
    const action = resolveStageTapAction({
      now,
      xFrac,
      isTouch: opts.isTouch,
      wasVisible: opts.wasVisible,
      isShowingNow: st.current.show,
      hasOpenPopup: Boolean(st.current.pop),
      tapState: {
        t: tap.current.t,
        side: tap.current.side,
        chainSide: tap.current.chainSide,
        chainUntil: tap.current.chainUntil,
        revealedAt: tap.current.revealedAt,
      },
    })
    tap.current.t = action.nextState.t
    tap.current.side = action.nextState.side
    tap.current.chainSide = action.nextState.chainSide
    tap.current.chainUntil = action.nextState.chainUntil
    tap.current.revealedAt = action.nextState.revealedAt

    switch (action.kind) {
      case 'close-popup':
        closePop()
        poke(3000)
        return
      case 'desktop-click':
        if (action.armRevealLock) armRevealLock(420)
        poke(3000)
        togglePlay()
        if (action.toggleFullscreen) toggleFs()
        return
      case 'touch-seek':
        seek(action.side * pfRef.current.seek, true)
        if (st.current.show) poke(3000)
        return
      case 'touch-show-now':
        if (action.armRevealLock) armRevealLock(420)
        poke(3000)
        return
      case 'touch-show-delayed':
        tap.current.timer = window.setTimeout(() => {
          tap.current.t = 0
          tap.current.side = 0
          if (!st.current.pop && !st.current.sheet && !st.current.show) {
            tap.current.revealedAt = Date.now()
            armRevealLock(420)
            poke(3000)
          }
        }, action.delayMs)
        return
      case 'touch-keep-visible':
        poke(3000)
        return
      case 'touch-hide-now':
        clearTimeout(hideT.current)
        if (!st.current.pop && !st.current.sheet) {
          st.current.show = false
          setShow(false)
          setRevealLock(false)
        }
        return
      case 'touch-hide-delayed':
        tap.current.timer = window.setTimeout(() => {
          tap.current.t = 0
          tap.current.side = 0
          clearTimeout(hideT.current)
          if (!st.current.pop && !st.current.sheet) {
            st.current.show = false
            setShow(false)
            setRevealLock(false)
          }
        }, action.delayMs)
        return
    }
  }

  /* ── seek bar ── */
  const frac = (e: RPointerEvent) => {
    const r = bar.current!.getBoundingClientRect()
    return clamp(rot90Ref.current ? (e.clientY - r.top) / r.height : (e.clientX - r.left) / r.width, 0, 1)
  }
  // one seek at a time on the preview video; always lands on the newest hovered time
  const pvGo = () => {
    const p = pv.current
    if (!p || pvT.current == null || p.seeking || p.readyState < 1) return
    const t = pvT.current
    pvT.current = null
    p.currentTime = t
  }
  const pvSeek = (t: number) => {
    if (!dur || (navigator as any).connection?.saveData) return
    if (!pvOn) setPvOn(true)
    pvT.current = clamp(t, 0, Math.max(0, dur - 0.5))
    pvGo()
  }
  const sDown = (e: RPointerEvent<HTMLDivElement>) => {
    if (!dur) return
    if (isPartyGuest) {
      toast('Playback scrub is controlled by the party host', 'info')
      return
    }
    e.currentTarget.setPointerCapture(e.pointerId)
    setScrub(frac(e) * dur)
    pvSeek(frac(e) * dur)
  }
  const sMove = (e: RPointerEvent<HTMLDivElement>) => {
    if (isPartyGuest) return
    const f = frac(e)
    setHover(f)
    pvSeek(f * dur)
    if (scrub !== null) setScrub(f * dur)
  }
  const sUp = (e: RPointerEvent<HTMLDivElement>) => {
    if (isPartyGuest || scrub === null) return
    const t = frac(e) * dur
    if (dur > 0 && t < Math.max(0, dur - 2)) hasEndedRef.current = false
    if (castOn.current) castSeek(t)
    else if (vid.current) vid.current.currentTime = t
    lastTimeRef.current = t
    setTime(t)
    if (dur > 0) persistOrClearScopedPos(animeId, episode, season, isTmdb, t, dur, false)
    setScrub(null)
    poke()
  }

  const shown = scrub ?? time
  const pct = dur ? clamp((shown / dur) * 100, 0, 100) : 0
  const tipF = scrub !== null ? scrub / dur : hover
  const vShown = muted ? 0 : vol
  const fsEl = getFullscreenElement()
  const isCurrentlyFullscreen = Boolean(fsEl && root.current && (fsEl === root.current || root.current.contains(fsEl)))
  const fs = isFs || fake || isCurrentlyFullscreen
  const adj = (d: number) => setOffset((o) => Math.round((o + d) * 10) / 10)
  const avail = availableEpisodes ?? totalEpisodes
  const target = (fs && (stageRef.current || root.current)) ? (stageRef.current || root.current)! : document.body
  const seg = (s: Seg) => (s && dur > 0 && s.end > s.start ? { left: `${(s.start / dur) * 100}%`, width: `${((s.end - s.start) / dur) * 100}%` } : null)
  const sr = seg(safeRecap)
  const si = seg(safeIntro)
  const so = seg(safeOutro)
  const isPopTop = activeAnchor?.top !== undefined
  const isPopLeft = activeAnchor?.left !== undefined
  const popTransformOrigin = `${isPopTop ? 'top' : 'bottom'} ${isPopLeft ? 'left' : 'right'}`
  const isAudioLoading = Boolean(audioLoading || switching || !mediaReady || (busy && audioTracks.length === 0))

  const langPrompt = useMemo(() => {
    if (preview || isAudioLoading || busy || !mediaReady || !savedPrefLang.trim()) return null
    const promptKey = `${animeId}:${episode}:${savedPrefLang}:${serverId ?? ''}`
    if (dismissedLangPrompt === promptKey) return null

    const wantLabel = formatLangLabel(savedPrefLang)
    const wantIsOrig = isOriginalTrack({ label: savedPrefLang, lang: savedPrefLang }, origLang)

    // 1. Multi-track HLS stream in dub mode
    if (audioMode === 'dub' && audioTracks.length > 0) {
      const identifiable = audioTracks.length > 1 || audioTracks.some(hasIdentifiableLang)
      if (identifiable && !audioTracks.some((t) => trackMatchesLang(t, savedPrefLang))) {
        const active = audioTracks.find((t) => t.i === audioIdx) ?? audioTracks[0]
        const nonOrig = audioTracks.filter((t) => !isOriginalTrack(t, origLang))
        const candidates = nonOrig.length > 0 ? nonOrig : audioTracks
        return {
          key: promptKey,
          wantLabel,
          currentLabel: active?.label || 'Another language',
          tracks: candidates.slice(0, 3),
          dubOptions: null as typeof dubs | null,
          fallbackToSub: false,
        }
      }
    }

    // 2. Movie / separate dub streams list (only check once dub tracks actually have identifiable labels)
    if (audioTracks.length < 2 && dubs && dubs.length > 0 && audioMode === 'dub') {
      const dubCandidates = dubs.filter((d) => !isOriginalTrack({ label: d.label, lang: '' }, origLang))
      const identifiableDub = dubCandidates.length > 1 || dubCandidates.some((d) => hasIdentifiableLang({ label: d.label, lang: '' }))
      const hasMatch = dubs.some((d) => trackMatchesLang({ label: d.label, lang: '' }, savedPrefLang))
      if (identifiableDub && !hasMatch) {
        const clean = (s: string) =>
          (s || 'Audio')
            .replace(/^(?:MovieBox|Vidzee|CineSrc|CinemaOS|Videasy|VidLink|VidFast|VidSrc|PrimeSrc)\s*(?:Direct|Pro)?\s*[·\-:]?\s*/i, '')
            .replace(/\b(?:MovieBox|Vidzee|Direct)\b/gi, '')
            .trim() || 'Original'
        const sel = dubs.find((d) => d.selected) ?? dubs[0]
        return {
          key: promptKey,
          wantLabel,
          currentLabel: clean(sel?.label || 'Another language'),
          tracks: null as typeof audioTracks | null,
          dubOptions: dubs.slice(0, 3),
          fallbackToSub: false,
        }
      }
    }

    // 3. User prefers dub + specific non-original language, but episode has no dub at all (only sub)
    if (!wantIsOrig && (getPrefs().audio ?? 'dub') === 'dub' && !hasDub && hasSub && audioMode === 'sub') {
      return {
        key: promptKey,
        wantLabel,
        currentLabel: origSubLabel,
        tracks: null as typeof audioTracks | null,
        dubOptions: null as typeof dubs | null,
        fallbackToSub: true,
      }
    }

    return null
  }, [preview, isAudioLoading, busy, mediaReady, savedPrefLang, animeId, episode, serverId, dismissedLangPrompt, audioMode, audioTracks, audioIdx, dubs, hasDub, hasSub, origLang, origSubLabel])

  if (embedUrl) {
    return (
      <div ref={root} data-zk-player className={cx('zp')}>
        <iframe
          key={embedUrl}
          src={embedUrl}
          title={title}
          allow={EXTERNAL_PLAYER_ALLOW_PERMISSIONS}
          sandbox={embedSandboxed ? EMBED_POPUP_BLOCKED_SANDBOX : undefined}
          allowFullScreen
          referrerPolicy="origin"
          onLoad={() => onPlay?.()}
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', border: 0, background: '#000' }}
        />
        {switching && (
          <div className="zp-toast" role="status" aria-live="polite">
            <Loader2 className="size-3.5 animate-spin shrink-0 text-white" />
            <span>Switching stream…</span>
          </div>
        )}
      </div>
    )
  }

  return (
    <div
      ref={root}
      data-zk-player
      className={cx('zp', fs && 'zp-fs', fake && 'zp-fake', rot90 && 'zp-rot', show && 'show', revealLock && 'zp-unlocking', !playing && 'zp-paused', fb && !show && 'zp-mini')}
      onTouchStartCapture={() => { lastTouchAt.current = Date.now() }}
      onTouchEndCapture={() => { lastTouchAt.current = Date.now() }}
      onPointerMove={onMouseMovePoke}
    >
      <div ref={stageRef} className="zp-stage">
      <video
        ref={vid}
        className="zp-v"
        style={{ ...aspectStyle(ar, fs), filter: videoFilterStyle, transform: pf.flip || pf.zoom !== 100 ? `scale(${pf.zoom / 100}) scaleX(${pf.flip ? -1 : 1})` : undefined }}
        playsInline
        controlsList="nodownload"
        preload="auto"
        onTimeUpdate={onTime}
        onDurationChange={() => !castOn.current && setDur(vid.current?.duration || 0)}
        onLoadStart={() => {
          // a fresh <video>/source starts at full volume: re-apply the saved level
          const v = vid.current
          if (!v || castOn.current) return
          const sv = clamp(readNum('zp-vol', 1), 0, 1)
          const sm = readNum('zp-mute', 0) === 1
          if (v.volume !== sv) v.volume = sv
          if (v.muted !== sm) v.muted = sm
        }}
        onLoadedMetadata={() => {
          if (castOn.current) return
          const v = vid.current
          if (v?.duration && isFinite(v.duration)) setDur(v.duration)
          if (v && v.readyState >= 2) {
            setPlaybackReady(true)
            setBusy(false)
          }
        }}
        onLoadedData={() => {
          if (castOn.current) return
          setPlaybackReady(true)
          setBusy(false)
        }}
        onPlay={() => {
          if (castOn.current) return
          if (!wantPlayRef.current && !isExternalAction.current) {
            vid.current?.pause()
            return
          }
          const v = vid.current
          if (hasEndedRef.current && v) {
            hasEndedRef.current = false
            lastTimeRef.current = 0
            skipped.current = -1
            clearScopedPos(animeId, episode, season, isTmdb)
            const effectiveDur = v.duration && isFinite(v.duration) && v.duration > 0 ? v.duration : dur
            if (effectiveDur > 0 && v.currentTime >= Math.max(0, effectiveDur - 1.5)) {
              v.currentTime = 0
              setTime(0)
              hls.current?.startLoad(0)
            }
          }
          setPlaying(true)
          if (!loadingSubs) setNote((n) => (n?.k === 'load' ? null : n))
          if (!isExternalAction.current && v) {
            onPlayerAction?.({ type: 'play', time: v.currentTime })
          }
          onPlay?.()
        }}
        onPause={() => {
          if (castOn.current) return
          const v = vid.current
          if (v && v.duration > 0) {
            persistOrClearScopedPos(animeId, episode, season, isTmdb, v.currentTime, v.duration, hasEndedRef.current || v.ended)
          }
          setPlaying(false)
          if (!wantPlayRef.current || (vid.current && vid.current.readyState >= 2)) {
            setBusy(false)
          }
          if (!isExternalAction.current && vid.current) {
            onPlayerAction?.({ type: 'pause', time: vid.current.currentTime })
          }
        }}
        onSeeked={() => {
          if (!castOn.current && vid.current && vid.current.readyState >= 2) {
            setPlaybackReady(true)
            setBusy(false)
          }
          if (!castOn.current && !isExternalAction.current && vid.current) {
            onPlayerAction?.({ type: 'seek', time: vid.current.currentTime })
          }
        }}
        onWaiting={() => {
          const v = vid.current
          if (!castOn.current && wantPlayRef.current && v && v.readyState < 3 && !v.paused) setBusy(true)
        }}
        onCanPlay={() => {
          if (castOn.current) return
          setPlaybackReady(true)
          setBusy(false)
          if (!loadingSubs) setNote((n) => (n?.k === 'load' ? null : n))
        }}
        onCanPlayThrough={() => {
          if (castOn.current) return
          setPlaybackReady(true)
          setBusy(false)
        }}
        onPlaying={() => {
          if (castOn.current) return
          if (!wantPlayRef.current && !isExternalAction.current) {
            vid.current?.pause()
            setPlaying(false)
            setBusy(false)
            return
          }
          wantPlayRef.current = true
          setPlaybackReady(true)
          setBusy(false)
          setMediaReady(true)
          if (!loadingSubs) setNote((n) => (n?.k === 'load' ? null : n))
          const v = vid.current
          if (v && v.duration) onProgress?.(Math.floor(v.currentTime), Math.floor(v.duration))
        }}
        onVolumeChange={() => {
          const v = vid.current
          if (!v || castOn.current) return
          setVol(v.volume)
          setMuted(v.muted)
          saveNum('zp-vol', v.volume)
          saveNum('zp-mute', v.muted ? 1 : 0)
        }}
        onEnded={() => {
          if (castOn.current) return
          hasEndedRef.current = true
          lastTimeRef.current = 0
          skipped.current = -1
          clearScopedPos(animeId, episode, season, isTmdb)
          setPlaying(false)
          onEnded?.()
        }}
      />
      {up && !upErr && <canvas ref={cv} className="zp-v" style={{ ...aspectStyle(ar, fs), opacity: upInt / 100, pointerEvents: 'none', filter: videoFilterStyle }} />}
      <div
        className="zp-g"
        onPointerDown={(e) => {
          if (e.pointerType === 'mouse' && e.button !== 0) return
          const g = gesture.current
          const now = Date.now()
          lastPointerLifecycleAt.current = now
          if (e.pointerType !== 'mouse') lastTouchAt.current = now

          // Prune any orphaned pointers from interrupted fullscreen/tab transitions so gestures never wedge
          for (const [pid, info] of g.pointers.entries()) {
            if (now - info.ts > 4000) g.pointers.delete(pid)
          }

          g.pointers.set(e.pointerId, {
            x: e.clientX,
            y: e.clientY,
            wasVisible: st.current.show,
            ts: now,
            type: e.pointerType,
          })

          if (g.pointers.size > 1) {
            g.multi = true
            holdEnd()
            return
          }

          g.multi = false
          g.moved = false
          if (e.pointerType === 'mouse' && st.current.show) {
            poke(3000)
          }
          holdStart(true)
        }}
        onPointerMove={(e) => {
          const g = gesture.current
          const entry = g.pointers.get(e.pointerId)
          if (entry && Math.hypot(e.clientX - entry.x, e.clientY - entry.y) > 36) {
            g.moved = true
            window.clearTimeout(hold.current.timer)
          }
          onMouseMovePoke(e)
        }}
        onPointerUp={(e) => {
          if (e.pointerType === 'mouse' && e.button !== 0) return
          const g = gesture.current
          const now = Date.now()
          lastPointerLifecycleAt.current = now
          const nativeEvt = e.nativeEvent as unknown as { sourceCapabilities?: { firesTouchEvents?: boolean } }
          const isTouch = resolveIsTouchInteraction({
            pointerType: e.pointerType,
            firesTouchEvents: nativeEvt?.sourceCapabilities?.firesTouchEvents,
            lastTouchAt: lastTouchAt.current,
            now,
          })
          if (isTouch) lastTouchAt.current = now
          const entry = g.pointers.get(e.pointerId)
          g.pointers.delete(e.pointerId)

          const wasMulti = g.multi
          const wasMoved = g.moved
          const wasPrimary = entry !== undefined || g.pointers.size === 0
          if (g.pointers.size === 0) {
            g.multi = false
            g.moved = false
          }

          const heldActive = holdEnd()
          if (heldActive || wasMulti || wasMoved || !wasPrimary) return
          if (entry && Math.hypot(e.clientX - entry.x, e.clientY - entry.y) > 48) return

          handleTap({
            clientX: e.clientX,
            clientY: e.clientY,
            rect: e.currentTarget.getBoundingClientRect(),
            isTouch,
            wasVisible: entry ? entry.wasVisible : st.current.show,
          })
        }}
        onPointerCancel={(e) => {
          const g = gesture.current
          lastPointerLifecycleAt.current = Date.now()
          g.pointers.delete(e.pointerId)
          if (g.pointers.size === 0) {
            g.multi = false
            g.moved = false
          }
          holdEnd()
        }}
        onLostPointerCapture={(e) => {
          const g = gesture.current
          lastPointerLifecycleAt.current = Date.now()
          g.pointers.delete(e.pointerId)
          if (g.pointers.size === 0) {
            g.multi = false
            g.moved = false
          }
        }}
        onClick={(e) => {
          const now = Date.now()
          if (
            shouldIgnoreGestureClick({
              detail: e.detail,
              now,
              lastHandledTapAt: lastHandledTapAt.current,
              lastPointerLifecycleAt: lastPointerLifecycleAt.current,
            })
          ) {
            return
          }
          if (st.current.pop) {
            closePop()
            poke(3000)
            return
          }
          const nativeEvt = e.nativeEvent as unknown as { pointerType?: string; sourceCapabilities?: { firesTouchEvents?: boolean } }
          const isTouch = resolveIsTouchInteraction({
            pointerType: nativeEvt?.pointerType,
            firesTouchEvents: nativeEvt?.sourceCapabilities?.firesTouchEvents,
            lastTouchAt: lastTouchAt.current,
            now,
          })
          handleTap({
            clientX: e.clientX,
            clientY: e.clientY,
            rect: e.currentTarget.getBoundingClientRect(),
            isTouch,
            wasVisible: st.current.show,
          })
        }}
        onContextMenu={(e) => e.preventDefault()}
      />
      {casting && (
        <div className="zp-cast" role="status" aria-live="polite">
          <span className="zp-castic big">
            <Cast />
          </span>
          <b>Casting to {cst.device || 'your device'}</b>
          <small>
            {title}{!isMovie ? ` · Episode ${episode}` : ''}
          </small>
          <button className="zp-pi" onClick={() => castStop()}>
            Stop casting
          </button>
        </div>
      )}

      <div className="zp-in">
        {busy && !err && <div className="zp-spn" />}
        {switching && <LoadingGrid label="Loading episode" className="pointer-events-none absolute bottom-16 left-4 z-30 text-white/70" />}
        {(note || switching) && (
          <div className={cx('zp-toast', (note?.k ?? 'load') === 'err' && 'err', (note?.k ?? 'load') === 'ok' && 'ok')} role="status" aria-live="polite" key={note?.msg ?? 'sw'}>
            {(note?.k ?? 'load') === 'load' ? <Loader2 className="size-3.5 animate-spin shrink-0 text-white" /> : note?.k === 'ok' ? <CheckCircle2 /> : <TriangleAlert />}
            <span>{note?.msg ?? 'Switching stream…'}</span>
          </div>
        )}

        {card && !err && (
          <div className="zp-card">
            <h3>{title}</h3>
            <p>
              {isMovie ? (
                format === 'MOVIE' ? 'Movie' : ''
              ) : (
                <>
                  Episode {episode}
                  {hasDistinctEpTitle ? ` · ${cleanEpTitle}` : ''}
                  {episodeKind ? ` · ${episodeKind === 'mixed' ? 'Mixed canon' : episodeKind === 'recap' ? 'Recap' : 'Filler'}` : ''}
                </>
              )}
              {!isAudioLoading && audioMode ? ` · ${audioMode.toUpperCase()}` : ''}
            </p>
          </div>
        )}

        {held && (
          <div className="zp-hold">
            <FastForward />
            <span>{pf.hold}×</span>
          </div>
        )}

        {fb && (
          <div key={fb.k} className={cx('zp-fb', fb.side < 0 ? 'l' : 'r')}>
            {fb.side < 0 ? <RotateCcw /> : <RotateCw />}
            <span>{fb.n} seconds</span>
          </div>
        )}

        {cue && !casting && (
          <div className="zp-sub" style={{ '--sp': `${cs.pos}%`, justifyContent: { left: 'flex-start', center: 'center', right: 'flex-end' }[cs.align] } as CSSProperties}>
            <span
              style={capCss(cs, 'var(--u)')}
            >
              {cue}
            </span>
          </div>
        )}

        {skip && (
          <button
            type="button"
            className="zp-sk"
            data-skip-kind={skip.kind}
            disabled={skipDisabled}
            aria-disabled={skipDisabled}
            aria-label={skip.label}
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation()
              doSkip()
            }}
          >
            <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
              <path d="M2 5.5v13l8.5-6.5L2 5.5zm8.5 0v13l8.5-6.5-8.5-6.5zM19.5 5.5h2.25v13H19.5v-13z" />
            </svg>
            <span>{skip.label}</span>
          </button>
        )}
        {upNext && (
          <button
            type="button"
            className="zp-sk"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation()
              onNextEpisode?.()
            }}
          >
            <SkipForward />
            <span>Next · Ep {nextEpisode ?? episode + 1}</span>
          </button>
        )}
        {skipFill && (
          <div
            className="zp-sk zp-ask"
            role="group"
            aria-label={`Skip ${episodeKind}?`}
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => e.stopPropagation()}
          >
            <span>Skip {episodeKind}?</span>
            <button type="button" className="y" onClick={() => (setFillAsk(false), onNextEpisode?.())}>Yes</button>
            <button type="button" onClick={() => setFillAsk(false)}>No</button>
          </div>
        )}

        {langPrompt && (
          <div className="zp-lang-warn" role="alert" aria-live="polite" onClick={(e) => e.stopPropagation()} onPointerDown={(e) => e.stopPropagation()}>
            <div className="zp-lang-warn-h">
              <div className="zp-lang-warn-t">
                <Languages className="size-4 shrink-0" />
                <div>
                  <strong>Your preferred language ({langPrompt.wantLabel}) is not available</strong>
                  <p>Continue with another available language?</p>
                </div>
              </div>
              <button
                type="button"
                className="zp-lang-warn-x"
                onClick={() => setDismissedLangPrompt(langPrompt.key)}
                aria-label="Dismiss language notice"
              >
                <X className="size-3.5" />
              </button>
            </div>
            <div className="zp-lang-warn-actions">
              {langPrompt.tracks && langPrompt.tracks.length > 0 ? (
                langPrompt.tracks.map((t, idx) => (
                  <button
                    key={`lp-${t.i}`}
                    type="button"
                    className={idx === 0 ? 'primary' : undefined}
                    onClick={() => {
                      if (isPartyGuest) {
                        toast('Audio is controlled by party host', 'info')
                      } else {
                        setAudioTrack(t)
                      }
                      setDismissedLangPrompt(langPrompt.key)
                    }}
                  >
                    Continue with {t.label}
                  </button>
                ))
              ) : langPrompt.dubOptions && langPrompt.dubOptions.length > 0 ? (
                langPrompt.dubOptions.map((d, idx) => {
                  const cleanName =
                    (d.label || 'Audio')
                      .replace(/^(?:MovieBox|Vidzee|CineSrc|CinemaOS|Videasy|VidLink|VidFast|VidSrc|PrimeSrc)\s*(?:Direct|Pro)?\s*[·\-:]?\s*/i, '')
                      .replace(/\b(?:MovieBox|Vidzee|Direct)\b/gi, '')
                      .trim() || 'Original'
                  return (
                    <button
                      key={`lpd-${d.id}`}
                      type="button"
                      className={idx === 0 ? 'primary' : undefined}
                      onClick={() => {
                        setDismissedLangPrompt(langPrompt.key)
                        if (!d.selected) {
                          flash('load', `Switching to ${cleanName}…`)
                          onDub?.(d.id)
                        }
                      }}
                    >
                      Continue with {cleanName}
                    </button>
                  )
                })
              ) : (
                <button
                  type="button"
                  className="primary"
                  onClick={() => setDismissedLangPrompt(langPrompt.key)}
                >
                  Continue with {langPrompt.currentLabel}
                </button>
              )}
            </div>
          </div>
        )}

        <div
          className="zp-ui"
          onPointerDownCapture={(e) => {
            if (Date.now() < unlockAt.current) {
              uiPointerDownSeen.current = false
              e.preventDefault()
              e.stopPropagation()
              return
            }
            uiPointerDownSeen.current = true
          }}
          onClickCapture={(e) => {
            const blocked = shouldBlockSyntheticUiClick({
              detail: e.detail,
              now: Date.now(),
              unlockAt: unlockAt.current,
              uiPointerDownSeen: uiPointerDownSeen.current,
              lastGestureTapAt: lastHandledTapAt.current,
            })
            uiPointerDownSeen.current = false
            if (blocked) {
              e.preventDefault()
              e.stopPropagation()
            }
          }}
        >
          <div className="zp-sc" />

          <div className="zp-top">
            <div className="zp-ti">
              <h3>{title}</h3>
              {!isMovie && (
                <p>
                  Episode {episode}
                  {hasDistinctEpTitle ? ` · ${cleanEpTitle}` : ''}
                </p>
              )}
            </div>
            <div className="zp-ac">
              {servers && servers.length > 0 && (
                <button className="zp-b" data-tour="p-srv" onClick={(e) => setPop('srv', e.currentTarget)} aria-label="Servers" title="Servers">
                  <Server />
                </button>
              )}
              {onSelectEpisode && totalEpisodes > 1 && (
                <button className="zp-b" onClick={() => setSheet('eps')} aria-label="Episodes" title="Episodes">
                  <List />
                </button>
              )}
              <button
                className="zp-b"
                onClick={() => {
                  setReportSuccess(null)
                  setSheet('report')
                }}
                aria-label="Report Issue"
                title="Report playback or stream issue"
              >
                <Flag />
              </button>
            </div>
          </div>

          {!err && (
            <div className="zp-mid">
              {!isMovie && (
                <button
                  className={cx('zp-b zp-pn', isPartyGuest && 'opacity-40 cursor-not-allowed')}
                  disabled={isPartyGuest || !hasPrevEpisode}
                  onClick={() => onPrevEpisode?.()}
                  aria-label="Previous episode"
                  title={isPartyGuest ? 'Episode changes controlled by party host' : 'Previous episode'}
                >
                  <SkipBack />
                </button>
              )}
              <button
                className={cx('zp-b zp-sd', isPartyGuest && 'opacity-40 cursor-not-allowed')}
                disabled={isPartyGuest}
                onClick={() => seek(-pf.seek)}
                aria-label={`Back ${pf.seek} seconds`}
                title={isPartyGuest ? 'Timestamp controlled by party host' : `Back ${pf.seek}s [J]`}
              >
                <RotateCcw />
                <span className="zp-n">{pf.seek}</span>
              </button>
              <button
                className="zp-b zp-hero"
                data-tour="p-play"
                disabled={playDisabled}
                aria-disabled={playDisabled}
                onClick={togglePlay}
                aria-label={playing ? 'Pause' : 'Play'}
                title={playDisabled ? 'Loading video…' : 'Play / pause [Space]'}
              >
                <Play className={cx('zp-ic pl', playing && 'off')} fill="currentColor" />
                <Pause className={cx('zp-ic', !playing && 'off')} fill="currentColor" />
              </button>
              <button
                className={cx('zp-b zp-sd', isPartyGuest && 'opacity-40 cursor-not-allowed')}
                disabled={isPartyGuest}
                onClick={() => seek(pf.seek)}
                aria-label={`Forward ${pf.seek} seconds`}
                title={isPartyGuest ? 'Timestamp controlled by party host' : `Forward ${pf.seek}s [L]`}
              >
                <RotateCw />
                <span className="zp-n">{pf.seek}</span>
              </button>
              {!isMovie && (
                <button
                  className={cx('zp-b zp-pn', isPartyGuest && 'opacity-40 cursor-not-allowed')}
                  disabled={isPartyGuest || !hasNextEpisode}
                  onClick={() => onNextEpisode?.()}
                  aria-label="Next episode"
                  title={isPartyGuest ? 'Episode changes controlled by party host' : 'Next episode'}
                >
                  <SkipForward />
                </button>
              )}
            </div>
          )}

          <div className="zp-bot">
            <div className="zp-sr">
              <span className="zp-tm">{fmt(shown)}</span>
              <div
                ref={bar}
                data-tour="p-seek"
                className={cx('zp-seek', scrub !== null && 'drag', isPartyGuest && 'cursor-not-allowed opacity-85')}
                role="slider"
                aria-label="Seek"
                title={isPartyGuest ? 'Playback timestamp is controlled by party host' : undefined}
                aria-valuemin={0}
                aria-valuemax={Math.round(dur)}
                aria-valuenow={Math.round(shown)}
                onPointerDown={sDown}
                onPointerMove={sMove}
                onPointerUp={sUp}
                onPointerCancel={() => setScrub(null)}
                onPointerLeave={() => setHover(null)}
              >
                <div className="zp-tr">
                  <i className="zp-bf" style={{ width: `${buf * 100}%` }} />
                  <i className="zp-pl" style={{ width: `${pct}%` }} />
                  {sr && <i className="zp-seg" style={sr} />}
                  {si && <i className="zp-seg" style={si} />}
                  {so && <i className="zp-seg" style={so} />}
                  <i className="zp-th" style={{ left: `${pct}%` }} />
                </div>
                <div className={cx('zp-tip', tipF != null && dur > 0 && 'on', pvRdy && 'rdy')} style={{ '--x': `${(tipF ?? 0) * 100}%` } as CSSProperties} aria-hidden="true">
                  <video
                    ref={pv}
                    className="zp-pv"
                    muted
                    playsInline
                    preload="auto"
                    disablePictureInPicture
                    tabIndex={-1}
                    onLoadedMetadata={pvGo}
                    onSeeked={() => {
                      setPvRdy(true)
                      pvGo()
                    }}
                  />
                  <b>{fmt((tipF ?? 0) * dur)}</b>
                </div>
              </div>
              <span className="zp-tm r">{fmt(dur)}</span>
            </div>

            <div className="zp-cr">
              <div className="zp-vg">
                <button className="zp-b" onClick={toggleMute} aria-label={vShown === 0 ? 'Unmute' : 'Mute'} title="Mute [M]">
                  {vShown === 0 ? <VolumeX /> : vShown < 0.5 ? <Volume1 /> : <Volume2 />}
                </button>
                <input
                  className="zp-vol"
                  type="range"
                  min="0"
                  max="1"
                  step="0.02"
                  value={vShown}
                  style={{ '--p': `${vShown * 100}%` } as React.CSSProperties}
                  onChange={(e) => setVolume(+e.target.value)}
                  aria-label="Volume"
                />
              </div>
              <span className="zp-flex" />
              {(() => {
                const subOnlyAnime = !isTmdb && audioMode === 'sub'
                const origTrack = (t: { label: string; lang: string }) => isOriginalTrack(t, origLang)
                const visAudioTracks = subOnlyAnime
                  ? audioTracks.filter(origTrack)
                  : audioTracks
                const showAudioPill = subOnlyAnime
                  ? true
                  : isAudioLoading || visAudioTracks.length > 1 || (dubs ? dubs.length > 1 : Boolean(onAudio && hasSub && hasDub))
                if (!showAudioPill) return null
                return (
                <button
                  className={cx('zp-b pill zp-aud-pill', pop === 'aud' && 'on', isPartyGuest && 'opacity-50 cursor-not-allowed')}
                  data-tour="p-audio"
                  onClick={(e) => {
                    if (isPartyGuest) {
                      toast('Audio is controlled by party host', 'info')
                      return
                    }
                    setPop('aud', e.currentTarget)
                  }}
                  title="Audio / Dub"
                  aria-label="Audio / Dub"
                >
                  {isAudioLoading ? <Loader2 className="animate-spin" /> : <Languages />}
                  <em>
                    {isAudioLoading
                      ? 'Loading…'
                      : subOnlyAnime
                        ? origSubLabel
                        : visAudioTracks.length > 1
                          ? ((visAudioTracks.find((t) => t.i === audioIdx)?.label || '').trim() || 'Audio')
                          : dubs && dubs.length > 0
                            ? ((dubs.find((d) => d.selected)?.label ?? dubs[0]?.label ?? '')
                                .replace(/^(?:MovieBox|Vidzee|CineSrc|CinemaOS|Videasy|VidLink|VidFast|VidSrc|PrimeSrc)\s*(?:Direct|Pro)?\s*[·\-:]?\s*/i, '')
                                .replace(/\b(?:MovieBox|Vidzee|Direct)\b/gi, '')
                                .trim() || (audioMode === 'dub' ? 'Dub' : origSubLabel))
                            : visAudioTracks.length === 1 && visAudioTracks[0]?.label && !/^track\s*\d+$/i.test(visAudioTracks[0].label.trim())
                              ? visAudioTracks[0].label.trim()
                              : audioMode === 'dub'
                                ? 'Dub'
                                : origSubLabel}
                  </em>
                </button>
                )
              })()}
              <button className={cx('zp-b pill zp-spd-btn', pop === 'spd' && 'on')} onClick={(e) => setPop('spd', e.currentTarget)} aria-label="Playback speed" title="Playback speed">
                {speed}×
              </button>
              {levels.length > 0 && (
                <button className={cx('zp-b pill zp-q-btn', pop === 'q' && 'on')} onClick={(e) => setPop('q', e.currentTarget)} aria-label="Quality" title="Quality">
                  {lvl === -1 ? 'Auto' : levels.find((l) => l.i === lvl)?.label}
                </button>
              )}
              <button className={cx('zp-b', (pop === 'cc' || (caps && tracks.length > 0)) && 'on')} data-tour="p-cc" onClick={(e) => setPop('cc', e.currentTarget)} aria-label="Subtitles" title="Subtitles [C]">
                <span className="zp-t">CC</span>
              </button>
              {onWatchTogetherClick && (
                <button
                  type="button"
                  className={cx('zp-b relative', watchPartyActive && 'text-accent')}
                  onClick={onWatchTogetherClick}
                  aria-label="Watch Together"
                  title={watchPartyActive ? `Watch Together (${watchPartyPeersCount || 1} peers)` : 'Start Watch Together'}
                >
                  <Users />
                  {watchPartyActive && (
                    <span className="absolute -top-1 -right-1 flex size-3.5 items-center justify-center rounded-full bg-accent text-[8px] font-bold text-accent-fg animate-pulse">
                      {watchPartyPeersCount || 1}
                    </span>
                  )}
                </button>
              )}
              <button className="zp-b" data-tour="p-set" onClick={() => (closePop(), setSheet('set'))} aria-label="Settings" title="Settings">
                <Settings />
              </button>
              {canCast && castAvail && (
                <button
                  className={cx('zp-b', casting && 'on')}
                  data-tour="p-cast"
                  onClick={() => (closePop(), setSetTab('cast'), setSheet('set'))}
                  aria-label={casting ? `Casting to ${cst.device || 'device'}` : 'Cast'}
                  title={casting ? `Casting to ${cst.device || 'device'}` : 'Cast to TV'}
                >
                  <Cast />
                </button>
              )}
              <button className="zp-b zp-fs-btn" data-tour="p-fs" onClick={toggleFs} aria-label={fs ? 'Exit fullscreen' : 'Fullscreen'} title="Fullscreen [F]">
                {fs ? <Minimize /> : <Maximize />}
              </button>
            </div>
          </div>
        </div>


        {createPortal(
          <AnimatePresence>
            {pop && (
              <motion.div
                ref={popRef}
                key={pop}
                className={cx('zp-pop', pop === 'cc' && 'zp-pop-cc', activeAnchor?.fixed && !fs && 'zp-pop-portal')}
                role="menu"
                aria-label={pop}
                onPointerDown={(e) => e.stopPropagation()}
                onWheel={(e) => e.stopPropagation()}
                onTouchMove={(e) => e.stopPropagation()}
                initial={{ opacity: 0, scale: 0.3, borderRadius: blob(120)[0] }}
                animate={{ opacity: 1, scale: 1, borderRadius: blob(120) }}
                exit={{ opacity: 0, scale: 0.6, transition: { duration: 0.14 } }}
                transition={{ ...SPRING, borderRadius: BLOB_T }}
                style={{
                  transformOrigin: popTransformOrigin,
                  ...(activeAnchor
                    ? {
                        top: activeAnchor.top !== undefined ? `${activeAnchor.top}px` : 'auto',
                        bottom: activeAnchor.bottom !== undefined ? `${activeAnchor.bottom}px` : 'auto',
                        left: activeAnchor.left !== undefined ? `${activeAnchor.left}px` : 'auto',
                        right: activeAnchor.right !== undefined ? `${activeAnchor.right}px` : 'auto',
                        ...(activeAnchor.fixed && !fs && activeAnchor.maxHeight ? { maxHeight: `${activeAnchor.maxHeight}px` } : {}),
                      }
                    : undefined),
                }}
              >
              {pop === 'spd' && (
                <>
                  <p className="zp-ph">Speed</p>
                  <div className="flex flex-col gap-0.5">
                    {SPEEDS.map((x, i) => (
                      <motion.button
                        key={x}
                        type="button"
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.03 + i * 0.02, duration: 0.18 }}
                        className={cx('zp-row', speed === x && 'on')}
                        onClick={() => (setRate(x), closePop())}
                      >
                        <span>{x === 1 ? 'Normal' : `${x}×`}</span>
                        {speed === x && <Check className="size-3.5 shrink-0 text-accent text-[var(--a,#dc143c)]" />}
                      </motion.button>
                    ))}
                  </div>
                </>
              )}
              {pop === 'q' && (
                <>
                  <p className="zp-ph">Quality</p>
                  <div className="flex flex-col gap-0.5">
                    {!isFileSrc(streamUrl) && (
                      <motion.button
                        type="button"
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.03, duration: 0.18 }}
                        className={cx('zp-row', lvl === -1 && 'on')}
                        onClick={() => (setQuality(-1), closePop())}
                      >
                        <span>Auto</span>
                        {lvl === -1 && <Check className="size-3.5 shrink-0 text-accent text-[var(--a,#dc143c)]" />}
                      </motion.button>
                    )}
                    {levels.map((l: any, i: number) => (
                      <motion.button
                        key={l.i}
                        type="button"
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.05 + i * 0.02, duration: 0.18 }}
                        className={cx('zp-row', lvl === l.i && 'on')}
                        onClick={() => (setQuality(l.i), closePop())}
                      >
                        <div className="flex items-center justify-between w-full pr-1">
                          <span>{l.label}</span>
                          {l.sub && <span className="text-[11px] opacity-60 font-mono ml-2">({l.sub})</span>}
                        </div>
                        {lvl === l.i && <Check className="size-3.5 shrink-0 text-accent text-[var(--a,#dc143c)]" />}
                      </motion.button>
                    ))}
                  </div>
                </>
              )}
              {pop === 'aud' && (
                <>
                  <p className="zp-ph">Audio / Dub</p>
                  <div className="flex flex-col gap-0.5">
                    {isAudioLoading ? (
                      <div className="flex items-center gap-2 px-3 py-2 text-xs text-white/60">
                        <Loader2 className="size-3.5 animate-spin text-[var(--a,#dc143c)]" />
                        <span>Loading audio tracks…</span>
                      </div>
                    ) : !isTmdb && audioMode === 'sub' ? (
                      (() => {
                        const origOnly = audioTracks.filter((t) => isOriginalTrack(t, origLang))
                        if (origOnly.length > 0) {
                          return origOnly.map((t, i) => (
                            <motion.button
                              key={`tr-${t.i}`}
                              type="button"
                              initial={{ opacity: 0, y: 6 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 0.03 + i * 0.02, duration: 0.18 }}
                              className={cx('zp-row', (t.i === audioIdx || origOnly.length === 1) && 'on')}
                              onClick={() => {
                                if (origOnly.length > 1) setAudioTrack(t)
                                closePop()
                              }}
                            >
                              <span>{t.label || origDetailLabel}</span>
                              {(t.i === audioIdx || origOnly.length === 1) && <Check className="size-3.5 shrink-0 text-accent text-[var(--a,#dc143c)]" />}
                            </motion.button>
                          ))
                        }
                        return (
                          <button type="button" className="zp-row on" onClick={() => closePop()}>
                            <span>{origSubLabel}</span>
                            <Check className="size-3.5 shrink-0 text-accent text-[var(--a,#dc143c)]" />
                          </button>
                        )
                      })()
                    ) : (
                      <>
                        {(audioTracks.length > 1 ? audioTracks : []).map((t, i) => (
                          <motion.button
                            key={`tr-${t.i}`}
                            type="button"
                            initial={{ opacity: 0, y: 6 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.03 + i * 0.02, duration: 0.18 }}
                            className={cx('zp-row', t.i === audioIdx && 'on')}
                            onClick={() => {
                              if (isPartyGuest) {
                                toast('Audio is controlled by party host', 'info')
                                closePop()
                                return
                              }
                              setAudioTrack(t)
                              closePop()
                            }}
                          >
                            <span>{t.label}</span>
                            {t.i === audioIdx && <Check className="size-3.5 shrink-0 text-accent text-[var(--a,#dc143c)]" />}
                          </motion.button>
                        ))}
                        {audioTracks.length < 2 && dubs && dubs.length > 0 && dubs.map((d, i) => {
                          const cleanName =
                            (d.label || 'Audio')
                              .replace(/^(?:MovieBox|Vidzee|CineSrc|CinemaOS|Videasy|VidLink|VidFast|VidSrc|PrimeSrc)\s*(?:Direct|Pro)?\s*[·\-:]?\s*/i, '')
                              .replace(/\b(?:MovieBox|Vidzee|Direct)\b/gi, '')
                              .trim() || 'Original'
                          return (
                            <motion.button
                              key={d.id}
                              type="button"
                              initial={{ opacity: 0, y: 6 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 0.03 + i * 0.02, duration: 0.18 }}
                              className={cx('zp-row', d.selected && 'on')}
                              onClick={() => {
                                closePop()
                                if (d.selected) return
                                flash('load', `Switching to ${cleanName}…`)
                                onDub?.(d.id)
                              }}
                            >
                              <span>{cleanName}</span>
                              {d.selected && <Check className="size-3.5 shrink-0 text-accent text-[var(--a,#dc143c)]" />}
                            </motion.button>
                          )
                        })}
                        {audioTracks.length < 2 && (!dubs || dubs.length === 0) && onAudio && (
                          <>
                            {(['dub', 'sub'] as const)
                              .filter((m) => (m === 'sub' ? hasSub : hasDub))
                              .map((m, i) => (
                                <motion.button
                                  key={m}
                                  type="button"
                                  initial={{ opacity: 0, y: 6 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  transition={{ delay: 0.03 + i * 0.02, duration: 0.18 }}
                                  className={cx('zp-row', audioMode === m && 'on')}
                                  onClick={() => {
                                    closePop()
                                    if (audioMode === m) return
                                    flash('load', `Switching to ${m === 'dub' ? 'Dub' : origSubLabel}…`)
                                    onAudio(m)
                                  }}
                                >
                                  <span>
                                    {m === 'dub'
                                      ? (audioTracks[0]?.label && !/^(track|audio|stream|default|main)\s*#?\d*$/i.test(audioTracks[0].label.trim())
                                          ? audioTracks[0].label.trim()
                                          : 'English (Dub)')
                                      : origSubLabel}
                                  </span>
                                  {audioMode === m && <Check className="size-3.5 shrink-0 text-accent text-[var(--a,#dc143c)]" />}
                                </motion.button>
                              ))}
                          </>
                        )}
                      </>
                    )}
                  </div>
                </>
              )}
              {pop === 'srv' && servers && (
                <>
                  <p className="zp-ph">Servers</p>
                  {onAudio && (hasSub || hasDub) && (
                    <div className="zp-two zp-pad">
                      {(['sub', 'dub'] as const)
                        .filter((m) => (m === 'sub' ? hasSub : hasDub))
                        .map((m) => (
                          <button
                            key={m}
                            type="button"
                            disabled={isAudioLoading}
                            className={cx('zp-pi', audioMode === m && 'on', isAudioLoading && 'opacity-50 cursor-not-allowed')}
                            onClick={() => {
                              if (isAudioLoading) return
                              if (isPartyGuest) {
                                toast('Audio mode is controlled by party host', 'info')
                                return
                              }
                              if (audioMode !== m) {
                                flash('load', `Switching to ${m.toUpperCase()}…`)
                                onAudio(m)
                              }
                            }}
                          >
                            <span>{m.toUpperCase()}</span>
                          </button>
                        ))}
                    </div>
                  )}
                  <div className="flex flex-col gap-0.5">
                    {servers.map((x, i) => (
                      <motion.button
                        key={x.id}
                        type="button"
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.04 + i * 0.025, duration: 0.18 }}
                        className={cx('zp-row', x.id === serverId && 'on', isPartyGuest && 'opacity-60 cursor-not-allowed')}
                        onClick={() => {
                          if (isPartyGuest) {
                            toast('Server is controlled by party host', 'info')
                            return
                          }
                          if (x.id !== serverId) flash('load', `Switching to ${x.name}…`)
                          onServer?.(x.id)
                          closePop()
                        }}
                      >
                        <span className="flex flex-col items-start gap-0.5">
                          <span className="flex items-center gap-2">
                            <span>{x.name}</span>
                            {x.tags && x.tags.length > 0 && (
                              <span className="flex items-center gap-1 text-[10px] text-white/50">
                                {x.tags.map((t) => (
                                  <span key={t} className="rounded border border-white/15 px-1 text-[9px] font-bold uppercase leading-4 text-neutral-300">{t}</span>
                                ))}
                              </span>
                            )}
                          </span>
                        </span>
                        {x.id === serverId && <Check className="size-3.5 shrink-0 text-accent text-[var(--a,#dc143c)]" />}
                      </motion.button>
                    ))}
                  </div>
                </>
              )}
              {pop === 'cc' && (
                <div className="flex flex-col gap-1">
                  <div className="flex items-center justify-between border-b border-white/10 px-2 py-1 pb-2">
                    <div className="flex items-center gap-1.5">
                      <Languages className="size-3.5 text-white/70" />
                      <span className="text-[11px] font-bold uppercase tracking-wider text-white/80">Subtitles</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        closePop()
                        setSheet('subs')
                      }}
                      title="Customize subtitle styling & sync"
                      className="flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium text-white/60 hover:text-white hover:bg-white/5 transition"
                    >
                      <Settings className="size-3" />
                      <span>Settings</span>
                    </button>
                  </div>

                  {langs.length > 4 && (
                    <div className="relative my-1 px-1">
                      <Search className="pointer-events-none absolute left-3.5 top-1/2 size-3.5 -translate-y-1/2 text-white/40" />
                      <input
                        type="text"
                        value={subSearch}
                        onChange={(e) => setSubSearch(e.target.value)}
                        placeholder="Filter languages…"
                        aria-label="Filter languages"
                        className="h-8 w-full rounded-xl border border-white/10 bg-white/5 pl-8 pr-7 text-xs text-white placeholder:text-white/40 outline-none transition focus:border-white/30"
                      />
                      {subSearch && (
                        <button
                          type="button"
                          onClick={() => setSubSearch('')}
                          className="absolute right-3 top-1/2 -translate-y-1/2 p-0.5 text-white/40 hover:text-white"
                          aria-label="Clear filter"
                        >
                          <X className="size-3" />
                        </button>
                      )}
                    </div>
                  )}

                  <motion.button
                    type="button"
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.02, duration: 0.15 }}
                    onClick={() => {
                      setCaps(false)
                      closePop()
                    }}
                    className={cx(
                      'flex w-full items-center justify-between rounded-xl px-3 py-2 text-left text-xs font-medium transition',
                      !caps
                        ? 'bg-white/10 text-white font-semibold'
                        : 'text-white/70 hover:bg-white/5 hover:text-white'
                    )}
                  >
                    <span>Off</span>
                    {!caps && <Check className="size-3.5 text-accent text-[var(--a,#dc143c)] shrink-0" />}
                  </motion.button>

                  {loadingSubs && (
                    <div className="flex items-center gap-2 px-3 py-2 text-xs text-white/50">
                      <Loader2 className="size-3.5 animate-spin text-[var(--a,#dc143c)]" />
                      <span>Searching for subtitles…</span>
                    </div>
                  )}
                  {!loadingSubs && tracks.length === 0 && srcLeft === 0 && (
                    <p className="px-3 py-2 text-xs text-white/50">No subtitles found.</p>
                  )}
                  {subErr && <p className="px-3 py-1.5 text-xs text-amber-400">{subErr}</p>}

                  <div className="flex flex-col gap-0.5">
                    {filteredLangs.map(([name, list], i) => {
                      const isSingle = list.length === 1
                      const isLangActive = caps && list.some((t) => t.id === trackId)
                      const isExpanded = grp === name

                      if (isSingle) {
                        const t = list[0]
                        const isSelected = caps && t.id === trackId
                        const subLabel = formatTrackSubLabel(t.label, name)
                        const displayName = subLabel !== 'Default' ? `${name} (${subLabel})` : name

                        return (
                          <motion.button
                            key={name}
                            type="button"
                            initial={{ opacity: 0, y: 6 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.03 + Math.min(i, 8) * 0.02, duration: 0.15 }}
                            onClick={() => {
                              void pick(t)
                              closePop()
                            }}
                            className={cx(
                              'group flex w-full items-center justify-between gap-2 rounded-xl px-3 py-2 text-left transition',
                              isSelected
                                ? 'bg-white/10 text-white font-semibold'
                                : 'text-white/80 hover:bg-white/5 hover:text-white'
                            )}
                          >
                            <div className="min-w-0 flex-1">
                              <span className="truncate text-xs">{displayName}</span>
                              {t.source && <span className="block text-[10px] text-white/40">{t.source}</span>}
                            </div>
                            {isSelected && <Check className="size-3.5 shrink-0 text-accent text-[var(--a,#dc143c)]" />}
                          </motion.button>
                        )
                      }

                      return (
                        <motion.div
                          key={name}
                          initial={{ opacity: 0, y: 6 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.03 + Math.min(i, 8) * 0.02, duration: 0.15 }}
                          className="flex flex-col"
                        >
                          <button
                            type="button"
                            aria-expanded={isExpanded}
                            onClick={() => setGrp(isExpanded ? null : name)}
                            className={cx(
                              'group flex w-full items-center justify-between gap-2 rounded-xl px-3 py-2 text-left transition',
                              isLangActive
                                ? 'text-white font-semibold bg-white/5'
                                : 'text-white/80 hover:bg-white/5 hover:text-white'
                            )}
                          >
                            <div className="flex items-center gap-1.5 min-w-0">
                              <span className="truncate text-xs">{name}</span>
                              <span className="text-[10px] text-white/40">({list.length})</span>
                              {isLangActive && (
                                <span className="size-1.5 rounded-full bg-[var(--a,#dc143c)] shrink-0" />
                              )}
                            </div>
                            <ChevronDown
                              className={cx(
                                'size-3.5 text-white/40 transition-transform duration-200 shrink-0',
                                isExpanded && 'rotate-180 text-white'
                              )}
                            />
                          </button>

                          <AnimatePresence>
                            {isExpanded && (
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                exit={{ opacity: 0, height: 0 }}
                                transition={{ duration: 0.2 }}
                                className="overflow-hidden my-0.5 ml-3.5 flex flex-col gap-0.5 border-l border-white/10 pl-2"
                              >
                                {list.map((t) => {
                                  const isSelected = caps && t.id === trackId
                                  const subLabel = formatTrackSubLabel(t.label, name)
                                  return (
                                    <button
                                      key={t.id}
                                      type="button"
                                      onClick={() => {
                                        void pick(t)
                                        closePop()
                                      }}
                                      className={cx(
                                        'group flex w-full items-center justify-between gap-2 rounded-lg px-2.5 py-1.5 text-left transition',
                                        isSelected
                                          ? 'text-white font-semibold bg-white/10'
                                          : 'text-white/70 hover:bg-white/5 hover:text-white'
                                      )}
                                    >
                                      <div className="min-w-0 flex-1">
                                        <div className="flex items-center gap-1.5">
                                          <span className="truncate text-xs">{subLabel}</span>
                                          {isSelected && <span className="size-1 rounded-full bg-[var(--a,#dc143c)] shrink-0" />}
                                        </div>
                                        {t.source && (
                                          <span className="block text-[10px] text-white/40">
                                            {t.source}
                                          </span>
                                        )}
                                      </div>
                                      {isSelected && <Check className="size-3 shrink-0 text-accent text-[var(--a,#dc143c)]" />}
                                    </button>
                                  )
                                })}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </motion.div>
                      )
                    })}
                  </div>

                  {srcLeft > 0 && (
                    <p className="px-3 py-1 text-[10px] text-white/40">
                      Checking {srcLeft} more source{srcLeft > 1 ? 's' : ''}…
                    </p>
                  )}
                </div>
              )}
            </motion.div>
            )}
          </AnimatePresence>,
          target,
        )}

        {err && (
          <div className="pointer-events-auto absolute inset-0 z-10">
            <StreamProblem reason="This stream could not be loaded directly on this network.">
              {servers && servers.length > 0 && (
                <button className="zp-b pill" onClick={(e) => setPop('srv', e.currentTarget)}>
                  Switch Server ({servers.length})
                </button>
              )}
              {onStreamError && (
                <button
                  className="zp-b pill"
                  style={{ background: 'rgba(255,255,255,0.15)', color: '#fff', borderColor: 'rgba(255,255,255,0.3)' }}
                  onClick={() => {
                    setErr(false)
                    setBusy(true)
                    onStreamError()
                  }}
                >
                  Switch to Next Server
                </button>
              )}
              <button
                className="zp-b pill"
                style={{ background: '#fff', color: '#000' }}
                onClick={() => {
                  setErr(false)
                  setBusy(true)
                  setRetry((n) => n + 1)
                }}
              >
                Try again
              </button>
            </StreamProblem>
          </div>
        )}
      </div>
      </div>

      {sheet === 'subs' && (
        <Sheet title="Caption settings" onClose={() => setSheet(null)} target={target} dialog>
          <div className="zp-prev">
            <div className="flex min-h-[48px] items-center justify-center p-2 text-center">
              <span style={capCss(cs, '14px')}>I'm gonna be King of the Pirates!</span>
            </div>
            <div className="zp-tabs" role="tablist">
              {([['presets', 'Presets'], ['font', 'Font'], ['text', 'Text'], ['box', 'Box'], ['sync', 'Sync']] as const).map(([k, l]) => (
                <button key={k} role="tab" aria-selected={capTab === k} className={cx('zp-tab', capTab === k && 'on')} onClick={() => setCapTab(k)}>
                  {l}
                </button>
              ))}
            </div>
          </div>

          {capTab === 'presets' && (
            <div className="zp-tc">
              <button
                className="zp-row"
                onClick={() => {
                  setCaps((c) => {
                    const next = !c
                    if (next && (!trackId || !cues.length) && tracks.length > 0) {
                      const best = sortByBestSub(tracks)[0]
                      if (best) void pick(best, false, true)
                    }
                    return next
                  })
                }}
              >
                <span>Show subtitles</span>
                <i className={cx('zp-tg', caps && 'on')} />
              </button>
              <p className="zp-sec">Style presets</p>
              <div className="zp-pgrid">
                {CAP_PRESETS.map(([n, v]) => (
                  <button key={n} className="zp-pc" onClick={() => setCs({ ...CAP_DEFAULT, pos: cs.pos, ...v })}>
                    <div className="zp-pcv">
                      <span style={capCss({ ...CAP_DEFAULT, ...v }, '9px')}>Subtitle</span>
                    </div>
                    <small>{n}</small>
                  </button>
                ))}
              </div>
            </div>
          )}

          {capTab === 'font' && (
            <div className="zp-tc">
              <div className="zp-pg seg zp-cats">
                {FONT_CATS.map(([k, l]) => (
                  <button key={k} className={cx('zp-pi', capCat === k && 'on')} onClick={() => setCapCat(k)}>
                    {l}
                  </button>
                ))}
              </div>
              <div className="zp-flist">
                {SUB_FONT_LIST.filter(([, , , c]) => capCat === 'all' || c === capCat).map(([k, l, f]) => (
                  <button key={k} className={cx('zp-frow', cs.font === k && 'on')} onClick={() => setCs({ font: k })}>
                    <span>{l}</span>
                    <span style={{ fontFamily: f }}>The quick brown fox</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {capTab === 'text' && (
            <div className="zp-tc">
              <p className="zp-sec">Size</p>
              <div className="zp-pg seg">
                {(Object.keys(SUB_SIZE) as (keyof typeof SUB_SIZE)[]).map((k) => (
                  <button key={k} className={cx('zp-pi', cs.size === k && 'on')} onClick={() => setCs({ size: k })}>
                    {k[0].toUpperCase() + k.slice(1)}
                  </button>
                ))}
              </div>
              {slider('Size fine-tune', 'scale', 50, 200, 5)}

              <p className="zp-sec">Weight</p>
              <div className="zp-pg seg">
                {[[400, 'Light'], [500, 'Normal'], [700, 'Bold'], [900, 'Heavy']].map(([w, l]) => (
                  <button key={w} className={cx('zp-pi', cs.weight === w && 'on')} onClick={() => setCs({ weight: w as number })}>
                    {l}
                  </button>
                ))}
              </div>

              <p className="zp-sec">Style</p>
              <div className="zp-pg seg">
                <button className={cx('zp-pi', cs.italic && 'on')} onClick={() => setCs({ italic: !cs.italic })}>Italic</button>
                <button className={cx('zp-pi', cs.upper && 'on')} onClick={() => setCs({ upper: !cs.upper })}>UPPERCASE</button>
              </div>

              <p className="zp-sec">Letter spacing</p>
              <div className="zp-pg seg">
                {(['tight', 'normal', 'wide'] as const).map((id) => (
                  <button key={id} className={cx('zp-pi', cs.spacing === id && 'on')} onClick={() => setCs({ spacing: id })}>
                    {id[0].toUpperCase() + id.slice(1)}
                  </button>
                ))}
              </div>

              <p className="zp-sec">Color</p>
              <div className="zp-pg">{swatch(CAP_COLORS, 'color')}</div>
              {slider('Opacity', 'opacity', 20, 100, 5)}

              <p className="zp-sec">Edge</p>
              <div className="zp-pg seg">
                {EDGE_KEYS.map((k) => (
                  <button key={k} className={cx('zp-pi', cs.edge === k && 'on')} onClick={() => setCs({ edge: k })}>
                    {k[0].toUpperCase() + k.slice(1)}
                  </button>
                ))}
              </div>
              <div className="zp-pg">{swatch(EDGE_COLORS, 'edgeColor')}</div>
            </div>
          )}

          {capTab === 'box' && (
            <div className="zp-tc">
              <p className="zp-sec">Background</p>
              <div className="zp-pg seg">
                {(Object.keys(CAP_BOX) as (keyof typeof CAP_BOX)[]).map((k) => (
                  <button key={k} className={cx('zp-pi', cs.boxStyle === k && 'on')} onClick={() => setCs({ boxStyle: k })}>
                    {CAP_BOX[k]}
                  </button>
                ))}
              </div>
              {cs.boxStyle !== 'none' && (
                <>
                  {slider('Background opacity', 'bg', 0, 100, 5)}
                  <div className="zp-pg">{swatch(BG_COLORS, 'bgColor')}</div>
                  {slider('Background blur', 'blur', 0, 20, 1, 'px')}
                </>
              )}

              <p className="zp-sec">Alignment</p>
              <div className="zp-pg seg">
                {(['left', 'center', 'right'] as const).map((a) => (
                  <button key={a} className={cx('zp-pi', cs.align === a && 'on')} onClick={() => setCs({ align: a })}>
                    {a[0].toUpperCase() + a.slice(1)}
                  </button>
                ))}
              </div>
              {slider('Max width', 'width', 30, 100, 5)}
              {slider('Line height', 'lh', 100, 200, 5)}
              {slider('Height from bottom', 'pos', 0, 70, 5)}
            </div>
          )}

          {capTab === 'sync' && (
            <div className="zp-tc">
              <p className="zp-sec">Subtitle delay</p>
              <div className="zp-off">
                {[-0.5, -0.1].map((d) => (
                  <button key={d} className="zp-pi" onClick={() => adj(d)} aria-label={`Subtitles ${-d}s earlier`}>
                    {d}
                  </button>
                ))}
                <span>
                  {offset > 0 ? '+' : ''}
                  {offset.toFixed(1)}s
                </span>
                {[0.1, 0.5].map((d) => (
                  <button key={d} className="zp-pi" onClick={() => adj(d)} aria-label={`Subtitles ${d}s later`}>
                    +{d}
                  </button>
                ))}
                <button className="zp-pi" onClick={() => setOffset(0)} disabled={offset === 0}>
                  Reset
                </button>
              </div>
              <button className="zp-row" onClick={() => file.current?.click()}>
                <Upload />
                <span>Upload subtitle file</span>
              </button>
              <input ref={file} type="file" accept=".srt,.vtt,.txt" hidden onChange={uploadSub} />
            </div>
          )}
        </Sheet>
      )}

      {sheet === 'set' && (
        <Sheet title="Settings" onClose={() => setSheet(null)} target={target} dialog>
          <div className="zp-prev">
            <div className="zp-tabs" role="tablist">
              {([['video', 'Video'], ['picture', 'Picture'], ['play', 'Playback'], ...(canCast && castAvail ? [['cast', 'Cast']] : [])] as unknown as ReadonlyArray<readonly ['video' | 'picture' | 'play' | 'cast', string]>).map(([k, l]) => (
                <button key={k} role="tab" aria-selected={setTab === k} className={cx('zp-tab', setTab === k && 'on')} onClick={() => setSetTab(k)}>
                  {l}
                </button>
              ))}
            </div>
          </div>

          {setTab === 'video' && (
            <div className="zp-tc">
          {(isAudioLoading || audioTracks.length > 1 || (dubs && dubs.length > 0) || (!isTmdb && audioMode === 'sub')) && (
            <>
              <p className="zp-sec">Audio / Dub Language</p>
              {isAudioLoading ? (
                <div className="flex items-center gap-2 px-1 py-2 text-xs text-white/60">
                  <Loader2 className="size-3.5 animate-spin text-[var(--a,#dc143c)]" />
                  <span>Loading audio tracks…</span>
                </div>
              ) : !isTmdb && audioMode === 'sub' ? (
                <div className="zp-pg">
                  <button type="button" className="zp-pi on">
                    {origSubLabel}
                  </button>
                </div>
              ) : (
                <div className="zp-pg">
                  {audioTracks.length > 1 &&
                    audioTracks.map((t) => (
                      <button
                        key={`st-${t.i}`}
                        className={cx('zp-pi', t.i === audioIdx && 'on')}
                        onClick={() => {
                          if (isPartyGuest) {
                            toast('Audio is controlled by party host', 'info')
                            return
                          }
                          setAudioTrack(t)
                          setSheet(null)
                        }}
                      >
                        {t.label}
                      </button>
                    ))}
                  {audioTracks.length < 2 &&
                    dubs &&
                    dubs.map((d) => {
                      const cleanName =
                        (d.label || 'Audio')
                          .replace(/^(?:MovieBox|Vidzee|CineSrc|CinemaOS|Videasy|VidLink|VidFast|VidSrc|PrimeSrc)\s*(?:Direct|Pro)?\s*[·\-:]?\s*/i, '')
                          .replace(/\b(?:MovieBox|Vidzee|Direct)\b/gi, '')
                          .trim() || 'Original'
                      return (
                        <button
                          key={d.id}
                          className={cx('zp-pi', d.selected && 'on')}
                          onClick={() => {
                            if (d.selected) return
                            setSheet(null)
                            flash('load', `Switching to ${cleanName}…`)
                            onDub?.(d.id)
                          }}
                        >
                          {cleanName}
                        </button>
                      )
                    })}
                </div>
              )}
            </>
          )}
          <p className="zp-sec">Aspect ratio</p>
          <div className="zp-pg">
            {ASPECTS.map((a) => (
              <button key={a} className={cx('zp-pi', ar === a && 'on')} onClick={() => setAr(a)}>
                {a}
              </button>
            ))}
          </div>

              <p className="zp-sec">Zoom ({pf.zoom}%)</p>
              <input
                type="range" className="zp-rg" min={100} max={150} step={5} value={pf.zoom}
                style={{ '--p': `${(pf.zoom - 100) * 2}%` } as CSSProperties}
                onChange={(e) => setPf({ zoom: +e.target.value })}
                aria-label="Video zoom"
              />
              <button className="zp-row" onClick={() => setPf({ flip: !pf.flip })}>
                <span>Mirror video</span>
                <i className={cx('zp-tg', pf.flip && 'on')} />
              </button>
          <p className="zp-sec">4K upscaler (GPU)</p>
          <button className="zp-row" disabled={!gpuSupported} onClick={() => { setUpErr(null); setUp(!up); }}>
            <span>Anime4K WebGPU upscaling</span>
            <i className={cx('zp-tg', up && 'on')} />
          </button>
          {up && (
            <>
              <p className="zp-sec">Anime4K Model / Shader Preset</p>
              <div className="zp-pg">
                {ANIME4K_MODES.map((m) => (
                  <button
                    key={m.id}
                    className={cx('zp-pi', upMode === m.id && 'on')}
                    onClick={() => setUpMode(m.id)}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
              <p className="zp-note" style={{ marginTop: '4px' }}>
                {ANIME4K_MODES.find((m) => m.id === upMode)?.desc}
              </p>

              <p className="zp-sec">Upscale Intensity ({upInt}%)</p>
              <input
                type="range" className="zp-rg" min={0} max={100} step={5} value={upInt}
                style={{ '--p': `${upInt}%` } as CSSProperties}
                onChange={(e) => setUpInt(+e.target.value)}
                aria-label="Upscaler intensity"
              />
            </>
          )}
          <p className="zp-note">
            {!gpuSupported
              ? 'This browser has no WebGPU, so the upscaler is unavailable.'
              : upErr
                ? `Upscaler note: ${upErr}. Try selecting another preset or re-toggling.`
                : 'Runs in real-time on your GPU with WebGPU neural shaders. Best on 720p–1080p anime.'}
          </p>


            </div>
          )}

          {setTab === 'picture' && (
            <div className="zp-tc">
          <p className="zp-sec">Visual Enhancements &amp; Shaders</p>
          <div className="zp-pg">
            {[
              { id: 'off', label: 'Default' },
              { id: 'vibrant', label: 'Vibrance' },
              { id: 'cinema', label: 'Cinema HDR' },
              { id: 'sharp', label: 'Crisp Lines' },
              { id: 'warm', label: 'Warm (Eye Care)' },
            ].map(({ id, label }) => (
              <button
                key={id}
                className={cx('zp-pi', vfx.preset === id && 'on')}
                onClick={() => setVfx({ preset: id as VideoFilterPreset })}
              >
                {label}
              </button>
            ))}
          </div>

          <p className="zp-sec">Brightness ({vfx.brightness}%)</p>
          <input
            type="range" className="zp-rg" min={70} max={130} step={2} value={vfx.brightness}
            style={{ '--p': `${((vfx.brightness - 70) / (130 - 70)) * 100}%` } as CSSProperties}
            onChange={(e) => setVfx({ brightness: +e.target.value })}
            aria-label="Video brightness"
          />

          <p className="zp-sec">Contrast ({vfx.contrast}%)</p>
          <input
            type="range" className="zp-rg" min={70} max={140} step={2} value={vfx.contrast}
            style={{ '--p': `${((vfx.contrast - 70) / (140 - 70)) * 100}%` } as CSSProperties}
            onChange={(e) => setVfx({ contrast: +e.target.value })}
            aria-label="Video contrast"
          />

          <p className="zp-sec">Color Saturation ({vfx.saturation}%)</p>
          <input
            type="range" className="zp-rg" min={70} max={160} step={5} value={vfx.saturation}
            style={{ '--p': `${((vfx.saturation - 70) / (160 - 70)) * 100}%` } as CSSProperties}
            onChange={(e) => setVfx({ saturation: +e.target.value })}
            aria-label="Video saturation"
          />

          {(vfx.preset !== 'off' || vfx.brightness !== 100 || vfx.contrast !== 100 || vfx.saturation !== 100) && (
            <button
              className="zp-pi"
              style={{ marginTop: '8px' }}
              onClick={() => setVfx(VIDEO_FILTER_DEFAULTS)}
            >
              Reset visual shaders
            </button>
          )}


            </div>
          )}

          {setTab === 'cast' && (
            <div className="zp-tc">
              <div className={cx('zp-castcard', casting && 'on')}>
                <span className="zp-castic">
                  <Cast />
                </span>
                <div>
                  <b>{casting ? `Casting to ${cst.device || 'your device'}` : cst.status === 'connecting' ? 'Connecting…' : 'Not connected'}</b>
                  <small>{casting ? (cst.buffering || !cst.loaded ? 'Starting on the TV…' : cst.playing ? 'Playing on the TV' : 'Paused on the TV') : 'Send this episode to a TV or speaker'}</small>
                </div>
              </div>

              {!casting ? (
                <>
                  {(cst.status === 'ready' || cst.status === 'connecting') && (
                    <button className="zp-row" disabled={cst.status === 'connecting'} onClick={() => void castRequest()}>
                      <Cast />
                      <span>
                        Cast to a device
                        <small>Chromecast, Google TV, Android TV, Nest Hub</small>
                      </span>
                    </button>
                  )}
                  {airplay && (
                    <button className="zp-row" onClick={() => airplayPicker(vid.current)}>
                      <Airplay />
                      <span>
                        AirPlay
                        <small>Apple TV, HomePod and AirPlay TVs</small>
                      </span>
                    </button>
                  )}
                  {cst.status === 'unsupported' && !airplay && (
                    <p className="zp-ct">Casting isn&apos;t available in this browser. Use Chrome or Edge (Android or desktop) over https.</p>
                  )}
                  {cst.error && <p className="zp-ct err">{cst.error}</p>}
                  <p className="zp-sec">Good to know</p>
                  <p className="zp-ct">
                    Your phone and the TV must be on the same Wi-Fi. The TV plays the stream itself, so you can lock your phone or leave the page open.
                    Captions and playback speed stay on this device.
                  </p>
                </>
              ) : (
                <>
                  <p className="zp-sec">Remote</p>
                  <button className="zp-row" disabled={playDisabled} aria-disabled={playDisabled} onClick={togglePlay}>
                    {cst.playing ? <Pause /> : <Play />}
                    <span>{cst.playing ? 'Pause' : 'Play'}</span>
                    <small>
                      {fmt(cst.time)} / {fmt(cst.duration)}
                    </small>
                  </button>
                  <p className="zp-sec">Volume ({Math.round((cst.muted ? 0 : cst.volume) * 100)}%)</p>
                  <input
                    type="range" className="zp-rg" min={0} max={100} step={1} value={Math.round((cst.muted ? 0 : cst.volume) * 100)}
                    style={{ '--p': `${Math.round((cst.muted ? 0 : cst.volume) * 100)}%` } as CSSProperties}
                    onChange={(e) => castSetVolume(+e.target.value / 100)}
                    aria-label="TV volume"
                  />
                  <button className="zp-row" onClick={toggleMute}>
                    <span>Mute TV</span>
                    <i className={cx('zp-tg', cst.muted && 'on')} />
                  </button>
                  <button className="zp-row" onClick={() => (castStop(), setSheet(null))}>
                    <X />
                    <span>Stop casting</span>
                  </button>
                  {cst.error && <p className="zp-ct err">{cst.error}</p>}
                </>
              )}
            </div>
          )}

          {setTab === 'play' && (
            <div className="zp-tc">
          {onSkipFiller && (
            <>
              <p className="zp-sec">Automation</p>
              <button className="zp-row" onClick={() => onSkipFiller(!skipFiller)}>
                <span>Skip filler episodes</span>
                <i className={cx('zp-tg', skipFiller && 'on')} />
              </button>
            </>
          )}

          <p className="zp-sec">Skip step (buttons, double-tap, J / L)</p>
          <div className="zp-pg seg">
            {[[5, "5s"], [10, "10s"], [15, "15s"], [30, "30s"]].map(([v, l]) => (
              <button key={String(v)} className={cx('zp-pi', pf.seek === v && 'on')} onClick={() => setPf({ seek: v as any })}>
                {l}
              </button>
            ))}
          </div>

          <p className="zp-sec">Hold-to-speed rate</p>
          <div className="zp-pg seg">
            {[[1.5, "1.5×"], [2, "2×"], [3, "3×"], [4, "4×"]].map(([v, l]) => (
              <button key={String(v)} className={cx('zp-pi', pf.hold === v && 'on')} onClick={() => setPf({ hold: v as any })}>
                {l}
              </button>
            ))}
          </div>

          <p className="zp-sec">Auto-hide controls</p>
          <div className="zp-pg seg">
            {[[2000, "2s"], [3200, "3s"], [5000, "5s"], [0, "Never"]].map(([v, l]) => (
              <button key={String(v)} className={cx('zp-pi', pf.hide === v && 'on')} onClick={() => setPf({ hide: v as any })}>
                {l}
              </button>
            ))}
          </div>

              <button className="zp-pi" style={{ marginTop: '8px' }} onClick={() => setPf(PF_DEFAULT)}>
                Reset playback options
              </button>
            </div>
          )}
        </Sheet>
      )}

      {sheet === 'eps' && onSelectEpisode && (
        <Sheet title="Episodes" onClose={() => setSheet(null)} target={target} className="zp-sh-wide" bodyClassName="zp-sh-b-eps">
          <Episodes
            total={totalEpisodes}
            available={avail}
            current={episode}
            episodesInfo={episodesInfo}
            fallbackImg={fallbackImg}
            defaultRuntime={defaultRuntime}
            kinds={kinds}
            watchedEps={watchedEps}
            onPick={(n) => {
              if (isPartyGuest) {
                toast('Only the party host can change episodes', 'info')
                return
              }
              onSelectEpisode(n)
              setSheet(null)
            }}
          />
        </Sheet>
      )}

      {sheet === 'report' && (
        <Sheet title="Report Stream Issue" onClose={() => setSheet(null)} target={target}>
          {reportSuccess ? (
            <div style={{ textAlign: 'center', padding: '24px 12px' }}>
              <div style={{ display: 'grid', placeItems: 'center', width: '48px', height: '48px', margin: '0 auto 12px', borderRadius: '50%', background: 'rgba(16, 185, 129, 0.15)', color: '#34d399' }}>
                <CheckCircle2 style={{ width: '28px', height: '28px' }} />
              </div>
              <h4 style={{ fontSize: '16px', fontWeight: 'bold', marginBottom: '6px' }}>Report Submitted</h4>
              <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.7)', lineHeight: '1.5', maxWidth: '280px', margin: '0 auto 16px' }}>
                Thank you! Issue #{reportSuccess.slice(0, 8)} has been logged. Our curators have been alerted.
              </p>
              <button
                className="zp-b pill"
                style={{ margin: '0 auto', background: 'var(--accent)', color: 'white', padding: '8px 24px' }}
                onClick={() => setSheet(null)}
              >
                Done
              </button>
            </div>
          ) : (
            <form
              onSubmit={async (e) => {
                e.preventDefault()
                setReportSubmitting(true)
                try {
                  const sName = servers?.find((s) => s.id === serverId)?.name ?? serverId ?? 'Auto'
                  const res = await submitStreamReport({
                    anime_id: animeId ? String(animeId) : undefined,
                    anime_title: title || (isMovie ? 'Movie' : 'Anime Episode'),
                    episode: isMovie ? 'Movie' : String(episode || '1'),
                    server: sName,
                    audio_type: audioMode,
                    issue_type: reportIssue,
                    details: reportDetails.trim() || undefined,
                    playback_time: fmt(shown),
                  })
                  if (res.success && res.id) {
                    setReportSuccess(res.id)
                    toast('Report submitted successfully! Thank you.', 'info')
                  } else {
                    toast(res.error || 'Failed to submit report', 'error')
                  }
                } finally {
                  setReportSubmitting(false)
                }
              }}
              style={{ display: 'flex', flexDirection: 'column', gap: '12px', padding: '4px' }}
            >
              <div style={{ padding: '10px 12px', borderRadius: '8px', background: 'rgba(255,255,255,0.05)', fontSize: '11px', color: 'rgba(255,255,255,0.75)', lineHeight: '1.4' }}>
                <div><strong>{isMovie ? 'Title:' : 'Anime:'}</strong> {title}</div>
                <div>{!isMovie && <><strong>Episode:</strong> {episode} &bull; </>}<strong>Server:</strong> {servers?.find((s) => s.id === serverId)?.name ?? serverId ?? 'Auto'} &bull; <strong>Audio:</strong> {audioMode.toUpperCase()} &bull; <strong>Time:</strong> {fmt(shown)}</div>
              </div>

              <div>
                <p className="zp-sec" style={{ margin: '0 0 6px' }}>Select Issue Type</p>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '6px' }}>
                  {[
                    'Broken / Won\'t Play',
                    'Audio Desync',
                    'Wrong Episode',
                    'Missing Subtitles',
                    'Buffering / Lag',
                    'Other Problem',
                  ].map((iss) => (
                    <button
                      type="button"
                      key={iss}
                      className={cx('zp-pi', reportIssue === iss && 'on')}
                      style={{ fontSize: '11px', padding: '8px 6px', textAlign: 'center', height: 'auto' }}
                      onClick={() => setReportIssue(iss)}
                    >
                      {iss}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <p className="zp-sec" style={{ margin: '0 0 6px' }}>Additional Details (Optional)</p>
                <textarea
                  rows={3}
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  placeholder="e.g. Audio is 2 seconds ahead after the intro..."
                  style={{ width: '100%', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.15)', background: 'rgba(0,0,0,0.4)', color: 'white', padding: '8px', fontSize: '11px', outline: 'none', resize: 'vertical' }}
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '4px' }}>
                <button
                  type="button"
                  className="zp-b pill"
                  onClick={() => setSheet(null)}
                  style={{ padding: '6px 14px', fontSize: '12px' }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={reportSubmitting}
                  className="zp-b pill"
                  style={{ background: 'var(--accent)', color: 'white', padding: '6px 16px', fontSize: '12px', fontWeight: 'bold' }}
                >
                  {reportSubmitting ? 'Sending...' : 'Send Report'}
                </button>
              </div>
            </form>
          )}
        </Sheet>
      )}
    </div>
  )
}

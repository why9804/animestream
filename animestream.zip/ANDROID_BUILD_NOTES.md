# AnimeStream Android build notes

- The Android app ID is `com.animestream.app`.
- The frontend's native Capacitor runtime routes `/api/*` and `/proxy` to the existing Cloudflare Pages backend at `https://animestream-697.pages.dev` (overridable with `VITE_API_BASE`).
- Native API requests use the existing AnimeStream APK barrier header defined by `server/shield.js`; browser builds retain the normal Zenkai Shield challenge flow.
- HLS.js requests to the Pages backend receive the same APK headers so manifests and segments do not get blocked by the backend barrier.
- After `npx cap add android`, run `bash scripts/apply-android-branding.sh` to apply the supplied AnimeStream launcher icon.

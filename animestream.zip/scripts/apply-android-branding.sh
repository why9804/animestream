#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RES="$ROOT/android/app/src/main/res"
BRAND="$ROOT/android-branding/res"
if [[ ! -d "$ROOT/android/app/src/main" ]]; then
  echo "Android platform has not been generated yet; run npx cap add android first."
  exit 1
fi
mkdir -p "$RES"
cp -a "$BRAND/." "$RES/"
MANIFEST="$ROOT/android/app/src/main/AndroidManifest.xml"
if [[ -f "$MANIFEST" ]]; then
  python3 - "$MANIFEST" <<'PYXML'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text()
app = re.search(r'<application\b[^>]*>', s, flags=re.S)
if app:
    tag = app.group(0)
    tag = re.sub(r'android:icon="[^"]*"', 'android:icon="@mipmap/ic_launcher"', tag)
    tag = re.sub(r'android:roundIcon="[^"]*"', 'android:roundIcon="@mipmap/ic_launcher_round"', tag)
    if 'android:icon=' not in tag:
        tag = tag[:-1] + ' android:icon="@mipmap/ic_launcher">'
    if 'android:roundIcon=' not in tag:
        tag = tag[:-1] + ' android:roundIcon="@mipmap/ic_launcher_round">'
    s = s[:app.start()] + tag + s[app.end():]
    p.write_text(s)
PYXML
fi
echo "AnimeStream launcher branding applied."

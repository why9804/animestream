import test from 'node:test'
import assert from 'node:assert/strict'
import {
  clearConsumedSidsForTest,
  createStepChallenge,
  MIN_SOLVE_SECONDS,
  TOKEN_TTL_SECONDS,
  verifyStepCallback,
} from '../server/supportToken.js'

const SECRET = 'test-support-hmac-secret-2026-abcdef'

test('accepts a legitimate server-signed callback token after minimum wait time', async () => {
  clearConsumedSidsForTest()
  const issuedAt = 1_795_568_600
  const challenge = await createStepChallenge({
    userId: 'user-123',
    missionId: 'turbo',
    step: 1,
    origin: 'https://animestream-697.pages.dev',
    secret: SECRET,
    nowSec: issuedAt,
  })

  assert.match(challenge.sid, /^zks_[a-f0-9]{32}$/)
  assert.match(challenge.sig, /^[a-f0-9]{64}$/)

  const res = await verifyStepCallback({
    userId: 'user-123',
    missionId: 'turbo',
    step: 1,
    sid: challenge.sid,
    ts: challenge.ts,
    sig: challenge.sig,
    secret: SECRET,
    nowSec: issuedAt + MIN_SOLVE_SECONDS + 4,
    completedSteps: 0,
    pendingSessionId: challenge.sid,
    claimedTokens: [],
  })

  assert.equal(res.ok, true)
  assert.equal(res.newCompleted, 1)
  assert.equal(res.isMissionCompleted, false)
  assert.equal(res.xpEarned, 0)
})

test('blocks arbitrary forged URL tokens like zk_turbo_s3_..._x30htkuchbhi', async () => {
  clearConsumedSidsForTest()
  const res = await verifyStepCallback({
    userId: 'user-123',
    missionId: 'turbo',
    step: 3,
    sid: 'zk_turbo_s3_1795568616925_x30htkuchbhi',
    ts: 1_795_568_616,
    sig: '0'.repeat(64),
    secret: SECRET,
    nowSec: 1_795_568_650,
    completedSteps: 0,
    pendingSessionId: '',
    claimedTokens: [],
  })

  assert.equal(res.ok, false)
  assert.equal(res.status, 403)
  assert.equal(res.code, 'INVALID_TOKEN_FORMAT')
})

test('blocks tampered step or mission parameters on a real token', async () => {
  clearConsumedSidsForTest()
  const issuedAt = 1_795_568_600
  const challenge = await createStepChallenge({
    userId: 'user-123',
    missionId: 'turbo',
    step: 1,
    origin: 'https://animestream-697.pages.dev',
    secret: SECRET,
    nowSec: issuedAt,
  })

  const res = await verifyStepCallback({
    userId: 'user-123',
    missionId: 'turbo',
    step: 3,
    sid: challenge.sid,
    ts: challenge.ts,
    sig: challenge.sig,
    secret: SECRET,
    nowSec: issuedAt + 20,
    completedSteps: 0,
    pendingSessionId: challenge.sid,
    claimedTokens: [],
  })

  assert.equal(res.ok, false)
  assert.equal(res.code, 'INVALID_SIGNATURE')
})

test('blocks cross-user replay of a signed callback token', async () => {
  clearConsumedSidsForTest()
  const issuedAt = 1_795_568_600
  const challenge = await createStepChallenge({
    userId: 'user-alice',
    missionId: 'quick',
    step: 1,
    origin: 'https://animestream-697.pages.dev',
    secret: SECRET,
    nowSec: issuedAt,
  })

  const res = await verifyStepCallback({
    userId: 'user-bob',
    missionId: 'quick',
    step: 1,
    sid: challenge.sid,
    ts: challenge.ts,
    sig: challenge.sig,
    secret: SECRET,
    nowSec: issuedAt + 20,
    completedSteps: 0,
    pendingSessionId: challenge.sid,
    claimedTokens: [],
  })

  assert.equal(res.ok, false)
  assert.equal(res.code, 'INVALID_SIGNATURE')
})

test('blocks reusing an already claimed token both via replay cache and DB claimedTokens', async () => {
  clearConsumedSidsForTest()
  const issuedAt = 1_795_568_600
  const challenge = await createStepChallenge({
    userId: 'user-123',
    missionId: 'quick',
    step: 1,
    origin: 'https://animestream-697.pages.dev',
    secret: SECRET,
    nowSec: issuedAt,
  })

  const first = await verifyStepCallback({
    userId: 'user-123',
    missionId: 'quick',
    step: 1,
    sid: challenge.sid,
    ts: challenge.ts,
    sig: challenge.sig,
    secret: SECRET,
    nowSec: issuedAt + 15,
    completedSteps: 0,
    pendingSessionId: challenge.sid,
    claimedTokens: [],
  })
  assert.equal(first.ok, true)
  assert.equal(first.isMissionCompleted, true)
  assert.equal(first.xpEarned, 60)

  const second = await verifyStepCallback({
    userId: 'user-123',
    missionId: 'quick',
    step: 1,
    sid: challenge.sid,
    ts: challenge.ts,
    sig: challenge.sig,
    secret: SECRET,
    nowSec: issuedAt + 25,
    completedSteps: 0,
    pendingSessionId: challenge.sid,
    claimedTokens: [challenge.sid],
  })
  assert.equal(second.ok, false)
  assert.equal(second.status, 410)
  assert.equal(second.code, 'TOKEN_EXPIRED')

  const expiredStepSession = await verifyStepCallback({
    userId: 'user-123',
    missionId: 'quick',
    step: 1,
    sid: challenge.sid,
    ts: challenge.ts,
    sig: challenge.sig,
    secret: SECRET,
    nowSec: issuedAt + 25,
    completedSteps: 0,
    pendingSessionId: '',
    pendingStepSession: { expired: true, verifiedAt: (issuedAt + 15) * 1000 },
    claimedTokens: [],
    skipReplayCache: true,
  })
  assert.equal(expiredStepSession.ok, false)
  assert.equal(expiredStepSession.status, 410)
  assert.equal(expiredStepSession.code, 'TOKEN_EXPIRED')
})

test('blocks too-fast completion and expired tokens', async () => {
  clearConsumedSidsForTest()
  const issuedAt = 1_795_568_600
  const challenge = await createStepChallenge({
    userId: 'user-123',
    missionId: 'turbo',
    step: 1,
    origin: 'https://animestream-697.pages.dev',
    secret: SECRET,
    nowSec: issuedAt,
  })

  const tooFast = await verifyStepCallback({
    userId: 'user-123',
    missionId: 'turbo',
    step: 1,
    sid: challenge.sid,
    ts: challenge.ts,
    sig: challenge.sig,
    secret: SECRET,
    nowSec: issuedAt + 2,
    completedSteps: 0,
    pendingSessionId: challenge.sid,
    claimedTokens: [],
  })
  assert.equal(tooFast.ok, false)
  assert.equal(tooFast.code, 'TOO_FAST')

  const expired = await verifyStepCallback({
    userId: 'user-123',
    missionId: 'turbo',
    step: 1,
    sid: challenge.sid,
    ts: challenge.ts,
    sig: challenge.sig,
    secret: SECRET,
    nowSec: issuedAt + TOKEN_TTL_SECONDS + 10,
    completedSteps: 0,
    pendingSessionId: challenge.sid,
    claimedTokens: [],
  })
  assert.equal(expired.ok, false)
  assert.equal(expired.code, 'TOKEN_EXPIRED')
})

test('blocks out-of-order step completion and mismatched pending DB session', async () => {
  clearConsumedSidsForTest()
  const issuedAt = 1_795_568_600
  const challenge = await createStepChallenge({
    userId: 'user-123',
    missionId: 'turbo',
    step: 2,
    origin: 'https://animestream-697.pages.dev',
    secret: SECRET,
    nowSec: issuedAt,
  })

  const outOfOrder = await verifyStepCallback({
    userId: 'user-123',
    missionId: 'turbo',
    step: 2,
    sid: challenge.sid,
    ts: challenge.ts,
    sig: challenge.sig,
    secret: SECRET,
    nowSec: issuedAt + 15,
    completedSteps: 0,
    pendingSessionId: challenge.sid,
    claimedTokens: [],
  })
  assert.equal(outOfOrder.ok, false)
  assert.equal(outOfOrder.code, 'STEP_OUT_OF_ORDER')

  const sessionMismatch = await verifyStepCallback({
    userId: 'user-123',
    missionId: 'turbo',
    step: 2,
    sid: challenge.sid,
    ts: challenge.ts,
    sig: challenge.sig,
    secret: SECRET,
    nowSec: issuedAt + 15,
    completedSteps: 1,
    pendingSessionId: 'zks_00000000000000000000000000000000',
    claimedTokens: [],
  })
  assert.equal(sessionMismatch.ok, false)
  assert.equal(sessionMismatch.code, 'SESSION_MISMATCH')
})

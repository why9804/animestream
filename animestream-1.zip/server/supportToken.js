// Server-side cryptographic challenge & anti-bypass verification for AnimeStream Support Missions.
// Uses Web-standard crypto.subtle so it runs identically in Node.js (Vite dev) and Cloudflare Pages Functions.

export const SUPPORT_MISSIONS_META = {
  quick: { id: "quick", title: "Daily Server Fuel", steps: 1, xp: 60 },
  turbo: { id: "turbo", title: "Multi-Audio & Dub Supporter", steps: 3, xp: 220 },
  patron: { id: "patron", title: "Master Server Pillar", steps: 6, xp: 550 },
};

export const MIN_SOLVE_SECONDS = 8;
export const TOKEN_TTL_SECONDS = 3600; // 1 hour

const enc = new TextEncoder();
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");

function safeEq(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

async function hmacSha256(data, secret) {
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return hex(await crypto.subtle.sign("HMAC", key, enc.encode(data)));
}

let ephemeralSecret = null;
export function getSupportSecret(env) {
  const configured =
    env?.SUPPORT_SECRET ||
    env?.SHIELD_SECRET ||
    (typeof process !== "undefined" ? process.env?.SUPPORT_SECRET || process.env?.SHIELD_SECRET : "");
  if (configured && String(configured).trim().length >= 8) {
    return String(configured).trim();
  }
  if (!ephemeralSecret) {
    const bytes = new Uint8Array(32);
    crypto.getRandomValues(bytes);
    ephemeralSecret = hex(bytes);
  }
  return ephemeralSecret;
}

export function isValidSupportReturnOrigin(originUrl, requestUrl) {
  if (!originUrl) return false;
  try {
    const u = new URL(originUrl);
    if (u.protocol !== "https:" && u.protocol !== "http:") return false;
    const host = u.hostname.toLowerCase();
    if (requestUrl) {
      try {
        if (u.host.toLowerCase() === new URL(requestUrl).host.toLowerCase()) return true;
      } catch {}
    }
    return (
      host === "zenkai.cfd" ||
      host.endsWith(".zenkai.cfd") ||
      host === "animestream.pages.dev" ||
      host.endsWith(".pages.dev") ||
      host.endsWith(".run.app") ||
      host === "localhost" ||
      host === "127.0.0.1"
    );
  } catch {
    return false;
  }
}

// Per-isolate replay cache (supplements Postgres claimedTokens persistence)
const consumedSids = new Map();

export function markSidConsumed(sid, nowMs = Date.now()) {
  if (consumedSids.size > 8000) {
    for (const [k, exp] of consumedSids) {
      if (nowMs > exp) consumedSids.delete(k);
    }
  }
  consumedSids.set(sid, nowMs + TOKEN_TTL_SECONDS * 1000);
}

export function isSidConsumed(sid, nowMs = Date.now()) {
  const exp = consumedSids.get(sid);
  if (!exp) return false;
  if (nowMs > exp) {
    consumedSids.delete(sid);
    return false;
  }
  return true;
}

export function clearConsumedSidsForTest() {
  consumedSids.clear();
}

export async function createStepChallenge({ userId, missionId, step, origin, secret, nowSec = Math.floor(Date.now() / 1000) }) {
  const mission = SUPPORT_MISSIONS_META[missionId];
  if (!mission) throw new Error("Unsupported mission tier");
  const stepNum = Number(step);
  if (!Number.isInteger(stepNum) || stepNum < 1 || stepNum > mission.steps) {
    throw new Error("Invalid mission step number");
  }
  if (!userId || typeof userId !== "string") {
    throw new Error("Authenticated user required");
  }

  const rand = new Uint8Array(16);
  crypto.getRandomValues(rand);
  const sid = `zks_${hex(rand)}`;
  const payload = `support:v2:${userId}:${missionId}:${stepNum}:${sid}:${nowSec}`;
  const sig = await hmacSha256(payload, secret);

  const cleanOrigin = String(origin || "").replace(/\/+$/, "");
  const callbackUrl = `${cleanOrigin}/support?verified=true&mission=${encodeURIComponent(missionId)}&step=${stepNum}&sid=${sid}&ts=${nowSec}&sig=${sig}`;

  return { sid, ts: nowSec, sig, callbackUrl };
}

export async function verifyStepCallback({
  userId,
  missionId,
  step,
  sid,
  ts,
  sig,
  secret,
  nowSec = Math.floor(Date.now() / 1000),
  completedSteps,
  pendingSessionId,
  pendingStepSession,
  claimedTokens,
  skipReplayCache = false,
}) {
  if (!userId || typeof userId !== "string") {
    return { ok: false, status: 401, code: "AUTH_REQUIRED", error: "Please sign in to verify support steps." };
  }

  const mission = SUPPORT_MISSIONS_META[missionId];
  if (!mission) {
    return { ok: false, status: 400, code: "INVALID_MISSION", error: "Unknown support mission." };
  }

  const stepNum = Number(step);
  if (!Number.isInteger(stepNum) || stepNum < 1 || stepNum > mission.steps) {
    return { ok: false, status: 400, code: "INVALID_STEP", error: "Invalid mission step number." };
  }

  if (typeof sid !== "string" || !/^zks_[a-f0-9]{32}$/.test(sid)) {
    return {
      ok: false,
      status: 403,
      code: "INVALID_TOKEN_FORMAT",
      error: "Invalid or unverified session token. Manual URL bypasses are blocked.",
    };
  }

  const issuedAt = Number(ts);
  if (!Number.isInteger(issuedAt) || issuedAt <= 0 || issuedAt > nowSec + 30) {
    return {
      ok: false,
      status: 403,
      code: "INVALID_TIMESTAMP",
      error: "Invalid verification timestamp. Please generate a fresh link.",
    };
  }

  if (nowSec - issuedAt > TOKEN_TTL_SECONDS) {
    return {
      ok: false,
      status: 410,
      code: "TOKEN_EXPIRED",
      error: "This verification link has expired. Please generate a new step link.",
    };
  }

  if (typeof sig !== "string" || !/^[a-f0-9]{64}$/.test(sig)) {
    return {
      ok: false,
      status: 403,
      code: "MISSING_SIGNATURE",
      error: "Missing or invalid cryptographic signature. Please complete the official ShrinkMe link.",
    };
  }

  const payload = `support:v2:${userId}:${missionId}:${stepNum}:${sid}:${issuedAt}`;
  const expectedSig = await hmacSha256(payload, secret);
  if (!safeEq(sig, expectedSig)) {
    return {
      ok: false,
      status: 403,
      code: "INVALID_SIGNATURE",
      error: "Verification signature mismatch. Tampered or forged URLs cannot complete steps.",
    };
  }

  if (nowSec - issuedAt < MIN_SOLVE_SECONDS) {
    return {
      ok: false,
      status: 403,
      code: "TOO_FAST",
      error: `Verification completed too quickly (${nowSec - issuedAt}s). Please complete the full shortener countdown.`,
    };
  }

  if (
    pendingStepSession?.expired ||
    pendingStepSession?.verifiedAt ||
    (!skipReplayCache && isSidConsumed(sid, nowSec * 1000)) ||
    (Array.isArray(claimedTokens) && claimedTokens.includes(sid))
  ) {
    return {
      ok: false,
      status: 410,
      code: "TOKEN_EXPIRED",
      error: "This verification token has expired because it was already used to complete a step.",
    };
  }

  if (typeof completedSteps === "number") {
    const expectedStep = completedSteps + 1;
    if (stepNum !== expectedStep) {
      return {
        ok: false,
        status: 409,
        code: "STEP_OUT_OF_ORDER",
        error: `Steps must be solved in order. Expected Step ${expectedStep}, received Step ${stepNum}.`,
      };
    }
  }

  if (pendingSessionId !== undefined && pendingSessionId !== sid) {
    return {
      ok: false,
      status: 403,
      code: "SESSION_MISMATCH",
      error: "No matching active step session found. Please start this step from the Support page first.",
    };
  }

  if (!skipReplayCache) {
    markSidConsumed(sid, nowSec * 1000);
  }

  const newCompleted = typeof completedSteps === "number" ? Math.min(completedSteps + 1, mission.steps) : stepNum;
  const isMissionCompleted = newCompleted >= mission.steps;
  const xpEarned = isMissionCompleted ? mission.xp : 0;

  return {
    ok: true,
    status: 200,
    sid,
    missionId,
    step: stepNum,
    newCompleted,
    isMissionCompleted,
    xpEarned,
  };
}

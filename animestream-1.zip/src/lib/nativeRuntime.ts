/** Runtime bridge for the installed Capacitor app. Web builds keep same-origin API routing. */
const DEFAULT_API_ORIGIN = 'https://animestream-697.pages.dev'
const APK_BARRIER_TOKEN = ((import.meta.env.VITE_ZENKAI_BARRIER as string | undefined) || 'zenkai-barrier-apk-2026-v1').trim()

type CapacitorWindow = Window & {
  Capacitor?: {
    isNativePlatform?: () => boolean
    getPlatform?: () => string
  }
}

const w = typeof window !== 'undefined' ? (window as CapacitorWindow) : null
export const IS_NATIVE_APP = Boolean(
  w?.Capacitor?.isNativePlatform?.() ||
  (w?.Capacitor?.getPlatform && w.Capacitor.getPlatform() !== 'web') ||
  (typeof location !== 'undefined' && (location.protocol === 'capacitor:' || location.protocol === 'ionic:')),
)

const configuredApiOrigin = ((import.meta.env.VITE_API_BASE as string | undefined) || '').trim()
export const API_ORIGIN = (configuredApiOrigin || (IS_NATIVE_APP ? DEFAULT_API_ORIGIN : '')).replace(/\/+$/, '')
const API_PATH = (path: string) => path.startsWith('/api/') || path === '/api' || path === '/proxy' || path.startsWith('/proxy?')

function backendOrigin(): string | null {
  if (!API_ORIGIN) return null
  try {
    return new URL(API_ORIGIN).origin
  } catch {
    return null
  }
}

const API_HOST = backendOrigin()

export function getApiBase(): string {
  return API_ORIGIN
}

/** Server responses use root-relative /proxy URLs on the website; make them absolute in the APK. */
export function resolveNativeApiPath(value?: string | null): string {
  if (!value || !IS_NATIVE_APP || !API_ORIGIN) return value || ''
  if (!value.startsWith('/api/') && value !== '/api' && !value.startsWith('/proxy')) return value
  try {
    return new URL(value, API_ORIGIN).href
  } catch {
    return value
  }
}

export function isNativeBackendUrl(input: string | URL): boolean {
  if (!IS_NATIVE_APP || !API_HOST) return false
  try {
    const url = new URL(String(input), typeof location !== 'undefined' ? location.href : API_ORIGIN)
    return url.origin === API_HOST && (url.pathname.startsWith('/api/') || url.pathname === '/api' || url.pathname === '/proxy')
  } catch {
    return false
  }
}

function addApkHeaders(source?: HeadersInit): Headers {
  const headers = new Headers(source)
  headers.set('X-Zenkai-Barrier', APK_BARRIER_TOKEN)
  headers.set('X-Zenkai-Client', 'Zenkai-Android-AnimeStream')
  headers.set('X-Zenkai-Embed', '1')
  return headers
}

/** HLS.js uses XHR for manifests/segments, so it needs the APK header separately from window.fetch. */
export function nativeHlsRequestConfig(): Record<string, unknown> {
  if (!IS_NATIVE_APP || !API_HOST) return {}
  return {
    xhrSetup: (xhr: XMLHttpRequest, url: string) => {
      if (!isNativeBackendUrl(url)) return
      const headers = addApkHeaders()
      headers.forEach((value, key) => xhr.setRequestHeader(key, value))
    },
    fetchSetup: (context: { url: string }, init: RequestInit = {}) => {
      const url = context?.url || ''
      const requestHeaders = addApkHeaders(init.headers)
      return new Request(url, { ...init, headers: isNativeBackendUrl(url) ? requestHeaders : init.headers })
    },
  }
}

/**
 * Rewrite root-relative /api and /proxy calls inside Capacitor's localhost WebView to the
 * actual Cloudflare Pages backend. This also covers fetches not using apiUrl().
 */
function installNativeFetchBridge(): void {
  if (!IS_NATIVE_APP || !API_HOST || typeof window === 'undefined') return

  const originalFetch = window.fetch.bind(window)
  window.fetch = ((input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    let requestUrl: URL
    try {
      const raw = input instanceof Request ? input.url : String(input)
      requestUrl = new URL(raw, window.location.href)
    } catch {
      return originalFetch(input, init)
    }

    const isLocalApi = requestUrl.origin === window.location.origin && API_PATH(requestUrl.pathname + requestUrl.search)
    if (isLocalApi) requestUrl = new URL(`${requestUrl.pathname}${requestUrl.search}`, API_ORIGIN)

    if (requestUrl.origin !== API_HOST || !API_PATH(requestUrl.pathname + requestUrl.search)) {
      return originalFetch(input, init)
    }

    const inheritedHeaders = input instanceof Request ? input.headers : undefined
    const headers = new Headers(inheritedHeaders)
    if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value))
    const finalHeaders = addApkHeaders(headers)
    const finalInput: RequestInfo | URL = input instanceof Request
      ? new Request(requestUrl.href, input)
      : requestUrl.href

    return originalFetch(finalInput, { ...init, headers: finalHeaders })
  }) as typeof window.fetch
}

installNativeFetchBridge()

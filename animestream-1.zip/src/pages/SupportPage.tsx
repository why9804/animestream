import { useState, useEffect, useMemo, useCallback, useRef } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowRight,
  Award,
  Check,
  CheckCircle2,
  ChevronRight,
  Clapperboard,
  Copy,
  ExternalLink,
  Flame,
  Heart,
  Loader2,
  Lock,
  RefreshCw,
  Rocket,
  RotateCcw,
  Share2,
  ShieldAlert,
  ShieldCheck,
  Trophy,
  X,
  Zap,
} from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { PageLoader } from '../components/PageLoader'
import { LoadingGrid } from '../components/LoadingGrid'
import { apiUrl } from '../services/api'
import {
  EMPTY_SUPPORTER_DATA,
  applyServerSupporterSnapshot,
  loadSupporterDataFromDb,
  type SupporterData,
  type SupporterDbActiveMission,
  type SupporterDbStats,
} from '../lib/supportDb'
import { toast } from '../lib/toast'
import { cn } from '../lib/utils'
import { shareLink } from '../lib/share'

const SUPPORT_BG_URL = '/assets/aistudio/file_000000003f2082118005774b6a3fa65c_b1817e2d.png'

export interface SupportMission {
  id: string
  title: string
  badge: string
  steps: number
  xp: number
  popular?: boolean
  accent: string
  desc: string
  impact: string
}

export const SUPPORT_MISSIONS: SupportMission[] = [
  {
    id: 'quick',
    title: 'Daily Server Fuel',
    badge: '1 Step',
    steps: 1,
    xp: 60,
    accent: '#e8294c',
    desc: 'Quick single sponsor link. Helps cover daily server bandwidth and keeps playback smooth.',
    impact: 'Daily bandwidth & fast episode loading',
  },
  {
    id: 'turbo',
    title: 'Multi-Audio & Dub Supporter',
    badge: '3 Steps',
    steps: 3,
    xp: 220,
    popular: true,
    accent: '#f59e0b',
    desc: 'Complete 3 sequential steps to directly support high-speed Hindi & English dub mirrors.',
    impact: 'Uncapped multi-audio streams & dub mirror uptime',
  },
  {
    id: 'patron',
    title: 'Master Server Pillar',
    badge: '6 Steps',
    steps: 6,
    xp: 550,
    accent: '#06b6d4',
    desc: '6-step community mission. Sustains main video servers, backup mirrors, and domain renewals.',
    impact: 'Primary video mirrors, backup capacity & domain uptime',
  },
]

const MOTIVATION_PILLARS = [
  {
    icon: Clapperboard,
    title: 'Faster Dub & Sub Drops',
    desc: 'Your support motivates our team to bring Hindi, English, and multi-audio tracks online even faster.',
  },
  {
    icon: Zap,
    title: 'Buffer-Free HD & 4K Mirrors',
    desc: 'Helps keep high-bitrate streams smooth and responsive even during peak weekly episode premieres.',
  },
  {
    icon: Heart,
    title: '100% Free Forever, Zero Paywalls',
    desc: 'Keeps every anime, movie, manga, and novel unlocked for everyone with no paid tiers or locked episodes.',
  },
  {
    icon: Rocket,
    title: 'Continuous Upgrades & Polish',
    desc: 'Fuels new features, watch parties, cleaner player controls, and better performance across all devices.',
  },
]

const SUPPORTER_TIERS = [
  { title: 'Bronze Booster', minSteps: 1, label: '1 Step', color: 'text-orange-600 dark:text-orange-400' },
  { title: 'Silver Supporter', minSteps: 2, label: '2 Steps', color: 'text-slate-600 dark:text-slate-300' },
  { title: 'Gold Sponsor', minSteps: 6, label: '6 Steps', color: 'text-amber-600 dark:text-amber-400' },
  { title: 'Diamond Patron', minSteps: 12, label: '12 Steps', color: 'text-sky-600 dark:text-sky-400' },
  { title: 'Sovereign Pillar', minSteps: 24, label: '24 Steps', color: 'text-cyan-600 dark:text-cyan-400' },
]

export default function SupportPage() {
  const { user, session, loading: authLoading } = useAuth()
  const [searchParams, setSearchParams] = useSearchParams()

  // Hydration state
  const [dbLoaded, setDbLoaded] = useState(false)
  const [syncingProgress, setSyncingProgress] = useState(false)
  const [supporterData, setSupporterData] = useState<SupporterData>(EMPTY_SUPPORTER_DATA)

  // UI selection & active step link state
  const [selectedMissionId, setSelectedMissionId] = useState<string>(SUPPORT_MISSIONS[0].id)
  const [generatingStep, setGeneratingStep] = useState(false)
  const [currentStepUrl, setCurrentStepUrl] = useState<string | null>(null)
  const [copiedLink, setCopiedLink] = useState(false)

  // Verification feedback states
  const [verifyingCallback, setVerifyingCallback] = useState(false)
  const [verificationError, setVerificationError] = useState<string | null>(null)
  const [justCompletedStep, setJustCompletedStep] = useState<number | null>(null)
  const [fullMissionCelebration, setFullMissionCelebration] = useState<{
    mission: SupportMission
    xpGained: number
  } | null>(null)

  const processingReturnRef = useRef<string | null>(null)

  const stats: SupporterDbStats = supporterData.stats
  const activeProgress: SupporterDbActiveMission | null = supporterData.activeMission

  const activeMission = useMemo(() => {
    return SUPPORT_MISSIONS.find((m) => m.id === selectedMissionId) || SUPPORT_MISSIONS[0]
  }, [selectedMissionId])

  const isInProgress = useMemo(() => {
    return activeProgress !== null && activeProgress.missionId === selectedMissionId
  }, [activeProgress, selectedMissionId])

  const effectiveCurrentStep = useMemo(() => {
    if (isInProgress && activeProgress) {
      return Math.min(activeProgress.completedSteps + 1, activeProgress.totalSteps)
    }
    return 1
  }, [isInProgress, activeProgress])

  const effectiveCompletedSteps = useMemo(() => {
    if (isInProgress && activeProgress) {
      return activeProgress.completedSteps
    }
    return 0
  }, [isInProgress, activeProgress])

  const progressPercent = useMemo(() => {
    if (!isInProgress || !activeProgress) return 0
    return Math.round((activeProgress.completedSteps / activeProgress.totalSteps) * 100)
  }, [isInProgress, activeProgress])

  const rank = useMemo(() => {
    const c = stats.totalLinksSolved
    if (c >= 24) return { title: 'Sovereign Pillar', color: 'text-cyan-600 dark:text-cyan-400' }
    if (c >= 12) return { title: 'Diamond Patron', color: 'text-sky-600 dark:text-sky-400' }
    if (c >= 6) return { title: 'Gold Sponsor', color: 'text-amber-600 dark:text-amber-400' }
    if (c >= 2) return { title: 'Silver Supporter', color: 'text-slate-600 dark:text-slate-300' }
    if (c >= 1) return { title: 'Bronze Booster', color: 'text-orange-600 dark:text-orange-400' }
    return { title: 'Otaku Member', color: 'text-muted' }
  }, [stats.totalLinksSolved])

  const unlockedTiersCount = useMemo(
    () => SUPPORTER_TIERS.filter((t) => stats.totalLinksSolved >= t.minSteps).length,
    [stats.totalLinksSolved],
  )

  const refreshProgress = useCallback(async () => {
    if (!user?.id) return
    const { data } = await loadSupporterDataFromDb(user.id)
    setSupporterData(data)
    if (data.activeMission?.missionId) {
      setSelectedMissionId(data.activeMission.missionId)
      const activeStep = data.activeMission.stepSessions?.[data.activeMission.currentStep]
      const savedStepUrl = activeStep && !activeStep.expired && !activeStep.verifiedAt ? activeStep.url || null : null
      setCurrentStepUrl(savedStepUrl)
    } else {
      setCurrentStepUrl(null)
    }
  }, [user?.id])

  // Hydrate supporter progress once auth resolves
  useEffect(() => {
    if (authLoading) return
    let alive = true
    setDbLoaded(false)

    loadSupporterDataFromDb(user?.id)
      .then(({ data }) => {
        if (!alive) return
        setSupporterData(data)
        if (data.activeMission?.missionId) {
          setSelectedMissionId(data.activeMission.missionId)
          const activeStep = data.activeMission.stepSessions?.[data.activeMission.currentStep]
          const savedStepUrl =
            activeStep && !activeStep.expired && !activeStep.verifiedAt ? activeStep.url || null : null
          setCurrentStepUrl(savedStepUrl)
        }
      })
      .finally(() => {
        if (alive) setDbLoaded(true)
      })

    const handleSync = () => {
      if (!user?.id) return
      void loadSupporterDataFromDb(user.id).then(({ data }) => {
        if (alive) setSupporterData(data)
      })
    }
    window.addEventListener('zk_mission_sync', handleSync)

    return () => {
      alive = false
      window.removeEventListener('zk_mission_sync', handleSync)
    }
  }, [authLoading, user?.id])

  // Cryptographic server-side verification for returning ShrinkMe callbacks
  useEffect(() => {
    if (authLoading || !dbLoaded) return

    const hasVerifiedParam = searchParams.get('verified') === 'true'
    const hasCallbackTokens = Boolean(searchParams.get('sid') || searchParams.get('sig') || searchParams.get('session'))
    if (!hasVerifiedParam && !hasCallbackTokens) return

    const missionParam = (searchParams.get('mission') || searchParams.get('tier') || '').trim()
    const stepParam = parseInt(searchParams.get('step') || '0', 10) || 0
    const sidParam = (searchParams.get('sid') || '').trim()
    const tsParam = parseInt(searchParams.get('ts') || '0', 10) || 0
    const sigParam = (searchParams.get('sig') || '').trim()
    const legacySession = (searchParams.get('session') || searchParams.get('t') || '').trim()

    const dedupeKey = `${missionParam}:${stepParam}:${sidParam || legacySession}:${tsParam}:${sigParam}`

    const cleanUrlParams = () => {
      const cleanParams = new URLSearchParams(searchParams)
      cleanParams.delete('verified')
      cleanParams.delete('mission')
      cleanParams.delete('tier')
      cleanParams.delete('step')
      cleanParams.delete('sid')
      cleanParams.delete('session')
      cleanParams.delete('t')
      cleanParams.delete('ts')
      cleanParams.delete('sig')
      setSearchParams(cleanParams, { replace: true })
    }

    if (processingReturnRef.current === dedupeKey) return
    processingReturnRef.current = dedupeKey

    cleanUrlParams()

    if (!session?.access_token || !user?.id) {
      const msg = 'You must be signed in to verify a support mission step.'
      setVerificationError(msg)
      toast(msg, 'error')
      return
    }

    if (!sidParam || !tsParam || !sigParam) {
      const msg =
        'Verification rejected: Missing official verification signature. Direct or edited URLs cannot complete steps—please generate and solve an official ShrinkMe link.'
      setVerificationError(msg)
      toast(msg, 'error')
      return
    }

    let alive = true
    setVerifyingCallback(true)
    setVerificationError(null)
    setSyncingProgress(true)

    fetch(apiUrl('/api/support/step/verify'), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({
        missionId: missionParam,
        step: stepParam,
        sid: sidParam,
        ts: tsParam,
        sig: sigParam,
      }),
      signal: AbortSignal.timeout(12000),
    })
      .then(async (res) => {
        const data = await res.json().catch(() => null)
        if (!alive) return

        if (!res.ok || !data?.ok || !data?.verified) {
          const errMsg =
            data?.error ||
            'Verification rejected: Invalid, expired, or already claimed verification token.'
          setVerificationError(errMsg)
          toast(errMsg, 'error')
          await refreshProgress()
          return
        }

        const nextData = applyServerSupporterSnapshot(user.id, data.supporterData)
        setSupporterData(nextData)
        setCurrentStepUrl(null)
        setVerificationError(null)

        const missionObj = SUPPORT_MISSIONS.find((m) => m.id === data.missionId) || activeMission
        setSelectedMissionId(missionObj.id)

        try {
          window.dispatchEvent(new CustomEvent('zk_mission_sync'))
        } catch {}

        if (data.missionCompleted) {
          setJustCompletedStep(null)
          setFullMissionCelebration({ mission: missionObj, xpGained: data.xpGained || missionObj.xp })
          toast(`Mission Completed: ${missionObj.title}! (+${data.xpGained || missionObj.xp} XP earned)`, 'success')
        } else {
          setJustCompletedStep(data.completedStep)
          toast(
            `Step ${data.completedStep}/${missionObj.steps} verified! Step ${data.completedStep + 1} is now ready.`,
            'success',
          )
        }
      })
      .catch(() => {
        if (!alive) return
        const msg = 'Could not verify token right now. Please check your connection and retry.'
        setVerificationError(msg)
        toast(msg, 'error')
      })
      .finally(() => {
        if (alive) {
          setVerifyingCallback(false)
          setSyncingProgress(false)
        }
      })

    return () => {
      alive = false
    }
  }, [
    authLoading,
    dbLoaded,
    searchParams,
    setSearchParams,
    session?.access_token,
    user?.id,
    activeMission,
    refreshProgress,
  ])

  const handleGenerateStepLink = async () => {
    if (generatingStep) return
    if (!session?.access_token || !user?.id) {
      toast('Please sign in to start a support mission.', 'error')
      return
    }

    setGeneratingStep(true)
    setVerificationError(null)

    const origin =
      typeof window !== 'undefined' &&
      !window.location.hostname.includes('localhost') &&
      !window.location.hostname.includes('127.0.0.1')
        ? window.location.origin
        : import.meta.env.VITE_SITE_URL || window.location.origin

    try {
      const resp = await fetch(apiUrl('/api/support/step/init'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          missionId: activeMission.id,
          step: effectiveCurrentStep,
          returnOrigin: origin,
        }),
        signal: AbortSignal.timeout(12000),
      })

      const data = await resp.json().catch(() => null)
      if (!resp.ok || !data?.ok || !data?.shortenedUrl) {
        toast(data?.error || 'Could not generate shortener link right now. Please try again.', 'error')
        if (data?.code === 'STEP_OUT_OF_ORDER') {
          await refreshProgress()
        }
        return
      }

      if (data.supporterData) {
        const nextData = applyServerSupporterSnapshot(user.id, data.supporterData)
        setSupporterData(nextData)
      }
      setCurrentStepUrl(data.shortenedUrl)
      toast(`Step ${effectiveCurrentStep} link ready. Solve it on ShrinkMe to continue.`, 'info')
    } catch {
      toast('Network error creating step link. Please check your connection and retry.', 'error')
    } finally {
      setGeneratingStep(false)
    }
  }

  const handleCopyStepLink = async () => {
    if (!currentStepUrl) return
    try {
      await navigator.clipboard.writeText(currentStepUrl)
      setCopiedLink(true)
      toast('Step link copied to clipboard.', 'success')
      setTimeout(() => setCopiedLink(false), 2000)
    } catch {
      toast('Failed to copy. Please open the link directly.', 'error')
    }
  }

  const handleResetProgress = async () => {
    if (!session?.access_token || !user?.id) return
    setSyncingProgress(true)
    try {
      const resp = await fetch(apiUrl('/api/support/reset'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({}),
        signal: AbortSignal.timeout(8000),
      })
      const data = await resp.json().catch(() => null)
      if (resp.ok && data?.supporterData) {
        setSupporterData(applyServerSupporterSnapshot(user.id, data.supporterData))
      } else {
        setSupporterData((prev) => ({ ...prev, activeMission: null }))
      }
      setCurrentStepUrl(null)
      setJustCompletedStep(null)
      setVerificationError(null)
      toast('Active mission progress cleared.', 'info')
    } catch {
      toast('Could not reset mission progress right now.', 'error')
    } finally {
      setSyncingProgress(false)
    }
  }

  const isHydrating = (authLoading || !dbLoaded) && !verifyingCallback

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {/* Page Background Artwork + Measured Contrast Scrim */}
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden bg-background">
        <img
          src={SUPPORT_BG_URL}
          alt=""
          onError={(e) => {
            e.currentTarget.style.display = 'none'
          }}
          className="h-full w-full object-cover object-center opacity-85 dark:opacity-95"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/55 via-background/45 to-background/75 dark:from-black/15 dark:via-black/25 dark:to-black/55" />
      </div>

      <main className="relative z-10 mx-auto w-full max-w-6xl px-4 pb-24 pt-6 sm:px-6 lg:px-8 lg:pt-10">
        {isHydrating ? (
          <PageLoader />
        ) : (
          <>
            {/* Top Breadcrumb + Hero Header */}
            <header className="space-y-6">
              <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-xs text-muted">
                <Link to="/home" className="transition-colors hover:text-foreground">
                  Home
                </Link>
                <ChevronRight className="size-3.5 opacity-60" />
                <span className="font-medium text-foreground">Support AnimeStream</span>
              </nav>

              <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
                <div className="max-w-2xl space-y-2.5">
                  <div className="flex items-center gap-2.5 text-xs font-semibold uppercase tracking-[0.18em] text-accent">
                    <Heart className="size-3.5 fill-current" />
                    <span>Support &amp; Motivate Us</span>
                  </div>
                  <h1 className="font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-[2.75rem]">
                    Keep AnimeStream Free &amp; Fast
                  </h1>
                  <p className="text-sm leading-relaxed text-muted sm:text-base">
                    Every mission you complete motivates us to push faster updates, maintain high-speed dub mirrors, and keep everything 100% free with zero paywalls.
                  </p>
                </div>

                <div className="flex items-center gap-2 text-xs text-muted">
                  <ShieldCheck className="size-4 text-emerald-600 dark:text-emerald-400" />
                  <span>Verified steps</span>
                  <span aria-hidden>·</span>
                  <span>Saved to your profile</span>
                </div>
              </div>

              {/* 4-Column Supporter Telemetry Strip */}
              <section
                aria-label="Supporter Statistics"
                className="grid grid-cols-2 divide-y divide-border overflow-hidden rounded-2xl border border-border bg-card/80 backdrop-blur-md sm:grid-cols-4 sm:divide-x sm:divide-y-0"
              >
                <div className="px-4 py-3.5 sm:px-5 sm:py-4">
                  <div className="flex items-center gap-1.5 text-xs text-muted">
                    <Trophy className="size-3.5" />
                    <span>Supporter Rank</span>
                  </div>
                  <p className={cn('mt-1 font-display text-base font-bold tracking-tight sm:text-lg', rank.color)}>
                    {rank.title}
                  </p>
                </div>

                <div className="px-4 py-3.5 sm:px-5 sm:py-4">
                  <div className="flex items-center gap-1.5 text-xs text-muted">
                    <CheckCircle2 className="size-3.5" />
                    <span>Steps Solved</span>
                  </div>
                  <p className="mt-1 font-mono text-base font-bold tabular-nums text-foreground sm:text-lg">
                    {stats.totalLinksSolved}
                  </p>
                </div>

                <div className="px-4 py-3.5 sm:px-5 sm:py-4">
                  <div className="flex items-center gap-1.5 text-xs text-muted">
                    <Flame className="size-3.5 text-accent" />
                    <span>Supporter XP</span>
                  </div>
                  <p className="mt-1 font-mono text-base font-bold tabular-nums text-foreground sm:text-lg">
                    {stats.totalXp} XP
                  </p>
                </div>

                <div className="px-4 py-3.5 sm:px-5 sm:py-4">
                  <div className="flex items-center gap-1.5 text-xs text-muted">
                    <Award className="size-3.5" />
                    <span>Missions Completed</span>
                  </div>
                  <p className="mt-1 font-mono text-base font-bold tabular-nums text-foreground sm:text-lg">
                    {syncingProgress ? 'Updating…' : stats.completedCount}
                  </p>
                </div>
              </section>
            </header>

            {/* Verification Status / Rejection / Success Banners */}
            <AnimatePresence mode="wait">
              {verifyingCallback && (
                <motion.div
                  key="verifying"
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border bg-card/80 p-4 text-sm backdrop-blur-md"
                >
                  <div>
                    <p className="font-semibold text-foreground">Verifying shortener completion…</p>
                    <p className="text-xs text-muted">Checking your official session token and step progress.</p>
                  </div>
                  <LoadingGrid label="Verifying" className="text-accent" />
                </motion.div>
              )}

              {!verifyingCallback && verificationError && (
                <motion.div
                  key="rejected"
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  role="alert"
                  className="mt-6 flex items-start justify-between gap-4 rounded-2xl border border-rose-500/35 bg-rose-500/10 p-4 backdrop-blur-md sm:p-5"
                >
                  <div className="flex items-start gap-3">
                    <ShieldAlert className="mt-0.5 size-5 shrink-0 text-rose-600 dark:text-rose-400" />
                    <div>
                      <h2 className="font-display text-sm font-bold text-rose-700 dark:text-rose-300 sm:text-base">
                        Step Verification Rejected
                      </h2>
                      <p className="mt-1 text-xs leading-relaxed text-rose-700/90 dark:text-rose-200/85 sm:text-sm">
                        {verificationError}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setVerificationError(null)}
                    aria-label="Dismiss error"
                    className="shrink-0 rounded-lg p-1.5 text-rose-700 transition hover:bg-rose-500/15 dark:text-rose-300"
                  >
                    <X className="size-4" />
                  </button>
                </motion.div>
              )}

              {!verifyingCallback && justCompletedStep !== null && !fullMissionCelebration && (
                <motion.div
                  key="step-ok"
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-emerald-500/35 bg-emerald-500/10 p-4 backdrop-blur-md sm:p-5"
                >
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-emerald-600 dark:text-emerald-400" />
                    <div>
                      <h2 className="font-display text-sm font-bold text-emerald-800 dark:text-emerald-300 sm:text-base">
                        Step {justCompletedStep} Verified &amp; Saved
                      </h2>
                      <p className="mt-0.5 text-xs text-emerald-800/85 dark:text-emerald-200/80 sm:text-sm">
                        Your progress is updated. Continue with Step {effectiveCurrentStep} of {activeMission.steps} below.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setJustCompletedStep(null)}
                    className="shrink-0 whitespace-nowrap rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white transition hover:bg-emerald-700"
                  >
                    Continue to Step {effectiveCurrentStep}
                  </button>
                </motion.div>
              )}

              {!verifyingCallback && fullMissionCelebration && (
                <motion.div
                  key="mission-done"
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className="mt-6 rounded-2xl border border-accent/40 bg-card/90 p-5 backdrop-blur-md sm:p-6"
                >
                  <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-center">
                    <div className="flex items-start gap-4">
                      <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-accent text-accent-fg">
                        <Trophy className="size-5" />
                      </span>
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wider text-accent">
                          Mission Accomplished · +{fullMissionCelebration.xpGained} XP
                        </p>
                        <h2 className="mt-0.5 font-display text-xl font-bold text-foreground sm:text-2xl">
                          {fullMissionCelebration.mission.title} Completed
                        </h2>
                        <p className="mt-1 max-w-xl text-xs leading-relaxed text-muted sm:text-sm">
                          Thank you for completing all {fullMissionCelebration.mission.steps} steps. Your support keeps us motivated and helps keep streams fast and free.
                        </p>
                      </div>
                    </div>
                    <div className="flex shrink-0 flex-wrap items-center gap-2.5">
                      <button
                        type="button"
                        onClick={() => setFullMissionCelebration(null)}
                        className="inline-flex items-center gap-2 whitespace-nowrap rounded-xl bg-accent px-4 py-2.5 text-xs font-semibold text-accent-fg transition hover:brightness-110"
                      >
                        <span>Done</span>
                        <ArrowRight className="size-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setFullMissionCelebration(null)
                          void shareLink(
                            'Support AnimeStream',
                            'I just supported AnimeStream to keep anime & donghua 100% free with multi-dubs in HD!',
                          )
                        }}
                        className="inline-flex items-center gap-2 whitespace-nowrap rounded-xl border border-border bg-card-2 px-4 py-2.5 text-xs font-semibold text-foreground transition hover:bg-border/60"
                      >
                        <Share2 className="size-3.5" />
                        <span>Share</span>
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Main 2-Column Workspace */}
            <div className="mt-8 grid grid-cols-1 items-start gap-8 lg:grid-cols-12">
              {/* Left Column: Mission Console (7 cols) */}
              <section className="rounded-2xl border border-border bg-card/90 p-5 backdrop-blur-md sm:p-7 lg:col-span-7">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-4">
                  <div>
                    <h2 className="font-display text-lg font-bold text-foreground sm:text-xl">
                      Support Missions
                    </h2>
                    <p className="mt-0.5 text-xs text-muted">
                      Choose a mission tier and complete each sponsor step sequentially.
                    </p>
                  </div>
                  {isInProgress && (
                    <button
                      type="button"
                      onClick={() => void handleResetProgress()}
                      disabled={syncingProgress}
                      className="inline-flex items-center gap-1.5 whitespace-nowrap rounded-lg border border-border px-3 py-1.5 text-xs font-medium text-muted transition hover:border-rose-500/40 hover:text-rose-600 dark:hover:text-rose-400"
                    >
                      <RotateCcw className="size-3.5" />
                      <span>Reset Mission</span>
                    </button>
                  )}
                </div>

                {/* Mission Tier Grid */}
                <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
                  {SUPPORT_MISSIONS.map((m) => {
                    const isSelected = m.id === selectedMissionId
                    const isThisActive = activeProgress?.missionId === m.id

                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => {
                          setSelectedMissionId(m.id)
                          const activeStep =
                            activeProgress?.missionId === m.id
                              ? activeProgress.stepSessions?.[activeProgress.currentStep]
                              : null
                          const savedUrl =
                            activeStep && !activeStep.expired && !activeStep.verifiedAt ? activeStep.url || null : null
                          setCurrentStepUrl(savedUrl)
                        }}
                        className={cn(
                          'flex flex-col justify-between rounded-xl border p-4 text-left transition',
                          isSelected
                            ? 'border-accent bg-accent/[0.07] ring-1 ring-accent/30'
                            : 'border-border bg-card-2/50 hover:border-foreground/25 hover:bg-card-2/80',
                        )}
                      >
                        <div>
                          <div className="flex items-baseline justify-between gap-2">
                            <span className="font-display text-sm font-bold text-foreground">
                              {m.title}
                            </span>
                          </div>
                          <p className="mt-1.5 text-xs leading-relaxed text-muted line-clamp-3">
                            {m.desc}
                          </p>
                        </div>

                        <div className="mt-4 flex items-center justify-between border-t border-border/70 pt-3 text-xs">
                          <span className="font-mono font-semibold tabular-nums text-foreground">
                            {m.badge}
                          </span>
                          <span className="font-mono font-semibold tabular-nums text-accent">
                            +{m.xp} XP
                          </span>
                        </div>

                        {isThisActive && (
                          <p className="mt-2 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                            {activeProgress.completedSteps}/{m.steps} steps completed
                          </p>
                        )}
                      </button>
                    )
                  })}
                </div>

                {/* Active Mission Progress & Stepper */}
                <div className="mt-6 border-t border-border pt-6">
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <div>
                      <h3 className="font-display text-base font-bold text-foreground">
                        {activeMission.title}
                      </h3>
                      <p className="mt-0.5 text-xs text-muted">
                        {isInProgress
                          ? `Step ${effectiveCurrentStep} of ${activeMission.steps} active · ${progressPercent}% complete`
                          : `${activeMission.steps} ${activeMission.steps === 1 ? 'step' : 'steps'} required · Reward: +${activeMission.xp} XP`}
                      </p>
                    </div>
                    <span className="font-mono text-xs font-semibold tabular-nums text-muted">
                      {effectiveCompletedSteps}/{activeMission.steps} Verified
                    </span>
                  </div>

                  {/* Linear Progress Bar */}
                  <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-card-2">
                    <div
                      className="h-full rounded-full bg-accent transition-all duration-300 ease-out"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>

                  {/* Step Nodes */}
                  <div className="mt-5 flex items-center gap-1.5 sm:gap-2">
                    {Array.from({ length: activeMission.steps }, (_, idx) => {
                      const stepNum = idx + 1
                      const isDone = effectiveCompletedSteps >= stepNum
                      const isCurrent = effectiveCurrentStep === stepNum && !isDone
                      const isLocked = stepNum > effectiveCurrentStep

                      return (
                        <div key={stepNum} className="flex flex-1 items-center gap-1.5 sm:gap-2">
                          <div
                            aria-label={`Step ${stepNum}: ${isDone ? 'completed' : isCurrent ? 'current' : 'locked'}`}
                            className={cn(
                              'flex size-8 shrink-0 items-center justify-center rounded-lg font-mono text-xs font-bold tabular-nums transition sm:size-9',
                              isDone
                                ? 'bg-emerald-600 text-white dark:bg-emerald-500'
                                : isCurrent
                                  ? 'border-2 border-accent bg-accent/15 text-accent'
                                  : 'border border-border bg-card-2 text-muted',
                            )}
                          >
                            {isDone ? (
                              <Check className="size-4 stroke-[2.75]" />
                            ) : isLocked ? (
                              <Lock className="size-3.5 opacity-70" />
                            ) : (
                              <span>{stepNum}</span>
                            )}
                          </div>

                          {idx < activeMission.steps - 1 && (
                            <div
                              className={cn(
                                'h-0.5 flex-1 rounded-full transition-colors',
                                isDone ? 'bg-emerald-500' : 'bg-border',
                              )}
                            />
                          )}
                        </div>
                      )
                    })}
                  </div>

                  {/* Interactive Step Action Box */}
                  <div className="mt-6 rounded-xl border border-border bg-card-2/60 p-4 sm:p-5">
                    {!currentStepUrl ? (
                      <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
                        <div className="space-y-1">
                          <h4 className="font-display text-sm font-bold text-foreground">
                            Step {effectiveCurrentStep} of {activeMission.steps} Ready
                          </h4>
                          <p className="text-xs leading-relaxed text-muted">
                            Generate a single-use ShrinkMe verification link for Step {effectiveCurrentStep}.
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => void handleGenerateStepLink()}
                          disabled={generatingStep}
                          className="inline-flex shrink-0 items-center gap-2 whitespace-nowrap rounded-xl bg-accent px-5 py-2.5 text-xs font-semibold text-accent-fg transition hover:brightness-110 disabled:opacity-50"
                        >
                          {generatingStep ? (
                            <>
                              <Loader2 className="size-4 animate-spin" />
                              <span>Generating Link…</span>
                            </>
                          ) : (
                            <>
                              <span>Start Step {effectiveCurrentStep}</span>
                              <ArrowRight className="size-4" />
                            </>
                          )}
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                            Step {effectiveCurrentStep} Link Generated
                          </span>
                          <span className="font-mono text-xs tabular-nums text-muted">
                            {effectiveCompletedSteps}/{activeMission.steps} verified
                          </span>
                        </div>

                        {/* Link Display + Copy */}
                        <div className="flex items-center gap-2 rounded-xl border border-border bg-background p-2">
                          <input
                            type="text"
                            readOnly
                            aria-label="Generated ShrinkMe step URL"
                            value={currentStepUrl}
                            className="min-w-0 flex-1 select-all bg-transparent px-2 font-mono text-xs text-foreground outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => void handleCopyStepLink()}
                            className={cn(
                              'inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition',
                              copiedLink
                                ? 'bg-emerald-600 text-white'
                                : 'bg-card-2 text-foreground hover:bg-border',
                            )}
                          >
                            {copiedLink ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
                            <span>{copiedLink ? 'Copied' : 'Copy'}</span>
                          </button>
                        </div>

                        {/* Primary & Secondary Actions */}
                        <div className="flex flex-wrap items-center gap-3">
                          <a
                            href={currentStepUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-accent px-5 py-2.5 text-xs font-semibold text-accent-fg transition hover:brightness-110 sm:text-sm"
                          >
                            <span>Open Step {effectiveCurrentStep} on ShrinkMe</span>
                            <ExternalLink className="size-4" />
                          </a>
                          <button
                            type="button"
                            onClick={() => void handleGenerateStepLink()}
                            disabled={generatingStep}
                            className="inline-flex items-center justify-center gap-1.5 whitespace-nowrap rounded-xl border border-border bg-card px-4 py-2.5 text-xs font-semibold text-foreground transition hover:bg-card-2 disabled:opacity-50"
                            title="Generate a fresh link for this step"
                          >
                            <RefreshCw className={cn('size-3.5', generatingStep && 'animate-spin')} />
                            <span>Regenerate</span>
                          </button>
                        </div>

                        {/* Clear Instructions */}
                        <div className="space-y-1.5 border-t border-border pt-3 text-xs text-muted">
                          <p className="font-semibold text-foreground">How verification works:</p>
                          <ol className="list-inside list-decimal space-y-1 text-xs leading-relaxed">
                            <li>Open the ShrinkMe link above and complete the captcha and countdown.</li>
                            <li>Click &ldquo;Get Link&rdquo; at the end to return automatically with your official verification token.</li>
                            <li>Each token is single-use and valid only for your current active step.</li>
                          </ol>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </section>

              {/* Right Column: Support & Motivate Us + Supporter Milestones (5 cols) */}
              <aside className="space-y-6 lg:col-span-5">
                {/* Support & Motivate Us */}
                <section className="rounded-2xl border border-border bg-card/90 p-5 backdrop-blur-md sm:p-6">
                  <div className="border-b border-border pb-3.5">
                    <div className="flex items-baseline justify-between gap-2">
                      <h2 className="font-display text-base font-bold text-foreground">
                        Support &amp; Motivate Us
                      </h2>
                      <span className="text-xs font-medium text-accent">
                        Community Driven
                      </span>
                    </div>
                    <p className="mt-1 text-xs leading-relaxed text-muted">
                      Every completed mission keeps us going strong and directly improves AnimeStream for everyone.
                    </p>
                  </div>

                  <div className="divide-y divide-border">
                    {MOTIVATION_PILLARS.map((item) => {
                      const Icon = item.icon
                      return (
                        <div key={item.title} className="flex items-start gap-3.5 py-3.5 first:pt-4 last:pb-0">
                          <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-accent/10 text-accent">
                            <Icon className="size-4" />
                          </span>
                          <div className="min-w-0">
                            <h3 className="text-xs font-semibold text-foreground">{item.title}</h3>
                            <p className="mt-0.5 text-xs leading-relaxed text-muted">{item.desc}</p>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </section>

                {/* Supporter Milestones */}
                <section className="rounded-2xl border border-border bg-card/90 p-5 backdrop-blur-md sm:p-6">
                  <div className="flex items-baseline justify-between border-b border-border pb-3.5">
                    <h2 className="font-display text-base font-bold text-foreground">
                      Supporter Milestones
                    </h2>
                    <span className="font-mono text-xs tabular-nums text-muted">
                      {unlockedTiersCount}/{SUPPORTER_TIERS.length} unlocked
                    </span>
                  </div>

                  <div className="divide-y divide-border">
                    {SUPPORTER_TIERS.map((tier) => {
                      const unlocked = stats.totalLinksSolved >= tier.minSteps
                      return (
                        <div
                          key={tier.title}
                          className={cn(
                            'flex items-center justify-between py-3 text-xs',
                            unlocked ? 'text-foreground' : 'text-muted',
                          )}
                        >
                          <div className="flex items-center gap-2.5">
                            {unlocked ? (
                              <CheckCircle2 className="size-4 text-emerald-600 dark:text-emerald-400" />
                            ) : (
                              <Lock className="size-3.5 opacity-60" />
                            )}
                            <span className={cn('font-semibold', unlocked && tier.color)}>
                              {tier.title}
                            </span>
                          </div>
                          <span className="font-mono tabular-nums text-muted">{tier.label}</span>
                        </div>
                      )
                    })}
                  </div>

                  <div className="mt-4 border-t border-border pt-4">
                    <button
                      type="button"
                      onClick={() =>
                        void shareLink(
                          'Support AnimeStream',
                          'Support AnimeStream for free and help keep high-speed multi-audio anime streaming online!',
                        )
                      }
                      className="flex w-full items-center justify-center gap-2 whitespace-nowrap rounded-xl border border-border bg-card-2 py-2.5 text-xs font-semibold text-foreground transition hover:bg-border/60"
                    >
                      <Share2 className="size-3.5" />
                      <span>Invite Friends to Support</span>
                    </button>
                  </div>
                </section>
              </aside>
            </div>
          </>
        )}
      </main>
    </div>
  )
}

import { useEffect, useState, useMemo, useCallback } from 'react'
import { useParams, useSearchParams } from 'react-router-dom'
import { fetchAnimeLite, type AniLite } from '../services/anilist'
import { fetchStream, fetchEpisodeServers, type StreamResult, type ServerAudioMap } from '../services/api'
import CinePlayer, { type PlayerServer } from '../components/CinePlayer'
import { StreamProblem } from '../components/StreamProblem'
import { Loader2, Play, ShieldAlert } from 'lucide-react'
import { popupsBlocked, sameOriginParent } from '../lib/embedGuard'
import { cn } from '../lib/utils'
import { serverById } from '../lib/servers'

const pill = 'rounded-full border px-4 py-2 text-xs sm:text-sm font-semibold transition active:scale-95'

const BASE_SERVER_NAMES: Record<string, string> = {
  megaplay: 'Server 1 (MegaPlay)',
  vidstream: 'Server 2 (VidStream)',
  flixcloud: 'Server 3 (FlixCloud)',
  acdn: 'Multi-Audio (ACDN)',
  desidubanime: 'DesiDubAnime (Hindi Dub)',
}

const SERVER_DISPLAY_NAMES: Record<string, string> = {
  megaplay: 'MegaPlay',
  vidstream: 'Vidstream',
  flixcloud: 'FlixCloud',
  acdn: 'ACDN',
  desidubanime: 'DesiDubAnime',
}

export default function EmbedPage() {
  const { id: pathId, ep: pathEp } = useParams<{ id?: string; ep?: string }>()
  const [searchParams, setSearchParams] = useSearchParams()

  const animeId = parseInt(searchParams.get('id') || pathId || '195604', 10)
  const ep = Math.max(1, parseInt(searchParams.get('ep') || pathEp || '1', 10))
  const rawServer = (searchParams.get('server') || 'megaplay').toLowerCase()
  const rawAudio = (searchParams.get('audio') || 'dub').toLowerCase() === 'sub' ? 'sub' : 'dub'
  const isPreview = searchParams.get('preview') === '1' && sameOriginParent()
  const [gate, setGate] = useState<'check' | 'ok' | 'blocked'>('ok')

  const [anime, setAnime] = useState<AniLite | null>(null)
  const [stream, setStream] = useState<StreamResult | null>(null)
  const [serverAvail, setServerAvail] = useState<ServerAudioMap | null>(null)
  const [streamLoading, setStreamLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const animeTitle = useMemo(() => {
    if (!anime) return ''
    return anime.title.english || anime.title.romaji || anime.title.native || ''
  }, [anime])

  // Helper to safely update URL search params
  const updateParams = useCallback(
    (updates: Record<string, string | number>) => {
      setSearchParams(
        (prev) => {
          const next = new URLSearchParams(prev)
          Object.entries(updates).forEach(([k, v]) => {
            next.set(k, String(v))
          })
          return next
        },
        { replace: true }
      )
    },
    [setSearchParams]
  )

  // Load Anime Metadata from AniList
  useEffect(() => {
    let active = true
    fetchAnimeLite(animeId)
      .then((data) => {
        if (!active) return
        setAnime(data)
        const t = data.title.english || data.title.romaji || ''
        if (t) document.title = `${t} · Ep ${ep} — AnimeStream Player`
      })
      .catch(() => {})

    return () => {
      active = false
    }
  }, [animeId, ep])

  // 4. Fetch Episode Server & Audio Availability
  useEffect(() => {
    if (gate !== 'ok') return
    let active = true

    fetchEpisodeServers(animeId, ep, animeTitle)
      .then((map) => {
        if (!active) return
        setServerAvail(map)
      })
      .catch(() => {})

    return () => {
      active = false
    }
  }, [animeId, ep, animeTitle, gate])

  // 5. Server & Audio Availability
  const effectiveServer = rawServer
  const effectiveAudio = rawAudio
  const srvInfo = serverAvail?.[effectiveServer]
  const hasSub = Boolean(srvInfo?.sub ?? true)
  const hasDub = Boolean(srvInfo?.dub ?? false)
  const hasAnyDub = useMemo(() => {
    if (!serverAvail) return false
    return Object.values(serverAvail).some((s) => Boolean(s?.dub || s?.multi))
  }, [serverAvail])

  // 6. Build Formatted Server List for CinePlayer (Always keep all servers accessible)
  const formattedServers: PlayerServer[] = useMemo(() => {
    const order = ['megaplay', 'vidstream', 'flixcloud', 'acdn', 'desidubanime']
    return order.map((key) => {
      const avail = serverAvail?.[key]
      const tags: string[] = []
      if (key === 'desidubanime') {
        tags.push('HINDI', 'DUB')
      } else {
        if (avail?.sub) tags.push('SUB')
        if (avail?.dub) tags.push('DUB')
        if (avail?.multi && !avail.sub && !avail.dub) tags.push('MULTI')
        if (!tags.length) tags.push('SUB')
      }
      return {
        id: key,
        name: BASE_SERVER_NAMES[key] || key.toUpperCase(),
        note: key === 'desidubanime' ? 'Hindi Dub only' : tags.join(' · '),
        access: serverById(key).access,
        tags,
      }
    })
  }, [serverAvail])

  // 7. Fetch Stream when (animeId, ep, effectiveServer, effectiveAudio) is requested
  useEffect(() => {
    if (gate !== 'ok') return
    let active = true
    setStreamLoading(true)
    setError(null)

    fetchStream({
      id: animeId,
      ep,
      server: effectiveServer,
      audio: effectiveAudio,
      title: animeTitle,
      format: anime?.format,
    })
      .then((res) => {
        if (!active) return
        if (!res?.streamUrl) {
          setError('No stream found.')
          return
        }
        setStream(res)
      })
      .catch((err) => {
        if (!active) return
        const raw = String(err?.message || '')
        let friendly = 'Unavailable on this server. Try other server.'
        if (effectiveAudio === 'dub') {
          friendly = 'Unavailable on this server. Try other or try SUB.'
        } else if (/no (sub|dub) stream|resolution failed|not found/i.test(raw)) {
          friendly = 'Unavailable on this server. Try other server.'
        } else {
          friendly = raw || 'Unavailable on this server. Try other server.'
        }
        setError(friendly)
      })
      .finally(() => {
        if (active) setStreamLoading(false)
      })

    return () => {
      active = false
    }
  }, [animeId, ep, effectiveServer, effectiveAudio, animeTitle, anime?.format, gate])

  const altServerId = useMemo(() => {
    const list = ['megaplay', 'vidstream', 'flixcloud', 'acdn', 'desidubanime']
    const idx = list.indexOf(effectiveServer)
    return list[(idx + 1) % list.length] || 'megaplay'
  }, [effectiveServer])

  const altServerName = SERVER_DISPLAY_NAMES[altServerId] || altServerId

  const totalEpisodes = anime?.episodes || 24
  const hasNext = ep < totalEpisodes
  const hasPrev = ep > 1

  return (
    <div className="fixed inset-0 h-screen w-screen overflow-hidden bg-black select-none">
      {gate === 'blocked' ? (
        <div className="flex h-full w-full items-center justify-center bg-[#070709] p-4 text-white">
          <div className="w-full max-w-sm rounded-2xl border border-white/10 bg-[#121217] p-6 text-center">
            <ShieldAlert className="mx-auto mb-3 size-8 text-rose-400" />
            <h2 className="mb-1.5 text-base font-bold">Embed blocked</h2>
            <p className="mb-4 text-xs leading-relaxed text-zinc-400">
              This player can't run in a sandboxed frame. Remove the <code>sandbox</code> attribute from the iframe, or watch on AnimeStream.
            </p>
            <a href={location.origin} target="_top" className="inline-flex rounded-xl bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-500">
              Open AnimeStream
            </a>
          </div>
        </div>
      ) : gate === 'check' ? (
        <button
          type="button"
          onClick={() => setGate(popupsBlocked() ? 'blocked' : 'ok')}
          aria-label="Play"
          className="group relative flex h-full w-full items-center justify-center bg-black bg-cover bg-center"
          style={{ backgroundImage: anime?.bannerImage || anime?.coverImage?.extraLarge ? `url(${anime?.bannerImage || anime?.coverImage?.extraLarge})` : undefined }}
        >
          <span className="absolute inset-0 bg-black/50" />
          <span className="relative grid size-16 place-items-center rounded-full bg-rose-600 text-white shadow-2xl transition group-hover:scale-110">
            <Play className="size-7 fill-current" />
          </span>
        </button>
      ) : error ? (
        <StreamProblem reason={error} onReconnect={() => updateParams({ server: altServerId })}>
          <button
            type="button"
            onClick={() => updateParams({ server: altServerId })}
            className={cn(pill, 'border-transparent bg-white text-black hover:bg-white/90')}
          >
            Try {altServerName}
          </button>
          {effectiveAudio === 'dub' ? (
            <button
              type="button"
              onClick={() => updateParams({ audio: 'sub' })}
              className={cn(pill, 'border-white/15 bg-white/5 text-white hover:bg-white/10')}
            >
              SUB instead
            </button>
          ) : hasAnyDub ? (
            <button
              type="button"
              onClick={() => updateParams({ audio: 'dub' })}
              className={cn(pill, 'border-white/15 bg-white/5 text-white hover:bg-white/10')}
            >
              DUB instead
            </button>
          ) : null}
        </StreamProblem>
      ) : stream ? (
        <CinePlayer
          streamUrl={stream.streamUrl}
          title={animeTitle || 'Anime Stream'}
          episode={ep}
          totalEpisodes={totalEpisodes}
          availableEpisodes={totalEpisodes}
          animeId={animeId}
          format={anime?.format}
          preview={isPreview}
          directSubtitles={stream.subtitles.map((s, i) => ({
            id: `sub-${i}`,
            label: s.label,
            lang: s.label,
            url: s.file,
          }))}
          audioMode={effectiveAudio}
          hasDub={hasDub}
          hasSub={hasSub}
          onAudio={(m) => updateParams({ audio: m })}
          servers={formattedServers}
          serverId={effectiveServer}
          onServer={(sid) => updateParams({ server: sid })}
          hasNextEpisode={hasNext}
          hasPrevEpisode={hasPrev}
          onNextEpisode={() => updateParams({ ep: ep + 1 })}
          onPrevEpisode={() => updateParams({ ep: ep - 1 })}
          onSelectEpisode={(n) => updateParams({ ep: n })}
          onEnded={() => {
            if (hasNext) {
              updateParams({ ep: ep + 1 })
            }
          }}
          intro={stream.intro}
          outro={stream.outro}
          switching={streamLoading}
          fallbackImg={anime?.bannerImage || anime?.coverImage?.extraLarge}
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center bg-black text-white/80">
          <Loader2 className="size-8 animate-spin text-rose-500" />
        </div>
      )}
    </div>
  )
}

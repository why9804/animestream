import { AnimatePresence, motion } from 'framer-motion'
import { Check, Info, TriangleAlert } from 'lucide-react'
import { dismissToast, useToasts } from '../lib/toast'
import { cn } from '../lib/utils'

const ICON = { success: Check, info: Info, error: TriangleAlert }

/** Mounted once in App. Polite live region; tap a toast to dismiss it. */
export function Toaster() {
  const list = useToasts()
  return (
    <div aria-live="polite" role="status" className="pointer-events-none fixed inset-x-0 bottom-[calc(6rem+env(safe-area-inset-bottom))] z-[120] flex flex-col-reverse items-center gap-2 px-4 sm:bottom-8">
      <AnimatePresence mode="popLayout">
        {list.map((t) => {
          const Icon = ICON[t.kind]
          return (
            <motion.button
              key={t.id}
              type="button"
              layout
              onClick={() => dismissToast(t.id)}
              initial={{ opacity: 0, y: 22, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 14, scale: 0.94 }}
              transition={{ type: 'spring', stiffness: 380, damping: 26 }}
              className="pointer-events-auto relative flex max-w-[min(92vw,24rem)] items-center gap-3 overflow-hidden rounded-2xl border border-border bg-card py-2.5 pl-2.5 pr-4 text-left text-sm font-semibold text-foreground shadow-2xl shadow-black/40"
            >
              <span className={cn('grid size-7 shrink-0 place-items-center rounded-full', t.kind === 'error' ? 'bg-red-500/20 text-red-400' : 'bg-accent text-accent-fg')}>
                <Icon className="size-4" strokeWidth={3} />
              </span>
              <span className="min-w-0">{t.message}</span>
              <motion.span aria-hidden className={cn('absolute bottom-0 left-0 h-0.5 w-full origin-left', t.kind === 'error' ? 'bg-red-400' : 'bg-accent')} initial={{ scaleX: 1 }} animate={{ scaleX: 0 }} transition={{ duration: t.kind === 'error' ? 4.2 : 2.6, ease: 'linear' }} />
            </motion.button>
          )
        })}
      </AnimatePresence>
    </div>
  )
}

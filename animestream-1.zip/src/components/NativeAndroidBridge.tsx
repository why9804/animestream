import { useEffect, useRef } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { App as NativeApp } from '@capacitor/app'
import { Capacitor } from '@capacitor/core'
import { StatusBar } from '@capacitor/status-bar'

/** Native Android system-back integration for the React Router history stack. */
export default function NativeAndroidBridge() {
  const location = useLocation()
  const navigate = useNavigate()
  const locationRef = useRef(location)
  const navigateRef = useRef(navigate)

  useEffect(() => {
    locationRef.current = location
  }, [location])

  useEffect(() => {
    navigateRef.current = navigate
  }, [navigate])

  useEffect(() => {
    if (!Capacitor.isNativePlatform() || Capacitor.getPlatform() !== 'android') return

    let disposed = false
    let removeListener: (() => void) | undefined

    void StatusBar.setOverlaysWebView({ overlay: false }).catch(() => {})
    void StatusBar.show().catch(() => {})

    NativeApp.addListener('backButton', () => {
      // CinePlayer gets first refusal: Back should leave fullscreen before leaving the page.
      const nativeBack = new CustomEvent('animestream:native-back', { cancelable: true })
      const notHandled = window.dispatchEvent(nativeBack)
      if (!notHandled) return

      const historyIndex = Number(window.history.state?.idx)
      if (Number.isFinite(historyIndex) && historyIndex > 0) {
        navigateRef.current(-1)
        return
      }

      const path = locationRef.current.pathname
      if (path !== '/' && path !== '/home') {
        navigateRef.current('/home', { replace: true })
        return
      }

      void NativeApp.exitApp()
    }).then((listener) => {
      if (disposed) {
        void listener.remove()
      } else {
        removeListener = () => void listener.remove()
      }
    }).catch((error) => {
      console.warn('[AnimeStream] Android back-button listener failed:', error)
    })

    return () => {
      disposed = true
      removeListener?.()
      void StatusBar.show().catch(() => {})
    }
  }, [])

  return null
}

import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  X,
  Film,
  BookOpen,
  Book,
  Clapperboard,
  MessageSquare,
  Compass,
  CalendarDays,
  Bookmark,
  TrendingUp,
  User,
  LogOut,
  ChevronRight,
  Flame,
  Star,
  Search,
  Users,
  MonitorPlay,
  ArrowRight,
  Heart,
} from 'lucide-react'
import { getWatchRoom } from '../lib/watchRooms'
import { toast } from '../lib/toast'
import { useAuth } from '../context/AuthContext'
import { useProfile } from '../lib/profile'
import { useSearch } from '../context/SearchContext'
import { Avatar } from './Avatar'
import { Logo } from './Logo'
import { StyledDisplayName } from './StyledDisplayName'
import { ThemeToggle } from './ThemeToggle'
import { cn } from '../lib/utils'

interface NavSection {
  title: string
  items: {
    label: string
    to: string
    icon: React.ComponentType<{ className?: string }>
    badge?: string
    isExternal?: boolean
  }[]
}

export function NavDrawer({
  open,
  onClose,
}: {
  open: boolean
  onClose: () => void
}) {
  const { pathname } = useLocation()
  const { user, username, signOut } = useAuth()
  const me = useProfile()
  const { openSearch } = useSearch()
  const drawerRef = useRef<HTMLDivElement>(null)
  const navigate = useNavigate()
  const [code, setCode] = useState('')
  const [joining, setJoining] = useState(false)

  const joinParty = async (e: React.FormEvent) => {
    e.preventDefault()
    const c = code.trim().toLowerCase()
    if (c.length < 3 || joining) return
    setJoining(true)
    try {
      const rec = await getWatchRoom(c)
      if (!rec) return toast('Watch party not found or expired', 'error')
      setCode('')
      onClose()
      navigate(`/watch/${rec.anime_id}?room=${c}&ep=${rec.episode}&server=${rec.server}&audio=${rec.audio}`)
    } finally {
      setJoining(false)
    }
  }

  // Close on route change
  useEffect(() => {
    onClose()
  }, [pathname])

  // While open, pause the page's running animations and lock background scroll & zoom leaks
  useEffect(() => {
    if (!open) return
    const el = document.documentElement
    const body = document.body
    const prevBodyOverflow = body.style.overflow
    const prevHtmlOverflow = el.style.overflow
    const prevBodyTouchAction = body.style.touchAction

    el.dataset.drawer = ''
    body.style.overflow = 'hidden'
    el.style.overflow = 'hidden'
    body.style.touchAction = 'none'

    return () => {
      delete el.dataset.drawer
      body.style.overflow = prevBodyOverflow
      el.style.overflow = prevHtmlOverflow
      body.style.touchAction = prevBodyTouchAction
    }
  }, [open])

  // Close on Escape key
  useEffect(() => {
    if (!open) return
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [open, onClose])

  const SECTIONS: NavSection[] = [
    {
      title: 'Anime & Donghua',
      items: [
        { label: 'Anime Home', to: '/home', icon: Film },
        { label: 'Donghua Hub', to: '/donghua', icon: Clapperboard, badge: 'CN' },
        { label: 'Browse Donghua', to: '/donghua/browse', icon: Compass },
        { label: 'Trending', to: '/trending', icon: Flame, badge: 'Hot' },
        { label: 'Popular', to: '/popular', icon: TrendingUp },
        { label: 'Top Rated', to: '/top', icon: Star },
        { label: 'Browse Catalog', to: '/browse', icon: Compass },
        { label: 'Release Schedule', to: '/schedule', icon: CalendarDays },
        { label: 'My Watchlist', to: '/list', icon: Bookmark },
      ],
    },
    {
      title: 'Manga, Manhwa & Novels',
      items: [
        { label: 'Manga Hub', to: '/manga', icon: BookOpen },
        { label: 'Browse Manga', to: '/manga/browse', icon: Compass },
        { label: 'Manhwa Hub', to: '/manhwa', icon: BookOpen, badge: 'KR' },
        { label: 'Browse Manhwa', to: '/manhwa/browse', icon: Compass },
        { label: 'Light Novels Hub', to: '/novel', icon: Book },
        { label: 'Find Novels', to: '/novel/find', icon: Search },
      ],
    },
    {
      title: 'Movies & TV',
      items: [
        { label: 'Movies Hub', to: '/movies', icon: Clapperboard },
        { label: 'Browse Movies & Series', to: '/movies/browse', icon: Compass },
      ],
    },
    {
      title: 'Social & Inbox',
      items: [
        { label: 'Direct Messages', to: '/messages', icon: MessageSquare },
        { label: 'Community Lounge', to: '/community', icon: Users, badge: 'Live' },
        ...(username ? [{ label: 'My Public Profile', to: `/u/${username}`, icon: User }] : []),
      ],
    },
    {
      title: 'Support',
      items: [
        { label: 'Support AnimeStream', to: '/support', icon: Heart },
      ],
    },
  ]

  return createPortal(
    <AnimatePresence>
      {open && (
        <div
          className="fixed inset-0 z-[150] flex h-[100dvh] w-full overflow-hidden select-none"
          style={{ touchAction: 'none' }}
        >
          {/* Backdrop with touchAction none and backdrop blur to prevent background zoom glitch */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/75 backdrop-blur-[2px]"
            style={{ touchAction: 'none' }}
          />

          {/* Drawer Sidebar */}
          <motion.div
            ref={drawerRef}
            initial={{ x: '-100%' }}
            animate={{ x: '0%' }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 280 }}
            className="relative z-10 flex h-full h-[100dvh] max-h-[100dvh] w-[min(86vw,22rem)] max-w-[calc(100vw-2.5rem)] flex-col border-r border-border bg-card shadow-2xl select-text"
            style={{ touchAction: 'pan-y', willChange: 'transform' }}
          >
            {/* Drawer Header */}
            <div className="flex items-center justify-between border-b border-border/70 p-4 sm:px-6">
              <div className="flex items-center gap-3">
                <Logo size={32} showText={false} />
                <span className="font-display text-sm font-bold tracking-tight text-foreground">
                  Navigation
                </span>
              </div>
              <div className="flex items-center gap-2">
                <ThemeToggle />
                <button
                  type="button"
                  onClick={onClose}
                  aria-label="Close menu"
                  className="grid size-9 place-items-center rounded-full text-muted transition hover:bg-card-2 hover:text-foreground active:scale-90"
                >
                  <X className="size-5" />
                </button>
              </div>
            </div>

            {/* User Profile Card (if logged in) */}
            <div className="border-b border-border/60 p-4 sm:px-6">
              {user ? (
                <Link
                  to="/profile"
                  onClick={onClose}
                  className="flex items-center gap-3 rounded-2xl border border-border/60 bg-card-2/60 p-3 transition hover:border-accent/40 active:scale-[0.98]"
                >
                  <Avatar size={40} src={me.avatar} frame={me.frame} name={me.name} animateFrame />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-bold text-foreground">
                      <StyledDisplayName isSelf name={me.name || 'Your Profile'} styleSpec={me.nameStyle ?? null} />
                    </p>
                    <p className="truncate text-[11px] text-muted">
                      @{username || user.email?.split('@')[0]}
                    </p>
                  </div>
                  <ChevronRight className="size-4 text-muted" />
                </Link>
              ) : (
                <Link
                  to="/profile"
                  onClick={onClose}
                  className="flex h-11 items-center justify-center gap-2 rounded-2xl bg-foreground px-4 text-xs font-bold text-background transition hover:opacity-90 active:scale-95"
                >
                  <User className="size-4" />
                  <span>Sign In / Register</span>
                </Link>
              )}

              {/* Quick Search Button in Drawer */}
              <button
                type="button"
                onClick={() => {
                  onClose()
                  openSearch()
                }}
                className="mt-2.5 flex h-10 w-full items-center gap-2.5 rounded-xl border border-border bg-card-2/80 px-3 text-xs text-muted transition hover:border-accent/40 hover:text-foreground"
              >
                <Search className="size-4" />
                <span>Search anime, manga, movies…</span>
              </button>
            </div>

            {/* Scrollable Navigation Sections */}
            <div
              className="flex-1 min-h-0 overflow-y-auto px-3 py-4 space-y-6 overscroll-contain"
              style={{ touchAction: 'pan-y' }}
            >
              {SECTIONS.map((sec) => (
                <div key={sec.title}>
                  <h3 className="px-3 text-[10px] font-bold uppercase tracking-wider text-muted">
                    {sec.title}
                  </h3>
                  <div className="mt-1.5 space-y-0.5">
                    {sec.items.map((item) => {
                      const Icon = item.icon
                      const isActive = pathname === item.to
                      return (
                        <Link
                          key={item.to}
                          to={item.to}
                          className={cn(
                            'flex items-center justify-between rounded-xl px-3 py-2 text-xs font-semibold transition active:scale-[0.98]',
                            isActive
                              ? 'bg-accent/15 text-accent font-bold shadow-sm'
                              : 'text-foreground/90 hover:bg-card-2 hover:text-foreground'
                          )}
                        >
                          <div className="flex items-center gap-2.5">
                            <Icon className={cn('size-4', isActive ? 'text-foreground' : 'text-muted')} />
                            <span>{item.label}</span>
                          </div>
                          {item.badge && (
                            <span className="rounded-full border border-border px-2 py-0.5 text-[9px] font-semibold text-muted">
                              {item.badge}
                            </span>
                          )}
                        </Link>
                      )
                    })}
                  </div>
                </div>
              ))}

              <div>
                <h3 className="px-3 text-[10px] font-bold uppercase tracking-wider text-muted">Watch Together</h3>
                <form onSubmit={joinParty} className="mt-1.5 flex items-center gap-2 px-3">
                  <MonitorPlay className="size-4 shrink-0 text-muted" />
                  <input
                    value={code}
                    onChange={(e) => setCode(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))}
                    placeholder="Join with room code"
                    aria-label="Watch party room code"
                    className="h-10 min-w-0 flex-1 rounded-xl border border-border bg-card-2/80 px-3 text-xs outline-none transition placeholder:text-muted focus:border-foreground"
                  />
                  <button type="submit" disabled={code.trim().length < 3 || joining} aria-label="Join watch party" className="grid size-10 shrink-0 place-items-center rounded-xl bg-foreground text-background transition active:scale-90 disabled:opacity-40">
                    <ArrowRight className="size-4" />
                  </button>
                </form>
              </div>
            </div>

            {/* Drawer Footer */}
            {user && (
              <div className="border-t border-border/70 p-3 sm:px-6">
                <button
                  type="button"
                  onClick={() => {
                    onClose()
                    void signOut()
                  }}
                  className="flex h-10 w-full items-center justify-center gap-2 rounded-xl border border-border/60 bg-card-2/40 text-xs font-semibold text-rose-400 transition hover:bg-rose-500/10 active:scale-95"
                >
                  <LogOut className="size-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body,
  )
}

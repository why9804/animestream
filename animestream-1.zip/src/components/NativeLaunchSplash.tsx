import { useEffect, useState } from 'react'
import { Capacitor } from '@capacitor/core'
import { StatusBar } from '@capacitor/status-bar'

/** A short, native-only branded intro shown after Android's system launch screen. */
export default function NativeLaunchSplash() {
  const [visible, setVisible] = useState(false)
  const [closing, setClosing] = useState(false)

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return

    void StatusBar.hide().catch(() => {})
    setVisible(true)
    const closeTimer = window.setTimeout(() => setClosing(true), 2250)
    const removeTimer = window.setTimeout(() => {
      setVisible(false)
      void StatusBar.show().catch(() => {})
    }, 2850)

    return () => {
      window.clearTimeout(closeTimer)
      window.clearTimeout(removeTimer)
      void StatusBar.show().catch(() => {})
    }
  }, [])

  if (!visible) return null

  return (
    <div
      className={`as-native-splash${closing ? ' as-native-splash--closing' : ''}`}
      role="status"
      aria-label="AnimeStream is starting"
      aria-live="polite"
    >
      <div className="as-splash-glow as-splash-glow--one" />
      <div className="as-splash-glow as-splash-glow--two" />
      <div className="as-splash-grid" />

      <div className="as-splash-content">
        <div className="as-splash-mark-stage">
          <span className="as-splash-orbit as-splash-orbit--outer" />
          <span className="as-splash-orbit as-splash-orbit--inner" />
          <span className="as-splash-mark-halo" />
          <img
            className="as-splash-mark"
            src="/logo.png"
            alt=""
            draggable={false}
          />
          <span className="as-splash-light-sweep" />
        </div>

        <div className="as-splash-brand">
          <div className="as-splash-eyebrow">YOUR SCREEN. YOUR UNIVERSE.</div>
          <div className="as-splash-wordmark">
            <span>ANIME</span><strong>STREAM</strong>
          </div>
          <div className="as-splash-tagline">A universe of stories awaits</div>
        </div>

        <div className="as-splash-loading" aria-hidden="true">
          <span className="as-splash-loading-track">
            <span className="as-splash-loading-fill" />
          </span>
          <span className="as-splash-loading-label">PREPARING YOUR EXPERIENCE</span>
        </div>
      </div>

      <div className="as-splash-footer" aria-hidden="true">
        <span>ANIME</span><i /> <span>MOVIES</span><i /> <span>MANGA</span><i /> <span>NOVELS</span>
      </div>
    </div>
  )
}

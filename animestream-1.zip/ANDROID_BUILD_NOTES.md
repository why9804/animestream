# AnimeStream Android build notes

- The Android app ID is `com.animestream.app`.
- The frontend's native Capacitor runtime routes `/api/*` and `/proxy` to the existing Cloudflare Pages backend at `https://animestream-697.pages.dev` (overridable with `VITE_API_BASE`).
- Native API requests use the existing AnimeStream APK barrier header defined by `server/shield.js`; browser builds retain the normal Zenkai Shield challenge flow.
- HLS.js requests to the Pages backend receive the same APK headers so manifests and segments do not get blocked by the backend barrier.
- After `npx cap add android`, run `bash scripts/apply-android-branding.sh` to apply the supplied AnimeStream launcher icon.

- Android fullscreen mode hides the native Android status bar and restores it when leaving fullscreen or unmounting the player.
- Android hardware Back exits player fullscreen first; the next Back follows the React Router history instead of closing the Capacitor activity.
- Launcher icons are regenerated from `public/logo.png`; adaptive and legacy density assets use the original red/white mark on a black background.
- Capacitor plugins `@capacitor/app` and `@capacitor/status-bar` are installed as major-version-8 plugins.

- Native cold-start now uses the AnimeStream logo on a near-black, fullscreen Android splash background, followed by a native-only animated React intro; browser website startup is unchanged. The status bar is restored after the intro.

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RES="$ROOT/android/app/src/main/res"
BRAND="$ROOT/android-branding/res"
MANIFEST="$ROOT/android/app/src/main/AndroidManifest.xml"

if [[ ! -d "$ROOT/android/app/src/main" ]]; then
  echo "Android platform has not been generated yet; run npx cap add android first."
  exit 1
fi

for asset in \
  "$BRAND/drawable/ic_launcher_foreground.png" \
  "$BRAND/drawable/splash.png" \
  "$BRAND/drawable/splash_background.xml" \
  "$BRAND/values/splash_colors.xml" \
  "$BRAND/mipmap-anydpi-v26/ic_launcher.xml" \
  "$BRAND/mipmap-anydpi-v26/ic_launcher_round.xml" \
  "$BRAND/mipmap-xxxhdpi/ic_launcher.png"; do
  if [[ ! -s "$asset" ]]; then
    echo "ERROR: Required AnimeStream branding asset is missing: $asset"
    exit 1
  fi
done

mkdir -p "$RES"
cp -a "$BRAND/." "$RES/"

if [[ ! -f "$MANIFEST" ]]; then
  echo "ERROR: AndroidManifest.xml not found: $MANIFEST"
  exit 1
fi

python3 - "$MANIFEST" "$RES" <<'PYXML'
from pathlib import Path
import re, sys
manifest = Path(sys.argv[1])
res = Path(sys.argv[2])
s = manifest.read_text()
app = re.search(r'<application\b[^>]*>', s, flags=re.S)
if not app:
    raise SystemExit('ERROR: <application> tag missing from AndroidManifest.xml')
tag = app.group(0)
for attr, value in (
    ('android:icon', '@mipmap/ic_launcher'),
    ('android:roundIcon', '@mipmap/ic_launcher_round'),
):
    pattern = rf'{re.escape(attr)}="[^"]*"'
    replacement = f'{attr}="{value}"'
    if re.search(pattern, tag):
        tag = re.sub(pattern, replacement, tag)
    else:
        tag = tag[:-1] + f' {replacement}>'
manifest.write_text(s[:app.start()] + tag + s[app.end():])

# Capacitor's generated launch theme differs slightly across Android versions.
# Patch every launch/splash style found, without replacing the generated theme parent.
for style_file in sorted((res / 'values').glob('styles.xml')) + sorted((res / 'values-v31').glob('styles.xml')):
    text = style_file.read_text()
    is_v31 = style_file.parent.name == 'values-v31'
    item_values = {
        'android:background': '@drawable/splash_background',
        'android:windowBackground': '@drawable/splash_background',
        'android:windowFullscreen': 'true',
    }
    if is_v31:
        item_values.update({
            'android:windowSplashScreenBackground': '@color/animestream_splash_background',
            'android:windowSplashScreenAnimatedIcon': '@drawable/splash',
            'android:windowSplashScreenAnimationDuration': '900',
        })

    def patch_style(match):
        opening, body, closing = match.groups()
        for name, value in item_values.items():
            item = f'<item name="{name}">{value}</item>'
            pattern = rf'<item\s+name="{re.escape(name)}">.*?</item>'
            if re.search(pattern, body, flags=re.S):
                body = re.sub(pattern, item, body, flags=re.S)
            else:
                body = body.rstrip() + '\n        ' + item + '\n    '
        return opening + body + closing

    patched, count = re.subn(
        r'(<style\b[^>]*\bname="[^"]*(?:Launch|Splash)[^"]*"[^>]*>)(.*?)(</style>)',
        patch_style,
        text,
        flags=re.S,
    )
    if count:
        style_file.write_text(patched)
        print(f'Patched native splash theme: {style_file}')

# Verify the launcher and splash assets that will be packaged.
for rel in (
    'mipmap-xxxhdpi/ic_launcher.png',
    'drawable/ic_launcher_foreground.png',
    'drawable/splash.png',
    'drawable/splash_background.xml',
):
    if not (res / rel).is_file() or (res / rel).stat().st_size == 0:
        raise SystemExit(f'ERROR: Native branding output missing: {rel}')

final_manifest = manifest.read_text()
if 'android:icon="@mipmap/ic_launcher"' not in final_manifest:
    raise SystemExit('ERROR: Launcher icon was not applied')
if 'android:roundIcon="@mipmap/ic_launcher_round"' not in final_manifest:
    raise SystemExit('ERROR: Round launcher icon was not applied')
print('AnimeStream launcher branding and native splash screen applied.')
PYXML

chmod +x scripts/apply-android-branding.sh


# Register the native orientation/immersive-mode bridge used by CinePlayer.
JAVA_ROOT="$ROOT/android/app/src/main/java"
mkdir -p "$JAVA_ROOT/com/animestream/app"
cp "$ROOT/scripts/AnimeStreamNativePlugin.java" "$JAVA_ROOT/com/animestream/app/AnimeStreamNativePlugin.java"
MAIN_ACTIVITY="$(find "$JAVA_ROOT" -type f \( -name 'MainActivity.java' -o -name 'MainActivity.kt' \) -print -quit)"
if [[ -z "$MAIN_ACTIVITY" ]]; then
  echo "ERROR: Capacitor MainActivity.java/.kt not found under $JAVA_ROOT"
  exit 1
fi
python3 - "$MAIN_ACTIVITY" <<'PYMAIN'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text()
if 'AnimeStreamNativePlugin' not in s:
    if p.suffix == '.java':
        if 'import com.animestream.app.AnimeStreamNativePlugin;' not in s:
            # Same package import is harmless and makes non-default package builds explicit.
            package = re.search(r'^package\s+[^;]+;', s, re.M)
            if package and package.group(0).replace('package ', '').replace(';','').strip() != 'com.animestream.app':
                s = s.replace(package.group(0), package.group(0) + '\n\nimport com.animestream.app.AnimeStreamNativePlugin;')
        if 'void onCreate(' in s:
            s = re.sub(r'(void\s+onCreate\s*\([^)]*\)\s*\{)', r'\1\n        registerPlugin(AnimeStreamNativePlugin.class);', s, count=1)
        else:
            s = re.sub(r'(class\s+MainActivity\s+extends\s+BridgeActivity\s*\{)', r'\1\n    @Override\n    public void onCreate(android.os.Bundle savedInstanceState) {\n        registerPlugin(AnimeStreamNativePlugin.class);\n        super.onCreate(savedInstanceState);\n    }', s, count=1)
    else:
        if 'import com.animestream.app.AnimeStreamNativePlugin' not in s:
            s = s.replace('import com.getcapacitor.BridgeActivity', 'import com.getcapacitor.BridgeActivity\nimport com.animestream.app.AnimeStreamNativePlugin')
        if 'override fun onCreate(' in s:
            s = re.sub(r'(override\s+fun\s+onCreate\s*\([^)]*\)\s*\{)', r'\1\n        registerPlugin(AnimeStreamNativePlugin::class.java)', s, count=1)
        else:
            s = re.sub(r'(class\s+MainActivity\s*:\s*BridgeActivity\s*\(\)\s*\{)', r'\1\n    override fun onCreate(savedInstanceState: android.os.Bundle?) {\n        registerPlugin(AnimeStreamNativePlugin::class.java)\n        super.onCreate(savedInstanceState)\n    }', s, count=1)
    if 'registerPlugin(AnimeStreamNativePlugin' not in s:
        raise SystemExit('ERROR: Could not register AnimeStreamNativePlugin in MainActivity')
    p.write_text(s)
print(f'Registered AnimeStreamNativePlugin in {p}')
PYMAIN

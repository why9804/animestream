# AnimeStream Android build notes

- The Android app ID is `com.animestream.app`.
- The frontend's native Capacitor runtime routes `/api/*` and `/proxy` to the existing Cloudflare Pages backend at `https://animestream-697.pages.dev` (overridable with `VITE_API_BASE`).
- Native API requests use the existing AnimeStream APK barrier header defined by `server/shield.js`; browser builds retain the normal Zenkai Shield challenge flow.
- HLS.js requests to the Pages backend receive the same APK headers so manifests and segments do not get blocked by the backend barrier.
- After `npx cap add android`, run `bash scripts/apply-android-branding.sh` to apply the supplied AnimeStream launcher icon.

- Android fullscreen calls a native Capacitor bridge to lock the real Activity into sensor-landscape and hide both status/navigation bars; exit restores the system bars and orientation.
- Android hardware Back exits player fullscreen first; the next Back follows the React Router history instead of closing the Capacitor activity.
- Launcher icons are regenerated from `public/logo.png`; adaptive and legacy density assets use the original red/white mark on a black background.
- Capacitor plugins `@capacitor/app` and `@capacitor/status-bar` are installed as major-version-8 plugins.

- Native cold-start uses a short, lightweight native-only logo handoff after the first app paint; browser website startup is unchanged. Heavy looping animations were removed to prevent startup jank.

- Player Fit mode uses object-fit: contain in both portrait and landscape so video edges are not cropped.

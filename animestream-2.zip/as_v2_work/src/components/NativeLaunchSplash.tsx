import { useEffect, useState } from 'react'
import { Capacitor } from '@capacitor/core'
import { StatusBar } from '@capacitor/status-bar'

/** Lightweight native-only handoff; the web app is already mounted underneath. */
export default function NativeLaunchSplash() {
  const [visible, setVisible] = useState(false)
  const [closing, setClosing] = useState(false)

  useEffect(() => {
    if (!Capacitor.isNativePlatform() || Capacitor.getPlatform() !== 'android') return

    let showTimer = 0
    let closeTimer = 0
    let removeTimer = 0
    let disposed = false

    void StatusBar.hide().catch(() => {})
    // Wait for the first browser paint so the intro animation does not compete
    // with React's initial render and route/data setup.
    showTimer = window.setTimeout(() => {
      if (!disposed) setVisible(true)
    }, 90)
    closeTimer = window.setTimeout(() => {
      if (!disposed) setClosing(true)
    }, 1120)
    removeTimer = window.setTimeout(() => {
      if (!disposed) {
        setVisible(false)
        void StatusBar.show().catch(() => {})
      }
    }, 1450)

    return () => {
      disposed = true
      window.clearTimeout(showTimer)
      window.clearTimeout(closeTimer)
      window.clearTimeout(removeTimer)
      void StatusBar.show().catch(() => {})
    }
  }, [])

  if (!visible) return null

  return (
    <div className={`as-native-splash${closing ? ' as-native-splash--closing' : ''}`} role="status" aria-label="AnimeStream">
      <div className="as-splash-glow" />
      <div className="as-splash-content">
        <div className="as-splash-mark-stage">
          <span className="as-splash-mark-halo" />
          <img className="as-splash-mark" src="/logo.png" alt="" draggable={false} />
          <span className="as-splash-light-sweep" />
        </div>
        <div className="as-splash-wordmark"><span>ANIME</span><strong>STREAM</strong></div>
        <div className="as-splash-tagline">A universe of stories awaits</div>
        <span className="as-splash-loading-track"><span className="as-splash-loading-fill" /></span>
      </div>
    </div>
  )
}

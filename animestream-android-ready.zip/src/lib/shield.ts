import { useSyncExternalStore } from 'react'

/**
 * Zenkai Shield (client): solves the server's proof-of-work once, then adds the token to every
 * same-origin /api and /proxy fetch. It is invisible unless DevTools / a bot is detected, or the server asks for a captcha.
 * The server half is server/shield.js; with no SHIELD_SECRET set there it hands out no token and this stays idle.
 */
const API = (import.meta.env.VITE_API_BASE as string | undefined) ?? ''
const KEY = { tok: 'zenkai_shield_token', exp: 'zenkai_shield_exp' }

/* ---------- tiny store for the overlay ---------- */
interface State {
  devtools: boolean
  bot: boolean
  /** Set while the server wants a captcha solved (svg is the image). */
  captcha: { svg: string; error: boolean } | null
  verified: boolean
  /** token fetch gave up (network / rate limit / server error); UI can offer a retry */
  failed: boolean
}

let token: string | null = null
let exp = 0
try {
  token = sessionStorage.getItem(KEY.tok)
  exp = Number(sessionStorage.getItem(KEY.exp) || 0)
} catch {}

let off = false
let pending: Promise<string | null> | null = null

const isTokenValid = () => !off && !!token && Date.now() < exp - 30_000

let state: State = {
  devtools: false,
  bot: false,
  captcha: null,
  verified: import.meta.env.DEV || isTokenValid(),
  failed: false,
}
const subs = new Set<() => void>()
const set = (p: Partial<State>) => {
  state = { ...state, ...p }
  subs.forEach((f) => f())
}
export const useShield = () =>
  useSyncExternalStore(
    (f) => (subs.add(f), () => void subs.delete(f)),
    () => state,
  )

export function isShieldVerified(): boolean {
  return import.meta.env.DEV || off || isTokenValid()
}

export function useShieldVerified(): boolean {
  const s = useShield()
  return s.verified
}

/* ---------- token ---------- */
const nativeFetch = window.fetch.bind(window)

async function solve(cid: string, salt: string, difficulty: number) {
  const prefix = '0'.repeat(difficulty)
  const enc = new TextEncoder()
  for (let n = 0; n < 500_000; n++) {
    const b = new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(`${cid}:${salt}:${n}`)))
    const h = [...b.slice(0, 4)].map((x) => x.toString(16).padStart(2, '0')).join('')
    if (h.startsWith(prefix)) return n
  }
  return -1
}

let answer: ((a: string) => void) | null = null
const askCaptcha = (svg: string, error: boolean) =>
  new Promise<string>((res) => {
    answer = res
    set({ captcha: { svg, error } })
  })
export function submitCaptcha(a: string) {
  answer?.(a)
  answer = null
  set({ captcha: null })
}

async function fetchTokenOnce(): Promise<{ token: string | null; retry: boolean }> {
  let wrong = false
  for (let tries = 0; tries < 6; tries++) {
    const cr = await nativeFetch(`${API}/api/shield/challenge${state.bot ? '?cap=1' : ''}`)
    if (cr.status === 429 || cr.status >= 500) return { token: null, retry: true }
    const { svg, ...c } = await cr.json()
    if (c.off) {
      off = true
      set({ verified: true, failed: false })
      return { token: null, retry: false }
    }
    const nonce = await solve(c.cid, c.salt, c.difficulty)
    if (nonce < 0) return { token: null, retry: true }
    // Every API call waits here until the captcha is solved.
    const answer = c.cap ? await askCaptcha(svg, wrong) : undefined
    const r = await nativeFetch(`${API}/api/shield/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...c, nonce, answer }),
    })
    const d = await r.json().catch(() => null)
    if (r.ok && d?.token) {
      token = d.token
      exp = Date.now() + d.expiresIn * 1000
      try {
        sessionStorage.setItem(KEY.tok, token!)
        sessionStorage.setItem(KEY.exp, String(exp))
      } catch {}
      set({ verified: true, captcha: null, failed: false })
      return { token, retry: false }
    }
    if (r.status === 429 || r.status >= 500) return { token: null, retry: true }
    if (d?.code !== 'SHIELD_CAPTCHA_WRONG') {
      // stale / bad proof (e.g. challenge expired while the captcha was open): just get a fresh challenge
      if (d?.code === 'SHIELD_BAD_PROOF') continue
      return { token: null, retry: false }
    }
    wrong = true
  }
  return { token: null, retry: false }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

// Transient failures (offline blip, 429, cold start) used to leave the player locked until a full reload.
async function fetchToken(): Promise<string | null> {
  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      const out = await fetchTokenOnce()
      if (out.token || off) return out.token
      if (!out.retry && attempt >= 1) break
    } catch {}
    await sleep(Math.min(1500 * 2 ** attempt, 12_000))
  }
  set({ failed: true })
  return null
}

export function getToken(): Promise<string | null> {
  if (off || import.meta.env.DEV) return Promise.resolve(null)
  if (token && Date.now() < exp - 30_000) return Promise.resolve(token)
  return (pending ??= fetchToken().finally(() => (pending = null)))
}

const forget = () => {
  token = null
  exp = 0
  try {
    sessionStorage.removeItem(KEY.tok)
    sessionStorage.removeItem(KEY.exp)
  } catch {}
  set({ verified: import.meta.env.DEV || off, failed: false })
}

/* ---------- fetch interceptor ---------- */
const origins = new Set([location.origin, API ? new URL(API, location.href).origin : ''])

const isProtected = (input: RequestInfo | URL) => {
  try {
    const u = new URL(typeof input === 'string' || input instanceof URL ? String(input) : input.url, location.href)
    return origins.has(u.origin) && (u.pathname.startsWith('/api/') || u.pathname === '/proxy') && !u.pathname.startsWith('/api/shield/')
  } catch {
    return false
  }
}

export function haltAllMedia() {
  try {
    document.querySelectorAll('video, audio').forEach((media) => {
      try {
        const el = media as HTMLMediaElement
        el.pause()
        el.removeAttribute('src')
        el.load()
      } catch {}
    })
    window.dispatchEvent(new CustomEvent('zenkai:devtools-halt'))
  } catch {}
}

function install() {
  const wrappedFetch: typeof window.fetch = async (input, init) => {
    if (!isProtected(input)) return nativeFetch(input, init)
    const send = (tok: string | null) => {
      const h = new Headers(init?.headers ?? (input instanceof Request ? input.headers : undefined))
      if (tok && !h.has('X-Zenkai-Shield')) h.set('X-Zenkai-Shield', tok)
      return nativeFetch(input, { ...init, headers: h })
    }
    let res = await send(await getToken())
    if (res.status === 401 || res.status === 403) {
      const body = await res.clone().json().catch(() => null)
      if (String(body?.code ?? '').startsWith('SHIELD_')) {
        forget()
        const t = await getToken()
        if (t) res = await send(t)
      }
    }
    return res
  }

  try {
    const desc =
      Object.getOwnPropertyDescriptor(window, 'fetch') ??
      Object.getOwnPropertyDescriptor(Object.getPrototypeOf(window), 'fetch')
    if (desc?.writable || desc?.set) {
      window.fetch = wrappedFetch
    } else if (!desc || desc.configurable) {
      Object.defineProperty(window, 'fetch', {
        value: wrappedFetch,
        writable: true,
        configurable: true,
        enumerable: desc?.enumerable ?? true,
      })
    }
  } catch {
    // Host environment exposes a non-configurable/read-only fetch; leave native fetch intact.
  }
}

/* ---------- bot + DevTools checks ---------- */
const AUTOMATION = ['__webdriver_script_fn', '__selenium_evaluate', 'callPhantom', '_phantom', '__nightmare', 'domAutomation', 'domAutomationController']

const looksAutomated = () =>
  !!navigator.webdriver ||
  AUTOMATION.some((k) => k in window) ||
  /HeadlessChrome|PhantomJS/i.test(navigator.userAgent) ||
  (!!(window as unknown as { chrome?: unknown }).chrome && !navigator.languages?.length)

let started = false
export function startShield() {
  if (started) return
  started = true
  install()
  if (import.meta.env.DEV) return
  if (looksAutomated()) set({ bot: true })
}

import { supabase } from './supabase'

export interface WatchRoomRecord {
  id: string
  host_id: string
  host_username: string
  host_display_name: string
  host_avatar: string | null
  anime_id: number
  anime_title: string
  episode: number
  server: string
  audio: string
  host_only_control: boolean
  created_at: string
  updated_at: string
}

const STORAGE_CLIENT_KEY = 'zk:client_session_id'

/** Get a persistent client session ID for this browser tab/device */
export function getClientSessionId(): string {
  if (typeof window === 'undefined') return 'server_client'
  let id = localStorage.getItem(STORAGE_CLIENT_KEY)
  if (!id) {
    id = `cs_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`
    localStorage.setItem(STORAGE_CLIENT_KEY, id)
  }
  return id
}

/** Get the authoritative host identifier for current user (auth user ID or client session ID) */
export function getMyHostIdentifier(userId?: string): string {
  return userId || getClientSessionId()
}

/** Check if current user is the host of a room */
export function isUserRoomHost(room: WatchRoomRecord | null, userId?: string): boolean {
  if (!room) return false
  const myId = getMyHostIdentifier(userId)
  return room.host_id === myId
}

/** Save newly created watch party room to Supabase */
export async function createWatchRoom(data: {
  roomId: string
  hostId: string
  hostUsername: string
  hostDisplayName: string
  hostAvatar: string | null
  animeId: number
  animeTitle: string
  episode: number
  server: string
  audio: string
  hostOnlyControl?: boolean
}): Promise<WatchRoomRecord | null> {
  try {
    // Match the host ID to the authenticated account; client-generated IDs are not ownership proof.
    const { data: authData, error: authError } = await supabase.auth.getUser()
    if (authError || !authData.user || authData.user.id !== data.hostId) {
      console.warn('[watchRooms] Refusing to create a room without an authenticated matching host.')
      return null
    }

    // Delete stale rooms through a constrained database function, never a broad client DELETE.
    void cleanExpiredWatchRooms()

    const payload = {
      id: data.roomId,
      host_id: data.hostId,
      host_username: data.hostUsername,
      host_display_name: data.hostDisplayName,
      host_avatar: data.hostAvatar,
      anime_id: data.animeId,
      anime_title: data.animeTitle,
      episode: data.episode,
      server: data.server,
      audio: data.audio,
      host_only_control: data.hostOnlyControl ?? true,
      updated_at: new Date().toISOString(),
    }

    const { data: record, error } = await supabase
      .from('watch_rooms')
      .upsert(payload)
      .select()
      .single()

    if (error) {
      console.warn('[watchRooms] createWatchRoom error:', error)
      return null
    }

    return record as WatchRoomRecord
  } catch (err) {
    console.warn('[watchRooms] createWatchRoom exception:', err)
    return null
  }
}

/** Fetch watch room from Supabase. Returns null if expired (>30 mins inactive) or not found */
export async function getWatchRoom(roomId: string): Promise<WatchRoomRecord | null> {
  const cleanId = roomId.trim().toLowerCase()
  if (!cleanId) return null

  try {
    // The function grants room membership only after the caller supplies a valid active room code.
    // Direct table-wide room reads are intentionally disabled by RLS.
    const { data, error } = await supabase.rpc('join_watch_room', { p_room_id: cleanId })
    if (error || !data || typeof data !== 'object') return null
    return data as WatchRoomRecord
  } catch {
    return null
  }
}

/** Update watch room state (episode, server, audio, show, host controls) and refresh 30-min window */
export async function updateWatchRoom(
  roomId: string,
  patch: Partial<{
    episode: number
    anime_id: number
    anime_title: string
    server: string
    audio: string
    host_only_control: boolean
  }>
): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('watch_rooms')
      .update({
        ...patch,
        updated_at: new Date().toISOString(),
      })
      .eq('id', roomId)

    return !error
  } catch {
    return false
  }
}

/** Keep room alive with heartbeat, resetting 30-min inactivity countdown */
export async function touchWatchRoom(roomId: string): Promise<void> {
  try {
    await supabase.rpc('touch_watch_room', { p_room_id: roomId.trim().toLowerCase() })
  } catch {
    // ignore
  }
}

/** Clean up rooms inactive for 30 minutes */
export async function cleanExpiredWatchRooms(): Promise<void> {
  try {
    // The database function deletes stale rooms without granting clients permission
    // to delete other users' active rooms.
    await supabase.rpc('cleanup_expired_watch_rooms')
  } catch {
    // ignore cleanup failures; joining and playback should keep working
  }
}

/** Delete room when host leaves or disbands */
export async function deleteWatchRoom(roomId: string): Promise<void> {
  try {
    await supabase.from('watch_rooms').delete().eq('id', roomId)
  } catch {
    // ignore
  }
}

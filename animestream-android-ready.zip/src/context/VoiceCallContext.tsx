import React, { createContext, useContext, useState, useEffect, type Context } from 'react'
import { DirectVoiceCall, sendIncomingCallAlert, type CallUserInfo } from '../lib/webrtcVoiceCall'
import { supabase } from '../lib/supabase'
import { useAuth } from './AuthContext'
import { useProfile } from '../lib/profile'
import { VoiceCallOverlay } from '../components/VoiceCallOverlay'
import { sendDirectMessage } from '../lib/messages'
import { toast } from '../lib/toast'
import { sanitizeNameStyle } from '../lib/nameStyle'

interface VoiceCallContextType {
  activeCall: DirectVoiceCall | null
  startCall: (partner: CallUserInfo, preacquiredStream?: MediaStream) => Promise<void>
  endCall: () => void
  returnPath: string | null
  setReturnPath: (path: string | null) => void
}

const VOICE_CALL_CONTEXT_KEY = Symbol.for('animestream.VoiceCallContext')
const globalWithVoiceCallContext = globalThis as typeof globalThis & {
  [VOICE_CALL_CONTEXT_KEY]?: Context<VoiceCallContextType | null>
}
const VoiceCallContext = (globalWithVoiceCallContext[VOICE_CALL_CONTEXT_KEY] ??=
  createContext<VoiceCallContextType | null>(null))

export function VoiceCallProvider({ children }: { children: React.ReactNode }) {
  const { user, username: authUsername } = useAuth()
  const me = useProfile()
  const username =
    authUsername ||
    (user?.user_metadata?.username as string | undefined) ||
    user?.email?.split('@')[0] ||
    (user?.id ? `user_${user.id.slice(0, 6)}` : 'user')
  const [activeCall, setActiveCall] = useState<DirectVoiceCall | null>(null)
  const [returnPath, setReturnPath] = useState<string | null>(null)

  // Restore active call on page refresh / reload
  useEffect(() => {
    if (!user?.id) return
    const saved = sessionStorage.getItem('zk:voice_call')
    if (!saved) return
    try {
      const parsed = JSON.parse(saved)
      if (!parsed?.callId || !parsed?.partner) return
      void (async () => {
        const { data } = await supabase
          .from('call_sessions')
          .select('status')
          .eq('call_id', parsed.callId)
          .maybeSingle()

        if (!data || data.status === 'ended' || data.status === 'declined') {
          sessionStorage.removeItem('zk:voice_call')
          return
        }

        const myUser: CallUserInfo = {
          id: user.id,
          username,
          displayName: me.name || user.user_metadata?.full_name || 'Otaku',
          avatar: me.avatar,
          nameStyle: me.nameStyle ? sanitizeNameStyle(me.nameStyle) : null,
        }

        const restored = new DirectVoiceCall({
          callId: parsed.callId,
          myUser,
          partner: {
            ...parsed.partner,
            nameStyle: parsed.partner.nameStyle ? sanitizeNameStyle(parsed.partner.nameStyle) : null,
          },
          isCaller: parsed.isCaller,
        })
        if (parsed.connectedAt) {
          restored.connectedAt = parsed.connectedAt
        }
        await restored.initSignaling()
        setActiveCall(restored)
        await restored.reconnect()
      })()
    } catch {
      sessionStorage.removeItem('zk:voice_call')
    }
  }, [user?.id, username, me])

  // Save active call to sessionStorage only if call was accepted and active
  useEffect(() => {
    if (activeCall && activeCall.status !== 'ended' && activeCall.isAccepted) {
      try {
        sessionStorage.setItem('zk:voice_call', JSON.stringify({
          callId: activeCall.callId,
          isCaller: activeCall.isCaller,
          partner: activeCall.partner,
          connectedAt: activeCall.connectedAt,
        }))
      } catch {}
    } else {
      try {
        sessionStorage.removeItem('zk:voice_call')
      } catch {}
    }
  }, [activeCall, activeCall?.status, activeCall?.isAccepted])

  // Automatically clear activeCall state and sessionStorage when call ends
  useEffect(() => {
    if (!activeCall) return
    const unlisten = activeCall.addCallEndedListener(() => {
      try {
        sessionStorage.removeItem('zk:voice_call')
      } catch {}
      setTimeout(() => {
        setActiveCall((curr) => (curr?.callId === activeCall.callId ? null : curr))
      }, 1200)
    })
    return unlisten
  }, [activeCall])

  // Inform partner if we are refreshing / reloading tab during an active call
  useEffect(() => {
    const handleBeforeUnload = () => {
      if (activeCall && (activeCall.status === 'connected' || activeCall.status === 'hold')) {
        void activeCall.signalChannel?.send({
          type: 'broadcast',
          event: 'call:partner_reloading',
          payload: { by: user?.id },
        })
      }
    }
    window.addEventListener('beforeunload', handleBeforeUnload)
    return () => window.removeEventListener('beforeunload', handleBeforeUnload)
  }, [activeCall, user?.id])

  // Listen for global incoming call invitations targeted at current logged in user
  useEffect(() => {
    if (!user?.id) return

    const channel = supabase.channel(`call_invite_user_${user.id}`, { config: { private: true } })

    channel
      .on('broadcast', { event: 'incoming_call_invite' }, async ({ payload }) => {
        if (!payload || !payload.caller) return

        // If already in an active call, reject new call as busy so it doesn't interrupt or create duplicate
        if (activeCall && activeCall.status !== 'ended' && activeCall.status !== 'idle') {
          if (activeCall.partner.id === payload.caller.id) {
            activeCall.endCall(false, 'ended')
          } else {
            const busyChan = supabase.channel(`call_session_${payload.callId}`, { config: { private: true } })
            await busyChan.subscribe(async (s) => {
              if (s === 'SUBSCRIBED') {
                await busyChan.send({
                  type: 'broadcast',
                  event: 'call:rejected',
                  payload: { by: user.id, reason: 'busy' },
                })
                await supabase.removeChannel(busyChan)
              }
            })
            return
          }
        }

        const myUser: CallUserInfo = {
          id: user.id,
          username: username,
          displayName: me.name || user.user_metadata?.full_name || 'Otaku',
          avatar: me.avatar,
          nameStyle: me.nameStyle ? sanitizeNameStyle(me.nameStyle) : null,
        }

        const incoming = new DirectVoiceCall({
          callId: payload.callId,
          myUser,
          partner: {
            ...payload.caller,
            nameStyle: payload.caller.nameStyle ? sanitizeNameStyle(payload.caller.nameStyle) : null,
          },
          isCaller: false,
        })
        if (payload.offer) {
          incoming.pendingOffer = payload.offer
        }

        // Save current location as return path when receiving call
        setReturnPath(window.location.pathname + window.location.search)

        incoming.addCallEndedListener(async (summary) => {
          if (summary.status === 'missed') {
            const name = payload.caller.displayName || payload.caller.username
            toast(`Missed call from ${name}`, 'info')
            if (document.hidden && 'Notification' in window && Notification.permission === 'granted') {
              new Notification('Missed call', { body: `${name} tried to call you`, icon: '/favicon.ico' })
            }
          } else if (summary.status === 'ended' && incoming.connectedAt) {
            // Guarantee ended call duration is recorded even if caller lost connection
            const duration = Math.max(1, Math.floor((Date.now() - incoming.connectedAt) / 1000))
            try {
              const { data: latestMsgs } = await supabase
                .from('direct_messages')
                .select('id, content')
                .or(
                  `and(sender_id.eq.${user.id},receiver_id.eq.${payload.caller.id}),and(sender_id.eq.${payload.caller.id},receiver_id.eq.${user.id})`
                )
                .order('created_at', { ascending: false })
                .limit(3)

              const hasEndedMsg = latestMsgs?.some((m) => m.content.startsWith('[CALL:ended:'))
              if (!hasEndedMsg) {
                await sendDirectMessage(user.id, payload.caller.id, `[CALL:ended:${duration}]`)
              }
            } catch (err) {
              console.warn('[VoiceCall] Callee log call ended fallback:', err)
            }
          }
        })

        if (document.hidden && 'Notification' in window && Notification.permission === 'granted') {
          new Notification('Incoming call', {
            body: `${payload.caller.displayName || payload.caller.username} is calling…`,
            icon: '/favicon.ico',
            tag: payload.callId,
          })
        }

        await incoming.initSignaling()
        setActiveCall(incoming)
      })
      .subscribe()

    return () => {
      void supabase.removeChannel(channel)
    }
  }, [user?.id, username, me, activeCall])

  const startCall = async (partner: CallUserInfo, preacquiredStream?: MediaStream) => {
    if (!user?.id) {
      toast('Please sign in to make voice calls', 'error')
      return
    }

    if (activeCall && activeCall.status !== 'ended') {
      if (activeCall.partner.id === partner.id) {
        activeCall.endCall(false, 'ended')
      } else {
        toast('Already in a call', 'info')
        return
      }
    }

    const currentLoc = window.location.pathname + window.location.search
    setReturnPath(currentLoc)
    if ('Notification' in window && Notification.permission === 'default') void Notification.requestPermission()

    const myUser: CallUserInfo = {
      id: user.id,
      username: username,
      displayName: me.name || user.user_metadata?.full_name || 'Otaku',
      avatar: me.avatar,
      nameStyle: me.nameStyle ? sanitizeNameStyle(me.nameStyle) : null,
    }

    const callId = `call_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`

    const outgoing = new DirectVoiceCall({
      callId,
      myUser,
      partner: {
        ...partner,
        nameStyle: partner.nameStyle ? sanitizeNameStyle(partner.nameStyle) : null,
      },
      isCaller: true,
    })

    let startedMsgId: string | null = null

    // Caller logs the final resolution (ended duration, missed, or declined)
    outgoing.addCallEndedListener(async (summary) => {
      if (outgoing.isCaller) {
        try {
          const duration = outgoing.connectedAt
            ? Math.max(1, Math.floor((Date.now() - outgoing.connectedAt) / 1000))
            : (summary.duration || outgoing.getDuration() || 0)

          const isAnsweredCall = Boolean(outgoing.connectedAt || duration > 0 || summary.status === 'ended')
          const content = isAnsweredCall
            ? `[CALL:ended:${duration}]`
            : summary.status === 'declined'
            ? `[CALL:declined]`
            : `[CALL:missed]`

          if (startedMsgId) {
            const { error } = await supabase
              .from('direct_messages')
              .update({ content })
              .eq('id', startedMsgId)
            if (!error) return
          }
          await sendDirectMessage(user.id, partner.id, content)
        } catch (err) {
          console.warn('[VoiceCall] Failed to log call direct message:', err)
        }
      }
    })

    await outgoing.initSignaling()
    setActiveCall(outgoing)

    // Pre-generate WebRTC offer with audio track ready
    const offerPayload = await outgoing.startPeerConnectionAsCaller(preacquiredStream)

    window.setTimeout(() => {
      if (outgoing.status === 'calling') outgoing.endCall(true, 'missed')
    }, 45_000)

    // Send call started message to Supabase direct messages
    try {
      const dm = await sendDirectMessage(user.id, partner.id, `[CALL:started:${Date.now()}]`)
      if (dm?.id) startedMsgId = dm.id
    } catch (err) {
      console.warn('[VoiceCall] Failed to send call started message:', err)
    }

    // Broadcast incoming call invite to partner with pre-generated offer included
    await sendIncomingCallAlert(partner.id, {
      callId,
      caller: myUser,
      offer: offerPayload,
    })
  }

  const endCall = () => {
    try {
      sessionStorage.removeItem('zk:voice_call')
    } catch {}
    if (activeCall) {
      activeCall.endCall()
      setActiveCall(null)
    }
  }

  return (
    <VoiceCallContext.Provider value={{ activeCall, startCall, endCall, returnPath, setReturnPath }}>
      {children}
      <VoiceCallOverlay call={activeCall} onEndCall={() => setActiveCall(null)} />
    </VoiceCallContext.Provider>
  )
}

export function useVoiceCall() {
  const ctx = useContext(VoiceCallContext)
  if (!ctx) throw new Error('useVoiceCall must be used within a VoiceCallProvider')
  return ctx
}

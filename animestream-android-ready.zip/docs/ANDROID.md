# Android app build

AnimeStream is a React/Vite app packaged for Android with Capacitor. The app UI is bundled locally in the Android APK; API requests are sent to the HTTPS backend configured at build time.

## Requirements

- Node.js 22 or newer and npm
- Android Studio 2025.2.1 or newer
- Android SDK Platform 24 or newer (the generated Capacitor 8 app supports Android 7 / API 24 and later)

Capacitor/Android references:
- https://capacitorjs.com/docs/android
- https://capacitorjs.com/docs/getting-started/environment-setup

## First-time setup

1. Copy `.env.android.example` to `.env.android`.
2. Set `VITE_API_BASE` and `VITE_SITE_URL` to the real HTTPS domain hosting the AnimeStream API/Cloudflare Pages Functions. The example uses the domain already listed in `index.html`; change it if you deploy elsewhere.
3. Install dependencies with `npm install`.
4. Run `sh scripts/android-setup.sh`. This builds the web bundle, creates the Android project if needed, syncs the app assets, and applies the supplied launcher icons and microphone permission.
5. Run `npx cap open android`, allow Android Studio to sync Gradle, and build/run the app.

For later web changes, run `npm run cap:sync:android`. To build a debug APK after Android Studio/SDK setup, run `npm run build:android:debug`. The output is `android/app/build/outputs/apk/debug/app-debug.apk`.

## Native playback and permissions

The Android branding script declares `RECORD_AUDIO` and `MODIFY_AUDIO_SETTINGS` for the existing voice-chat feature, but marks the microphone hardware as optional so tablets and devices without a microphone can still install the app. Capacitor's Android WebView bridge handles the runtime permission request when a page asks for microphone access. The player uses its fixed-position fullscreen mode in the native WebView and keeps the existing orientation/rotation fallback for devices that cannot lock landscape.

## API and secrets

The APK contains only public client configuration (Supabase URL and publishable/anon key). The Supabase service-role key, TMDB private keys, and server secrets must exist only as Cloudflare Pages/server secrets. Never place them in `.env.android`, any `VITE_` variable, the Android project, or a committed file.

`VITE_API_BASE` must point at the deployed backend because the bundled app runs on the local Capacitor origin and cannot use relative `/api/*` paths to reach the deployed server.

## Supported Android versions

Capacitor 8's Android support floor is API 24 (Android 7). It is not possible to support every historical Android release; older Android versions and old WebView builds are outside the supported range. Newer Android releases still need testing on real devices, especially video playback, fullscreen rotation, audio output, microphone permission prompts, and file selection.

# Security and privacy notes

## Required database migration

For an existing Supabase project, run `supabase/security-hardening.sql` in the Supabase SQL Editor before publishing the updated app. A fresh database created from `supabase/schema.sql` already includes the same hardening.

The earlier `user_sync` SELECT policy used `auth.uid() = user_id OR TRUE`, which allowed any API role to read every user's history, lists, reading progress, and preferences. The updated policy restricts reads and writes to the authenticated owner.

Supabase already enables RLS on `realtime.messages`; the migration adds policies without changing ownership or attempting to re-enable RLS. After deploying clients that subscribe with `config.private: true`, open Supabase Dashboard → Realtime → Settings and turn **Allow public access** off. Do this only after the updated app is deployed: older clients that still subscribe to public channels will stop connecting. The SQL policies authorize private call, invitation, watch-party, and inbox topics; the `direct_messages` table still separately enforces participant RLS for Postgres Changes.

The hardening also:
- restricts watch-room creation, updates, and deletion to the authenticated host, and exposes each room only to its host and accounts that join with the room code;
- moves room lookup, membership registration, heartbeat, and stale-room cleanup into narrowly scoped database functions;
- restricts voice-call rows to the two call participants, keeps participant IDs immutable, validates ICE-candidate ownership and payload size, and authorizes private call/invite Realtime topics only for the participants;
- restricts private watch-together Realtime topics to authenticated users and rooms that exist in the database;
- limits private direct-message Realtime topics to the signed-in user’s own inbox topics, while Postgres Changes delivery remains governed by the direct-message table’s participant RLS policy.
- adds the missing `call_sessions.ended_at` column used by the client;
- restricts direct-message updates so a sender edits content and a recipient marks messages read;
- requires authentication for stream-report submissions and community likes.

## Secret handling

- `VITE_*` variables are compiled into browser/mobile assets and must be treated as public.
- `SUPABASE_SERVICE_ROLE_KEY`, `TMDB_API_KEY`, `TMDB_BEARER_TOKEN`, and all signing/support secrets belong only in server-side Cloudflare Pages secrets or equivalent backend environment variables.
- Do not commit `.env`, `.env.android`, or build outputs containing deployment values.
- The previous project source included a hard-coded TMDB access token. Rotate that token in TMDB before deployment; deleting it from this source copy does not invalidate the old token. If any service-role or private API key was ever exposed publicly, rotate it at the provider before deployment.

## Caching and transport

The service worker caches only the static application shell and same-origin static build assets. It intentionally skips `/api/*`, `/proxy`, Supabase REST/auth/storage endpoints, query-string requests, and third-party video/media URLs. The Android configuration uses an HTTPS Capacitor origin and the branding setup disables Android cleartext traffic and app backup.

Supabase Auth still persists its session in the app's WebView storage as configured by `src/lib/supabase.ts`. Android's app sandbox protects this storage from ordinary apps, but this is not a claim of hardware-backed encrypted token storage. Keep the device OS updated and avoid sharing unlocked devices.

## Release checklist

- Apply the SQL migration and verify the policies in Supabase Table Editor / policy advisor.
- Confirm a signed-in user cannot read another user's `user_sync`, DMs, supporter record, or call session.
- Confirm a user cannot enumerate rooms they have not joined, and a room host cannot alter another host's room.
- Confirm a non-participant cannot subscribe to call topics, only the addressed callee can read an invite topic, only the caller can publish an invite, and an anonymous user cannot join a watch-together Realtime topic.
- Confirm server-only secrets are set only in backend secret storage and are absent from `dist/` and APK assets.
- Test login/logout, account recovery, playback, fullscreen, device rotation, audio, microphone permission, and file picker flows on multiple Android versions and screen densities.
- Run `npm test`, `npm run lint`, and a production build before release.

No code review or automated static check can guarantee zero bugs or zero data exposure. Re-run security checks whenever database policies, auth flows, or server routes change.

import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const schema = readFileSync(resolve(process.cwd(), 'supabase/schema.sql'), 'utf8')
const migration = readFileSync(resolve(process.cwd(), 'supabase/security-hardening.sql'), 'utf8')

test('private user sync rows are restricted to their authenticated owner', () => {
  assert.match(schema, /create policy "Users can view own sync"\s+on public\.user_sync for select using \(auth\.uid\(\) = user_id\);/i)
  assert.doesNotMatch(schema, /user_sync for select using \([^;]*or\s+true/i)
  assert.match(migration, /on public\.user_sync for select using \(auth\.uid\(\) = user_id\)/i)
})

test('voice-call ICE candidate writes verify the matching participant', () => {
  assert.match(schema, /where call_id = p_call_id and caller_id = auth\.uid\(\)/i)
  assert.match(schema, /where call_id = p_call_id and callee_id = auth\.uid\(\)/i)
  assert.match(schema, /revoke all on function public\.append_call_candidate\(text, boolean, jsonb\) from public, anon/i)
})

test('Android/PWA cache configuration excludes private API and proxy requests', () => {
  const worker = readFileSync(resolve(process.cwd(), 'public/sw.js'), 'utf8')
  assert.match(worker, /PRIVATE_PREFIXES\s*=\s*\[[^\]]*'\/api\/'[^\]]*'\/proxy'/s)
  assert.match(worker, /url\.origin !== self\.location\.origin/)
})

test('private Realtime topics are scoped to the authenticated user or room participants', () => {
  assert.doesNotMatch(schema, /alter table realtime\.messages enable row level security/i)
  assert.doesNotMatch(migration, /alter table realtime\.messages enable row level security/i)
  assert.match(schema, /realtime\.topic\(\) = 'call_session_'/i)
  assert.match(schema, /realtime\.topic\(\) = 'call_invite_user_'/i)
  const schemaInviteRead = schema.split('create policy "AnimeStream private realtime read"')[1]?.split('create policy "AnimeStream private realtime write"')[0] || ''
  const schemaInviteWrite = schema.split('create policy "AnimeStream private realtime write"')[1] || ''
  const migrationInviteRead = migration.split('create policy "AnimeStream private realtime read"')[1]?.split('create policy "AnimeStream private realtime write"')[0] || ''
  const migrationInviteWrite = migration.split('create policy "AnimeStream private realtime write"')[1] || ''
  for (const readPolicy of [schemaInviteRead, migrationInviteRead]) {
    const inviteBlock = /or exists \(\s*select 1 from public\.call_sessions c\s*where realtime\.topic\(\) = 'call_invite_user_'[\s\S]*?\n    \)/i.exec(readPolicy)?.[0] || ''
    assert.match(inviteBlock, /auth\.uid\(\) = c\.callee_id/)
    assert.doesNotMatch(inviteBlock, /auth\.uid\(\) = c\.caller_id/)
  }
  for (const writePolicy of [schemaInviteWrite, migrationInviteWrite]) {
    const inviteBlock = /or exists \(\s*select 1 from public\.call_sessions c\s*where realtime\.topic\(\) = 'call_invite_user_'[\s\S]*?\n    \)/i.exec(writePolicy)?.[0] || ''
    assert.match(inviteBlock, /auth\.uid\(\) = c\.caller_id/)
    assert.doesNotMatch(inviteBlock, /auth\.uid\(\) = c\.callee_id/)
  }
  assert.match(schema, /realtime\.topic\(\) = 'wt_room_'/i)
  assert.match(schema, /realtime\.topic\(\) = 'dm_messages_page:' \|\| auth\.uid\(\)::text/i)
  assert.match(schema, /realtime\.topic\(\) = 'wt_room_' \|\| r\.id[\s\S]*?r\.host_id = auth\.uid\(\)::text[\s\S]*?m\.user_id = auth\.uid\(\)/i)
  assert.match(migration, /AnimeStream private realtime read/i)
  assert.match(migration, /realtime\.topic\(\) = 'wt_room_' \|\| r\.id[\s\S]*?r\.host_id = auth\.uid\(\)::text[\s\S]*?m\.user_id = auth\.uid\(\)/i)
  for (const file of ['src/lib/webrtcWatchTogether.ts', 'src/lib/webrtcVoiceCall.ts', 'src/context/VoiceCallContext.tsx', 'src/pages/MessagesPage.tsx', 'src/components/NavbarMessagesOverlay.tsx']) {
    assert.match(readFileSync(resolve(process.cwd(), file), 'utf8'), /private: true/)
  }
})

test('native Android watch API calls use the configured HTTPS API base', () => {
  const watchPage = readFileSync(resolve(process.cwd(), 'src/pages/WatchPage.tsx'), 'utf8')
  assert.ok(watchPage.includes("fetch(apiUrl(`/api/servers-available?${q}`))"))
  assert.ok(readFileSync(resolve(process.cwd(), 'src/services/api.ts'), 'utf8').includes("replace(/\\/+$/, '')"))
  assert.match(readFileSync(resolve(process.cwd(), '.gitignore'), 'utf8'), /^\.env\.android$/m)
})

test('watch-party room metadata requires a host or joined membership', () => {
  assert.match(schema, /create table if not exists public\.watch_room_members/i)
  assert.match(schema, /create or replace function public\.join_watch_room\(p_room_id text\)/i)
  assert.match(schema, /where m\.room_id = watch_rooms\.id and m\.user_id = auth\.uid\(\)/i)
  assert.match(migration, /create or replace function public\.touch_watch_room\(p_room_id text\)/i)
  assert.doesNotMatch(schema, /create policy "Authenticated users can read watch rooms"/i)
})


test('TMDB credentials are not embedded in backend source or sent to proxy mirrors', () => {
  const tmdb = readFileSync(resolve(process.cwd(), 'server/tmdb.js'), 'utf8')
  const handler = readFileSync(resolve(process.cwd(), 'server/handler.js'), 'utf8')
  assert.doesNotMatch(tmdb, /eyJhbGciOiJIUzI1NiJ9/)
  assert.doesNotMatch(tmdb, /DEFAULT_TMDB_(?:BEARER_TOKEN|API_KEY)/)
  assert.doesNotMatch(tmdb, /TMDB_FALLBACK/)
  assert.doesNotMatch(handler, /TMDB_FALLBACK/)
  assert.match(tmdb, /env\?\.TMDB_BEARER_TOKEN/)
  const share = readFileSync(resolve(process.cwd(), 'server/share.js'), 'utf8')
  assert.ok(share.includes('tmdbFetch(`${kind}/${id}?language=en-US`, env)'))
  assert.ok(share.includes('cardFor(kind, id, type, hint, env)'))
  const player = readFileSync(resolve(process.cwd(), 'src/components/CinePlayer.tsx'), 'utf8')
  assert.ok(player.includes('if (isCapacitorNative())'))
  assert.match(readFileSync(resolve(process.cwd(), 'vite.config.ts'), 'utf8'), /TMDB_BEARER_TOKEN: dotEnv\.TMDB_BEARER_TOKEN/)
})

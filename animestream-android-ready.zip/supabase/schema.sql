-- AnimeStream Supabase Schema
-- Run this entire script once inside your Supabase SQL Editor.
-- Also go to: Authentication -> Providers -> Email -> turn OFF "Confirm email" for instant registration.

create extension if not exists pgcrypto;

-- 1. Public user profiles
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  avatar_url text,
  banner_url text,
  frame text,
  bio text default '',
  name_style jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles add column if not exists name_style jsonb;

create unique index if not exists profiles_username_lower_idx
  on public.profiles (lower(username))
  where username is not null;

alter table public.profiles enable row level security;

drop policy if exists "Public profiles are readable" on public.profiles;
create policy "Public profiles are readable"
  on public.profiles for select using (true);

drop policy if exists "Users can insert own profile" on public.profiles;
create policy "Users can insert own profile"
  on public.profiles for insert with check (auth.uid() = id);

drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile"
  on public.profiles for update using (auth.uid() = id)
  with check (auth.uid() = id);

-- 2. Cloud user sync (history, watchlist, custom lists, reading, watched progress, prefs)
create table if not exists public.user_sync (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text,
  history jsonb not null default '[]'::jsonb,
  watchlist jsonb not null default '[]'::jsonb,
  custom_lists jsonb not null default '[]'::jsonb,
  reading jsonb not null default '[]'::jsonb,
  watched_eps jsonb not null default '{}'::jsonb,
  watched_movies jsonb not null default '{}'::jsonb,
  prefs jsonb not null default '{}'::jsonb,
  profile jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.user_sync add column if not exists watched_eps jsonb not null default '{}'::jsonb;
alter table public.user_sync add column if not exists watched_movies jsonb not null default '{}'::jsonb;
alter table public.user_sync add column if not exists prefs jsonb not null default '{}'::jsonb;

alter table public.user_sync enable row level security;

drop policy if exists "Users can view own sync" on public.user_sync;
create policy "Users can view own sync"
  on public.user_sync for select using (auth.uid() = user_id);

drop policy if exists "Users can upsert own sync" on public.user_sync;
create policy "Users can upsert own sync"
  on public.user_sync for insert with check (auth.uid() = user_id);

drop policy if exists "Users can update own sync" on public.user_sync;
create policy "Users can update own sync"
  on public.user_sync for update using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- 3. Community posts
create table if not exists public.community_posts (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  user_id uuid references auth.users(id) on delete set null,
  username text not null default 'Otaku',
  avatar_url text,
  frame text,
  title text not null,
  content text not null,
  category text not null default 'General',
  anime_title text,
  anime_id text,
  anime_image text,
  likes integer not null default 0,
  pinned boolean not null default false,
  edited boolean not null default false
);

alter table public.community_posts enable row level security;

drop policy if exists "Community posts are readable" on public.community_posts;
create policy "Community posts are readable"
  on public.community_posts for select using (true);

drop policy if exists "Authenticated users can create posts" on public.community_posts;
create policy "Authenticated users can create posts"
  on public.community_posts for insert with check (auth.uid() = user_id);

drop policy if exists "Authors can update own posts" on public.community_posts;
create policy "Authors can update own posts"
  on public.community_posts for update using (auth.uid() = user_id);

drop policy if exists "Authors can delete own posts" on public.community_posts;
create policy "Authors can delete own posts"
  on public.community_posts for delete using (auth.uid() = user_id);

create or replace function public.like_community_post(target_post_id uuid)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_likes integer;
begin
  if auth.uid() is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  update public.community_posts
  set likes = likes + 1
  where id = target_post_id
  returning likes into new_likes;
  return coalesce(new_likes, 0);
end;
$$;

revoke all on function public.like_community_post(uuid) from public, anon;
grant execute on function public.like_community_post(uuid) to authenticated;

-- 4. Direct messages
create table if not exists public.direct_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id) on delete cascade,
  receiver_id uuid not null references auth.users(id) on delete cascade,
  content text not null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.direct_messages enable row level security;

drop policy if exists "Users can view own DMs" on public.direct_messages;
create policy "Users can view own DMs"
  on public.direct_messages for select using (auth.uid() = sender_id or auth.uid() = receiver_id);

drop policy if exists "Users can send DMs" on public.direct_messages;
create policy "Users can send DMs"
  on public.direct_messages for insert with check (auth.uid() = sender_id);

drop policy if exists "Users can update own DMs" on public.direct_messages;
create policy "Participants can update own DMs"
  on public.direct_messages for update
  using (auth.uid() = sender_id or auth.uid() = receiver_id)
  with check (auth.uid() = sender_id or auth.uid() = receiver_id);

-- A sender may edit message content; only the recipient may mark it as read.
-- Identity and timestamps are immutable after insert.
create or replace function public.guard_direct_message_update()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if auth.uid() is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  if new.id is distinct from old.id
     or new.sender_id is distinct from old.sender_id
     or new.receiver_id is distinct from old.receiver_id
     or new.created_at is distinct from old.created_at then
    raise exception 'Message identity fields are immutable' using errcode = '42501';
  end if;

  if auth.uid() = old.sender_id then
    if new.read is distinct from old.read then
      raise exception 'Only the recipient may change read status' using errcode = '42501';
    end if;
  elsif auth.uid() = old.receiver_id then
    if new.content is distinct from old.content then
      raise exception 'Only the sender may edit message content' using errcode = '42501';
    end if;
    if old.read and not new.read then
      raise exception 'Read status cannot be reverted' using errcode = '42501';
    end if;
  else
    raise exception 'Not a message participant' using errcode = '42501';
  end if;

  return new;
end;
$$;

drop trigger if exists direct_messages_guard_update on public.direct_messages;
create trigger direct_messages_guard_update
  before update on public.direct_messages
  for each row execute function public.guard_direct_message_update();

drop policy if exists "Users can delete own DMs" on public.direct_messages;
create policy "Users can delete own DMs"
  on public.direct_messages for delete using (auth.uid() = sender_id);

-- 5. Watch rooms
create table if not exists public.watch_rooms (
  id text primary key,
  host_id text not null,
  host_username text,
  host_display_name text,
  host_avatar text,
  anime_id integer not null,
  anime_title text not null,
  episode integer not null default 1,
  server text not null default 'flixcloud',
  audio text not null default 'sub',
  host_only_control boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.watch_rooms enable row level security;

-- A room is visible only to its host and accounts that joined it with the room code.
create table if not exists public.watch_room_members (
  room_id text not null references public.watch_rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id)
);
alter table public.watch_room_members enable row level security;
revoke all on table public.watch_room_members from public, anon;
grant select on table public.watch_room_members to authenticated;
drop policy if exists "Users can view own watch-room memberships" on public.watch_room_members;
create policy "Users can view own watch-room memberships"
  on public.watch_room_members for select to authenticated
  using (auth.uid() = user_id);

drop policy if exists "Watch rooms public read/write for members" on public.watch_rooms;
drop policy if exists "Authenticated users can read watch rooms" on public.watch_rooms;
drop policy if exists "Room host and members can read watch rooms" on public.watch_rooms;
drop policy if exists "Room hosts can create watch rooms" on public.watch_rooms;
drop policy if exists "Room hosts can update watch rooms" on public.watch_rooms;
drop policy if exists "Room hosts can delete watch rooms" on public.watch_rooms;
create policy "Room host and members can read watch rooms"
  on public.watch_rooms for select to authenticated
  using (
    auth.uid() is not null
    and (
      host_id = auth.uid()::text
      or exists (
        select 1 from public.watch_room_members m
        where m.room_id = watch_rooms.id and m.user_id = auth.uid()
      )
    )
  );
create policy "Room hosts can create watch rooms"
  on public.watch_rooms for insert to authenticated
  with check (auth.uid() is not null and host_id = auth.uid()::text);
create policy "Room hosts can update watch rooms"
  on public.watch_rooms for update to authenticated
  using (auth.uid() is not null and host_id = auth.uid()::text)
  with check (auth.uid() is not null and host_id = auth.uid()::text);
create policy "Room hosts can delete watch rooms"
  on public.watch_rooms for delete to authenticated
  using (auth.uid() is not null and host_id = auth.uid()::text);

create or replace function public.join_watch_room(p_room_id text)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  room_record public.watch_rooms;
begin
  if auth.uid() is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  select r.* into room_record
  from public.watch_rooms r
  where r.id = lower(trim(p_room_id))
    and r.updated_at > now() - interval '30 minutes';

  if not found then
    return null;
  end if;

  insert into public.watch_room_members (room_id, user_id)
  values (room_record.id, auth.uid())
  on conflict (room_id, user_id) do nothing;

  return to_jsonb(room_record);
end;
$$;
revoke all on function public.join_watch_room(text) from public, anon;
grant execute on function public.join_watch_room(text) to authenticated;

create or replace function public.touch_watch_room(p_room_id text)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
begin
  if auth.uid() is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  update public.watch_rooms r
  set updated_at = now()
  where r.id = lower(trim(p_room_id))
    and (
      r.host_id = auth.uid()::text
      or exists (
        select 1 from public.watch_room_members m
        where m.room_id = r.id and m.user_id = auth.uid()
      )
    );

  return found;
end;
$$;
revoke all on function public.touch_watch_room(text) from public, anon;
grant execute on function public.touch_watch_room(text) to authenticated;

create or replace function public.cleanup_expired_watch_rooms()
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  deleted_count integer;
begin
  if auth.uid() is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  delete from public.watch_rooms
  where updated_at < now() - interval '30 minutes';
  get diagnostics deleted_count = row_count;
  return deleted_count;
end;
$$;
revoke all on function public.cleanup_expired_watch_rooms() from public, anon;
grant execute on function public.cleanup_expired_watch_rooms() to authenticated;

-- 6. Audio/voice call signaling sessions
create table if not exists public.call_sessions (
  call_id text primary key,
  caller_id uuid references auth.users(id) on delete cascade,
  callee_id uuid references auth.users(id) on delete cascade,
  status text not null default 'ringing',
  offer jsonb,
  answer jsonb,
  caller_candidates jsonb not null default '[]'::jsonb,
  callee_candidates jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  ended_at timestamptz
);

alter table public.call_sessions add column if not exists ended_at timestamptz;

alter table public.call_sessions enable row level security;

drop policy if exists "Participants can manage call sessions" on public.call_sessions;
create policy "Participants can view call sessions"
  on public.call_sessions for select
  using (auth.uid() = caller_id or auth.uid() = callee_id);
drop policy if exists "Participants can insert call sessions" on public.call_sessions;
create policy "Participants can insert call sessions"
  on public.call_sessions for insert
  with check (auth.uid() is not null and auth.uid() = caller_id);
drop policy if exists "Participants can update call sessions" on public.call_sessions;
create policy "Participants can update call sessions"
  on public.call_sessions for update
  using (auth.uid() = caller_id or auth.uid() = callee_id)
  with check (auth.uid() = caller_id or auth.uid() = callee_id);
drop policy if exists "Participants can delete call sessions" on public.call_sessions;
create policy "Participants can delete call sessions"
  on public.call_sessions for delete
  using (auth.uid() = caller_id or auth.uid() = callee_id);

-- A participant can update only their side of signaling; IDs and ownership stay immutable.
create or replace function public.guard_call_session_update()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if auth.uid() is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  if new.call_id is distinct from old.call_id
     or new.caller_id is distinct from old.caller_id
     or new.callee_id is distinct from old.callee_id
     or new.created_at is distinct from old.created_at then
    raise exception 'Call identity fields are immutable' using errcode = '42501';
  end if;

  if auth.uid() = old.caller_id then
    if new.answer is distinct from old.answer
       or new.callee_candidates is distinct from old.callee_candidates then
      raise exception 'Caller cannot modify callee signaling data' using errcode = '42501';
    end if;
  elsif auth.uid() = old.callee_id then
    if new.offer is distinct from old.offer
       or new.caller_candidates is distinct from old.caller_candidates then
      raise exception 'Callee cannot modify caller signaling data' using errcode = '42501';
    end if;
  else
    raise exception 'Not a call participant' using errcode = '42501';
  end if;

  return new;
end;
$$;

drop trigger if exists call_sessions_guard_update on public.call_sessions;
create trigger call_sessions_guard_update
  before update on public.call_sessions
  for each row execute function public.guard_call_session_update();

create or replace function public.append_call_candidate(p_call_id text, p_is_caller boolean, p_candidate jsonb)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if auth.uid() is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;
  if p_candidate is null or jsonb_typeof(p_candidate) <> 'object' or pg_column_size(p_candidate) > 4096 then
    raise exception 'Invalid ICE candidate payload' using errcode = '22023';
  end if;

  if p_is_caller then
    update public.call_sessions
    set caller_candidates = coalesce(caller_candidates, '[]'::jsonb) || jsonb_build_array(p_candidate),
        updated_at = now()
    where call_id = p_call_id and caller_id = auth.uid()
      and jsonb_array_length(coalesce(caller_candidates, '[]'::jsonb)) < 256;
  else
    update public.call_sessions
    set callee_candidates = coalesce(callee_candidates, '[]'::jsonb) || jsonb_build_array(p_candidate),
        updated_at = now()
    where call_id = p_call_id and callee_id = auth.uid()
      and jsonb_array_length(coalesce(callee_candidates, '[]'::jsonb)) < 256;
  end if;
end;
$$;

revoke all on function public.append_call_candidate(text, boolean, jsonb) from public, anon;
grant execute on function public.append_call_candidate(text, boolean, jsonb) to authenticated;

-- Private Realtime channels: only call participants can exchange signaling,
-- and only authenticated users can join a room that exists in watch_rooms.
drop policy if exists "AnimeStream private realtime read" on realtime.messages;
create policy "AnimeStream private realtime read"
  on realtime.messages for select to authenticated
  using (
    exists (
      select 1 from public.call_sessions c
      where realtime.topic() = 'call_session_' || c.call_id
        and (auth.uid() = c.caller_id or auth.uid() = c.callee_id)
    )
    or exists (
      select 1 from public.call_sessions c
      where realtime.topic() = 'call_invite_user_' || c.callee_id::text
        and auth.uid() = c.callee_id
    )
    or exists (
      select 1 from public.watch_rooms r
      where realtime.topic() = 'wt_room_' || r.id
        and (
          r.host_id = auth.uid()::text
          or exists (
            select 1 from public.watch_room_members m
            where m.room_id = r.id and m.user_id = auth.uid()
          )
        )
    )
    or realtime.topic() = 'dm_messages_page:' || auth.uid()::text
    or realtime.topic() = 'inbox_overlay_realtime:' || auth.uid()::text
  );
drop policy if exists "AnimeStream private realtime write" on realtime.messages;
create policy "AnimeStream private realtime write"
  on realtime.messages for insert to authenticated
  with check ((
    exists (
      select 1 from public.call_sessions c
      where realtime.topic() = 'call_session_' || c.call_id
        and (auth.uid() = c.caller_id or auth.uid() = c.callee_id)
    )
    or exists (
      select 1 from public.call_sessions c
      where realtime.topic() = 'call_invite_user_' || c.callee_id::text
        and auth.uid() = c.caller_id
    )
    or exists (
      select 1 from public.watch_rooms r
      where realtime.topic() = 'wt_room_' || r.id
        and (
          r.host_id = auth.uid()::text
          or exists (
            select 1 from public.watch_room_members m
            where m.room_id = r.id and m.user_id = auth.uid()
          )
        )
    )
  )
  and realtime.messages.extension in ('broadcast', 'presence'));

-- 7. Stream reports
create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  anime_id text,
  anime_title text not null,
  episode text not null,
  server text,
  audio_type text,
  issue_type text not null,
  details text,
  playback_time text,
  status text not null default 'pending',
  user_agent text
);

alter table public.reports enable row level security;

drop policy if exists "Authenticated users can submit reports" on public.reports;
create policy "Authenticated users can submit reports"
  on public.reports for insert with check (auth.uid() is not null);

-- 8. Support missions progress & supporter stats
create table if not exists public.supporter_records (
  user_id uuid primary key references auth.users(id) on delete cascade,
  completed_count integer not null default 0,
  total_links_solved integer not null default 0,
  total_xp integer not null default 0,
  active_mission jsonb,
  claimed_tokens jsonb not null default '[]'::jsonb,
  last_completed_at timestamptz,
  updated_at timestamptz not null default now()
);

alter table public.supporter_records enable row level security;

drop policy if exists "Users can view own supporter record" on public.supporter_records;
create policy "Users can view own supporter record"
  on public.supporter_records for select using (auth.uid() = user_id);

drop policy if exists "Users can insert own supporter record" on public.supporter_records;
create policy "Users can insert own supporter record"
  on public.supporter_records for insert with check (auth.uid() = user_id);

drop policy if exists "Users can update own supporter record" on public.supporter_records;
create policy "Users can update own supporter record"
  on public.supporter_records for update using (auth.uid() = user_id)
  with check (auth.uid() = user_id);


import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'com.animestream.app',
  appName: 'AnimeStream',
  webDir: 'dist',
  backgroundColor: '#050506',
  server: {
    androidScheme: 'https',
  },
}

export default config

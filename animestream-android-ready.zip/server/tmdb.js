// Centralized TMDB Client for AnimeStream.
// Credentials are read only from server-side Cloudflare/runtime environment variables.
// Never hard-code TMDB access tokens or pass them to third-party proxy services.

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
export const TMDB_API_BASE = "https://api.themoviedb.org/3";
export const TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p";

/**
 * Fetch from TMDB using server-only credentials. A metadata mirror is attempted
 * as a credential-free fallback; private TMDB credentials are never forwarded
 * to that mirror or any other third-party proxy.
 * @param {string} endpoint - e.g. "trending/movie/week" or "/tv/269?append_to_response=images"
 * @param {object} [env] - Cloudflare worker/pages environment
 */
export async function tmdbFetch(endpoint, env = null) {
  const token = String(
    env?.TMDB_BEARER_TOKEN ||
    env?.TMDB_API_READ_ACCESS_TOKEN ||
    env?.TMDB_READ_ACCESS_TOKEN ||
    (typeof process !== "undefined" && (process.env?.TMDB_BEARER_TOKEN || process.env?.TMDB_API_READ_ACCESS_TOKEN)) ||
    ""
  ).trim();

  const apiKey = String(
    env?.TMDB_API_KEY ||
    env?.TMDB_KEY ||
    (typeof process !== "undefined" && (process.env?.TMDB_API_KEY || process.env?.TMDB_KEY)) ||
    ""
  ).trim();

  // Normalize endpoint: strip leading slash or full TMDB URL.
  const clean = endpoint.startsWith("http")
    ? endpoint.replace(/^https?:\/\/[^\/]+(?:\/3|\/api\/tmdb)?\/?/, "")
    : endpoint.replace(/^\/+/, "");

  const sep = clean.includes("?") ? "&" : "?";
  const hasKey = /(?:^|[?&])api_key=/.test(clean);
  const directUrl = `${TMDB_API_BASE}/${clean}${hasKey || !apiKey ? "" : `${sep}api_key=${encodeURIComponent(apiKey)}`}`;

  const fromDirect = async () => {
    if (!token && !apiKey && !hasKey) {
      throw new Error("TMDB server credentials are not configured");
    }
    const headers = { Accept: "application/json", "User-Agent": UA };
    if (token) headers.Authorization = `Bearer ${token}`;
    const res = await fetch(directUrl, {
      headers,
      signal: AbortSignal.timeout(4500),
    });
    if (!res.ok) throw new Error(`TMDB direct ${res.status}`);
    return await res.json();
  };

  const fromMirror = async () => {
    const mirrorUrl = `https://zenkai-movies-production.up.railway.app/api/movies/${clean}`;
    const res = await fetch(mirrorUrl, {
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(4500),
    });
    if (!res.ok) throw new Error(`TMDB mirror ${res.status}`);
    const data = await res.json();
    if (!data || data.error) throw new Error("TMDB mirror returned an invalid response");
    return data;
  };

  try {
    return await Promise.any([fromMirror(), fromDirect()]);
  } catch (_error) {
    throw new Error(`TMDB fetch failed for ${endpoint}`);
  }
}

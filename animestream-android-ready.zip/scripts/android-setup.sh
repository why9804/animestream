#!/usr/bin/env sh
set -eu

if [ ! -f .env.android ]; then
  echo "Missing .env.android. Copy .env.android.example to .env.android and set your deployed API URL." >&2
  exit 1
fi

npm run build:android:web
if [ ! -d android ]; then
  npx cap add android
fi
npx cap sync android
sh scripts/apply-android-branding.sh
echo "Android project synced. Open it with: npx cap open android"

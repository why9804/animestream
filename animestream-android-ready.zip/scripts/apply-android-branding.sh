#!/usr/bin/env sh
set -eu
RES="android/app/src/main/res"
MANIFEST="android/app/src/main/AndroidManifest.xml"
if [ ! -d "$RES" ] || [ ! -f "$MANIFEST" ]; then
  echo "Android project not found. Run: npx cap add android" >&2
  exit 1
fi
for dir in resources/android/mipmap-*; do
  [ -d "$dir" ] || continue
  mkdir -p "$RES/$(basename "$dir")"
  cp "$dir"/*.png "$RES/$(basename "$dir")/"
done
mkdir -p "$RES/drawable-nodpi" "$RES/mipmap-anydpi-v26" "$RES/values"
cp resources/android/ic_launcher_foreground.png "$RES/drawable-nodpi/ic_launcher_foreground.png"
cat > "$RES/mipmap-anydpi-v26/ic_launcher.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
XML
cat > "$RES/mipmap-anydpi-v26/ic_launcher_round.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
XML
cat > "$RES/values/animestream_colors.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#050506</color>
</resources>
XML
if [ -f "$RES/values/strings.xml" ]; then
  if grep -q 'name="app_name"' "$RES/values/strings.xml"; then
    sed -i 's#<string name="app_name">[^<]*</string>#<string name="app_name">AnimeStream</string>#' "$RES/values/strings.xml"
  fi
fi
# WebRTC voice calls need the microphone. Not requiring the feature keeps tablets/emulators installable.
if ! grep -q 'android.permission.RECORD_AUDIO' "$MANIFEST"; then
  sed -i '/<application/i\    <uses-permission android:name="android.permission.RECORD_AUDIO" />' "$MANIFEST"
fi
if ! grep -q 'android.permission.MODIFY_AUDIO_SETTINGS' "$MANIFEST"; then
  sed -i '/<application/i\    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />' "$MANIFEST"
fi
if ! grep -q 'android.hardware.microphone' "$MANIFEST"; then
  sed -i '/<application/i\    <uses-feature android:name="android.hardware.microphone" android:required="false" />' "$MANIFEST"
fi
# Keep account/session data inside the app sandbox and require HTTPS network traffic.
if grep -q 'android:allowBackup=' "$MANIFEST"; then
  sed -i 's/android:allowBackup="[^"]*"/android:allowBackup="false"/' "$MANIFEST"
else
  sed -i 's/<application/<application android:allowBackup="false"/' "$MANIFEST"
fi
if grep -q 'android:usesCleartextTraffic=' "$MANIFEST"; then
  sed -i 's/android:usesCleartextTraffic="[^"]*"/android:usesCleartextTraffic="false"/' "$MANIFEST"
else
  sed -i 's/<application/<application android:usesCleartextTraffic="false"/' "$MANIFEST"
fi
echo "AnimeStream launcher icons and Android privacy permissions applied."
